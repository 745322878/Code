void ScreeningsCreate(struct film *ptemp)
{
	struct film *phead,*pnew,*t;
	FILE *fp;
	int i;
	float time =8;
	fp=fopen("/Users/wyz/Desktop/影院管理系统/文件/screenings.txt","a+");
	fprintf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",ptemp->name,
			ptemp->director,ptemp->actor,ptemp->type,ptemp->score,
			ptemp->time,ptemp->price,ptemp->year,ptemp->month,
			ptemp->day);
	phead=(struct film *)malloc(sizeof(struct film ));
	phead->next=NULL;
	t=phead;
	for(i=0;i<6;i++)
	{
		pnew=(struct film *)malloc(sizeof(struct film));
		pnew->start_time=time;
		pnew->end_time=0;
		pnew->movieroom=0;
		t->link=pnew;
		t=pnew;
		time+=3;
	}
	pnew->link=NULL;
	phead=phead->link;
	ptemp->link=phead;
	ptemp=ptemp->link;
	for(;ptemp!=NULL;ptemp=ptemp->link)
	{
		fprintf(fp,"%f %f %d\n",ptemp->start_time,ptemp->end_time,
					ptemp->movieroom);
	}
	fprintf(fp,"%f %f %d\n",0.0,0.0,0);
	fclose(fp);
}
