int k;
struct ShowFilm *chuan(struct film *phead)
{
		struct ShowFilm *pnew,*ptemp,*xhead;
		int i;
		k=0;
		xhead=(struct ShowFilm *)malloc(sizeof(struct ShowFilm));
		xhead->left=NULL;
		xhead->right=NULL;
		ptemp=xhead;
		while(1)
		{
				pnew=(struct ShowFilm *)malloc(sizeof(struct ShowFilm));
				for(i=0;i<2&&phead!=NULL;i++)
				{
						strcpy(pnew->name[i],phead->name);
						strcpy(pnew->director[i],phead->director);
						strcpy(pnew->actor[i],phead->actor);
						strcpy(pnew->type[i],phead->type);
						pnew->score[i]=phead->score;
						pnew->time[i]=phead->time;
						pnew->year[i]=phead->year;
						pnew->month[i]=phead->month;
						pnew->day[i]=phead->day;
						pnew->price[i]=phead->price;
						phead=phead->next;
				}
				ptemp->right=pnew;
				pnew->left=ptemp;
				pnew->right=NULL;
				ptemp=pnew;
				k++;
				if(phead==NULL)
				{
						strcpy(ptemp->name[i],"NULL");
						break;
				}
		}
		xhead=xhead->right;
		xhead->left=NULL;
		return xhead;
}
void Show(struct film *phead)
{
	struct ShowFilm *xhead,*ptemp;
	//struct film *ptemp=phead;
	int line=8,i,t=0,j;
	int print_line=1,tline;
	int flag,flag1;
	xhead=chuan(phead);
	ptemp=xhead;
	clear();
	box(stdscr,ACS_VLINE,ACS_HLINE);
	bkgd(COLOR_PAIR(6));
	curs_set(0);
	noecho();

	if(phead==NULL)
	{
		mvchgat(12,28,20,A_NORMAL,2,NULL);
		attron(A_BOLD|COLOR_PAIR(2));
		mvprintw(12,30,"影库还木有影片!😂 ");
		attroff(A_BOLD|COLOR_PAIR(2));
		getch();
	}	
	else
	{
		while(t>=0&&t<k)
		{
			clear();
		    box(stdscr,ACS_VLINE,ACS_HLINE);
			bkgd(COLOR_PAIR(6));
			print_line=1;
			

			for(j=0;j<2;j++)
			{
				if(strcmp(ptemp->name[j],"NULL")==0)
						break;
				tline=print_line;
				for(i=1;i<21;i++)
					mvprintw(print_line,i,"*");
											
				for(i=1;i<10;i++)
				{
					mvprintw(print_line+i,1,"*");
					mvprintw(print_line+i,20,"*");
				}
				for(i=1;i<21;i++)
					mvprintw(print_line+10,i,"*");
				mvprintw(tline+5,7,"%s",ptemp->name[j]);
				mvprintw(tline+1,14,"%2.1f分",ptemp->score[j]);
				mvprintw(tline+3,26,"导演");
				mvprintw(tline+3,35,"%s",ptemp->director[j]);
				mvprintw(tline+4,26,"主演");
				mvprintw(tline+4,35,"%s",ptemp->actor[j]);
				mvprintw(tline+5,26,"类型:");
				mvprintw(tline+5,35,"%s",ptemp->type[j]);
				mvprintw(tline+6,26,"首映:");
				mvprintw(tline+6,35,"%d-%d-%d",ptemp->year[j],
					ptemp->month[j],ptemp->day[j]);
				mvprintw(tline+7,26,"片长:");
				mvprintw(tline+7,35,"%d分钟",ptemp->time[j]);
				mvprintw(tline+8,26,"价格:");
				mvprintw(tline+8,35,"%2.2f元",ptemp->price[j]);
				print_line+=12;	
				
			}
		
			while(1)
			{
				mvprintw(8,70,"上一页");
				mvchgat(7,68,10,A_NORMAL,2,NULL);
				mvchgat(8,68,10,A_NORMAL,2,NULL);
				mvchgat(9,68,10,A_NORMAL,2,NULL);
		
				mvprintw(20,70,"下一页");
				mvchgat(19,68,10,A_NORMAL,2,NULL);
				mvchgat(20,68,10,A_NORMAL,2,NULL);
				mvchgat(21,68,10,A_NORMAL,2,NULL);
		
				mvprintw(14,71,"返回");
				mvchgat(13,68,10,A_NORMAL,2,NULL);
				mvchgat(14,68,10,A_NORMAL,2,NULL);
				mvchgat(15,68,10,A_NORMAL,2,NULL);
				
				mvchgat(line-1,68,10,A_BLINK,1,NULL);
				mvchgat(line,68,10,A_BLINK,1,NULL);
				mvchgat(line+1,68,10,A_BLINK,1,NULL);
				flag=getch();
				if(flag==KEY_DOWN)
				{
					line+=6;
					if(line==26)
						line=8;

				}
				else if(flag==KEY_UP)
				{
					line-=6;
					if(line==2)
						line=20;
				}
				else if(flag=='\r'||flag=='\n')
				{
					if(line==8)
					{
						if(ptemp->left==NULL)
						{
							flag1=2;
							continue;
						}
						t--;
						ptemp=ptemp->left;
						if(t==-1)
							flag1=1;
						break;
					}
					else if (line==14)
					{
						flag1=1;
						break;
					}
					else if(line==20)
					{
						if(ptemp->right==NULL)
						{
							flag1=2;
							continue;
						}
						t++;
						ptemp=ptemp->right;
						if(t==k)
							flag1=1;
						
						break;
					}

				}
			}
			if(flag1==1)
				break;
			else if(flag1==2)
					continue;
		}	
	}
}
