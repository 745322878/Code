void Screenings()		//场次设置
{
	struct film *phead=Read_file();
	struct film *ptemp=phead;
	struct film *pnew,*t,*shead;
	int line=13,flag,flag1,row=10;
    float End;
    float middle;
	char name[20];
	int print_line=1,tline;
	float thour=8,hour,minute;
	int i,j;
	FILE *fp;
	clear();
	box(stdscr,'|','-');
	bkgd(COLOR_PAIR(6));

	if(phead==NULL)
	{
		
		mvchgat(12,28,20,A_NORMAL,2,NULL);
		attron(A_BOLD|COLOR_PAIR(2));
		mvprintw(12,30,"影库还没有影片！😂 ");
		attroff(A_BOLD|COLOR_PAIR(2));
		getch();
	}		
	else
	{
			fp=fopen("/Users/wyz/Desktop/影院管理系统/文件/screenings.txt","w+");
			fclose(fp);
			while(ptemp!=NULL)
			{
				    clear();
				box(stdscr,'|','-');
				bkgd(COLOR_PAIR(6));
				tline=1;
				print_line=1;
				for(i=1;i<21;i++)
				{
					mvprintw(print_line,i,"*");
				}
				for(i=1;i<10;i++)
				{
					mvprintw(print_line+i,1,"*");
					mvprintw(print_line+i,20,"*");
				}
				for(i=1;i<21;i++)
					mvprintw(print_line+10,i,"*");
				mvprintw(tline+5,7,"%s",ptemp->name);
				mvprintw(tline+1,14,"%2.1f分",ptemp->score);
				mvprintw(tline+3,26,"导演");
				mvprintw(tline+3,35,"%s",ptemp->director);
				mvprintw(tline+4,26,"主演");
				mvprintw(tline+4,35,"%s",ptemp->actor);
				mvprintw(tline+5,26,"类型:");
				mvprintw(tline+5,35,"%s",ptemp->type);
				mvprintw(tline+6,26,"首映:");
				mvprintw(tline+6,35,"%d-%d-%d",ptemp->year,
									ptemp->month,ptemp->day);
				mvprintw(tline+7,26,"片长:");
				mvprintw(tline+7,35,"%d分钟",ptemp->time);
				mvprintw(tline+8,26,"价格:");
				mvprintw(tline+8,35,"%2.2f元",ptemp->price);
				print_line=13;
				
				mvprintw(print_line,13,"8:00");
				mvprintw(print_line,23,"11:00");
				mvprintw(print_line,33,"14:00");
				mvprintw(print_line,43,"17:00");
				mvprintw(print_line,53,"20:00");
				mvprintw(print_line,63,"23:00");
				mvchgat(print_line,10,60,A_NORMAL,2,NULL);
				for(i=10;i<70;i++)
						mvprintw(print_line+1,i,"-");
				for(j=print_line+2;j<print_line+4;j++)
				{
					for(i=15;i<75;i+=10)
					{
						mvprintw(j,i,"|");
					}
				}
				for(j=print_line+5;j<print_line+7;j++)
				{
					for(i=15;i<75;i+=10)
					{
						mvprintw(j,i,"|");
                    }
				}
				for(i=10;i<70;i++)
						mvprintw(print_line+7,i,"-");
				
				
				attron(A_BOLD);
				mvprintw(24,38,"下一个");
				attroff(A_BOLD);
				mvchgat(24,36,10,A_NORMAL,2,NULL);
				
				//default
				shead=(struct film *)malloc(sizeof(struct film ));
				pnew=(struct film *)malloc(sizeof(struct film));
				shead->link=NULL;
				t=shead;
				row=10;
				thour=8.0;
				curs_set(1);
				echo();
				for(i=0;i<6;i++)
				{
					pnew=(struct film *)malloc(sizeof(struct film));
					pnew->start_time=thour;
					hour=ptemp->time/60;
					minute=ptemp->time%60;
                    middle = thour+hour;
                    if (middle > 24) {
                        middle = middle - 24;
                    }
					mvprintw(print_line+8,row+3,"%1.0f:%1.0f",
									middle,minute);
					mvchgat(print_line+8,10,60,A_NORMAL,2,NULL);
					End = middle + minute/100;
                    if (End > 24) {
                        pnew->end_time = End - 24;
                    }
                    else
                    {
                        pnew->end_time = End;
                    }
					thour+=3;
					
					mvchgat(print_line+4,row+3,5,A_NORMAL,7,NULL);
					move(print_line+4,row+5);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%d",&pnew->movieroom);
					attroff(A_BOLD|COLOR_PAIR(7));
					row+=10;

					t->link=pnew;
					pnew->link=NULL;
					t=pnew;
				}
				shead=shead->link;
				ptemp->link=shead;
				Save_Screenings(ptemp);
				ptemp=ptemp->next;

				curs_set(0);
				noecho();
				//mvchgat(line,10,60,A_NORMAL,2,NULL);
				mvchgat(24,36,10,A_BLINK,1,NULL);
				getch();
			}
			attron(A_BOLD);
			mvprintw(24,38,"!返回!");
	        attroff(A_BOLD);
			mvchgat(24,36,8,A_NORMAL,2,NULL);
			mvchgat(24,36,8,A_BLINK,1,NULL);
			getch();
			
	}	
	
}	/*
				//mvprint
				mvchgat(print_line+8,10,60,A_NORMAL,2,NULL);
				noecho();			//getch（）不回显
				curs_set(0);		//光标不回显
				pnew=ptemp;
				while(1)
				{
					mvchgat(line,10,60,A_NORMAL,2,NULL);
					mvchgat(line,row,10,A_BLINK,1,NULL);
					flag=getch();
					if(flag==KEY_RIGHT)
					{
						row+=10;
						if(row==70)
							row=10;
					}
					else if(flag==KEY_LEFT)
					{	
						row-=10;
						if(row==0)
							row=60;
					}
					else if(flag==KEY_DOWN)
					{
						mvchgat(line,10,60,A_NORMAL,2,NULL);
						mvchgat(24,36,8,A_BLINK,1,NULL);
						while(1)
						{
							flag=getch();	
							if(flag=='\r'||flag=='\n')
							{
								flag1=1;
								break;
							}
						}
						if(flag1==1)
						{
								flag1=2;
								break;
						}
					}
					else if(flag=='\r'||flag=='\n')
					{
						mvchgat(print_line+8,10,60,A_NORMAL,2,NULL);
						curs_set(1);
						echo();
						if(row==10)
							thour=10;
						else if(row==20)
								thour=14;
						else if(row==30)
								thour=17;
						else if(row==40)
								thour=20;
						else if(row==50)
								thour=23;
						else if(row==60)
								thour=2;
						hour=ptemp->time/60;
						minute=ptemp->time%60;
						mvprintw(print_line+8,row+3,"%1.0f:%1.0f",
									thour+hour,minute);
						mvchgat(print_line+8,10,60,A_NORMAL,2,NULL);
						ptemp->start_time=thour;
						ptemp->end_time=(thour+hour)+minute/100*1.0;
						mvchgat(print_line+4,row+3,5,A_NORMAL,7,NULL);
						move(print_line+4,row+5);
						attron(A_BOLD|COLOR_PAIR(7));
						scanw("%d",&ptemp->movieroom);
						attroff(A_BOLD|COLOR_PAIR(7));
						pnew->start_time=ptemp->start_time;
						pnew->end_time=ptemp->end_time;
						pnew->movieroom=ptemp->movieroom;
						
						t->link=pnew;
						pnew->link=NULL;
						t=pnew;
						Save_Screenings(ptemp);
						curs_set(0);
						noecho();
					}
				}
				curs_set(0);
				noecho();
				if(flag1==2)
						break;
				*/
