//�޸�
void Administrator_Modify()
{
	struct student *ptemp,*phead,*ptemp1,*phead1,*p,*p1;
	char name[20],id[10],mod_name[20],mod_id[10];
	int flag,flag1;
	int l=8,x=35,y=8;
	int i=0,t;
	char ch;
	float mod_score;
	FILE *fp,*fp1;
	while(1)
	{
		phead=Read_file();
		ptemp=phead;
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t1.����\t\t\t|\t||\n");//8
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t2.ѧ��\t\t\t|\t||\n");//11
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t0.����\t\t\t|\t||\n");//14
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(32,5);
		printf("ѡ���޸�����");
		goto_xy(x,y);
		printf("%c",16);
		flag=getch();
		if(flag==Down)
		{
			y=y+3;
			if(y==17)
				y=8;
		}
		if(flag==Up)
		{
			y=y-3;
			if(y==5)
				y=14;
		}
		if(flag==13)
		{
			if(y==8)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|                                               |\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
				printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
				printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");//12
				printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("���������󣬻س��޸���Ϣ");
				goto_xy(37,8);
				t=0;
				i=0;
				while((ch=getch())!='\r')
				{
					
					if(ch!='\b')
					{
						putchar(ch);
						name[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
						name[i]='\0';
					if(ch=='\b'&& i>0)
					{
						printf("\b \b");
						i--;
					} 
					if(i==6)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=5;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;

					}
					
				}
				name[i]='\0';
				getchar();
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->name,name)==0)			
					{
						break;
					}
					ptemp=ptemp->next ;
				}
			
				if(ptemp==NULL)
				{
					goto_xy(30,16);
					printf("No such person!\n");
					goto_xy(45,16);
					Sleep(800);
					break;
				}
				while(1)
				{
					phead1=Read_file();
					ptemp1=phead1;
					while(ptemp1!=NULL)
					{
						if(strcmp(ptemp1->name,ptemp->name)==0||strcmp(ptemp1->id,ptemp->id)==0)			
						{
							break;
						}
						ptemp1=ptemp1->next ;
					}
					ptemp=ptemp1;
					p1=Read_Password();
					p=p1;
					while(p!=NULL)
					{
						if(strcmp(p->name,name)==0)
							break;
						p=p->next;
					}
					system("cls");
					printf("\n\n");
					printf("\t ________________________________________________________________\n");//64
					printf("\t| ______________________________________________________________ |\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t _______________________________________________ \t||\n");
					printf("\t||\t|                                               |\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
					printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
					printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
					printf("\t||\t|_______________________________________________|\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||______________________________________________________________||\n");
					printf("\t|________________________________________________________________|\n");
					goto_xy(32,5);
					printf("���������󣬻س��޸���Ϣ");
					goto_xy(37,8);
					printf("%s",name);
					goto_xy(37,9);
					printf("%s",ptemp1->id );
					goto_xy(37,10);
					printf("%2.2f",ptemp1->chinese );
					goto_xy(37,11);
					printf("%2.2f",ptemp1->math );
					goto_xy(37,12);
					printf("%2.2f",ptemp1->english );
					goto_xy(39,13);
					printf("%2.2f",ptemp1->aver );
					goto_xy(30,l);
					printf("%c",16);
					flag1=getch();
					if(flag1==Down)
					{
						l++;
						if(l==15)
							l=8;
					}
					if(flag1==Up)
					{
						l--;
						if(l==7)
							l=14;
					}
					if(flag1==13)
					{
						if(l==8)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_name[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_name[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==6)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=5;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_name[i]='\0';
							strcpy(ptemp1->name,mod_name);
							strcpy(p->name,mod_name);
						}
						if(l==9)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_id[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_id[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==8)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=7;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_id[i]='\0';
							strcpy(ptemp1->id,mod_id);
							strcpy(p->id,mod_id);
						}
						if(l==10)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->chinese =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==11)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->math =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==12)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->english=mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==14)
							break;
				

						fp1=fopen("password.txt","w+");
						for(p1 ;p1!=NULL;p1=p1->next)
						{
							fprintf(fp1,"%s %s %s\n",p1->name,p1->id,p1->password);
						}
						fclose(fp1);
						fp=fopen("student.txt","w+");
						for(phead1 ;phead1!=NULL;phead1=phead1->next)
						{
							fprintf(fp,"%s %s %f %f %f %f\n",phead1->name,phead1->id,phead1->chinese,
								phead1->math,phead1->english,phead1->aver);
						}
						fclose(fp);
						fflush(stdin);
			
					}
				}
			}
			if(y==11)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|                                               |\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
				printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
				printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");//12
				printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("����ѧ�ź󣬻س��޸���Ϣ");
				goto_xy(37,9);
				t=0;
				i=0;
				while((ch=getch())!=13)
				{
					if(ch!='\b')
					{
						putchar(ch);
						id[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
					{
						id[0]='\0';
					}
					if(ch=='\b'&&i>0)
					{
						printf("\b \b");
						i--;
					}
					if(i==8)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=7;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;
					}
				}
				id[i]='\0';
				getchar();
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->id,id)==0)			
					{
						break;
					}
					ptemp=ptemp->next ;
				}
				if(ptemp==NULL)
				{
					goto_xy(30,16);
					printf("No such person!\n");
					goto_xy(45,16);
		
					Sleep(800);
					break;
				}
				while(1)
				{
					phead1=Read_file();
					ptemp1=phead1;
					while(ptemp1!=NULL)
					{
						if(strcmp(ptemp1->id,ptemp->id )==0||strcmp(ptemp1->name,ptemp->name )==0)			
						{
							break;
						}
						ptemp1=ptemp1->next ;
					}
					ptemp=ptemp1;
					p1=Read_Password();
					p=p1;
					while(p!=NULL)
					{
						if(strcmp(p->id,id)==0)
							break;
						p=p->next;
					}
					system("cls");
					printf("\n\n");
					printf("\t ________________________________________________________________\n");//64
					printf("\t| ______________________________________________________________ |\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t _______________________________________________ \t||\n");
					printf("\t||\t|                                               |\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
					printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
					printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
					printf("\t||\t|_______________________________________________|\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||______________________________________________________________||\n");
					printf("\t|________________________________________________________________|\n");
					goto_xy(32,5);
					printf("����ѧ�ź󣬻س��޸���Ϣ");
					goto_xy(37,8);
					printf("%s",ptemp1->name );
					goto_xy(37,9);
					printf("%s",id );
					goto_xy(37,10);
					printf("%2.2f",ptemp1->chinese );
					goto_xy(37,11);
					printf("%2.2f",ptemp1->math );
					goto_xy(37,12);
					printf("%2.2f",ptemp1->english );
					goto_xy(39,13);
					printf("%2.2f",ptemp1->aver );
					goto_xy(30,l);
					printf("%c",16);
					flag1=getch();
					if(flag1==Down)
					{
						l++;
						if(l==15)
							l=8;
					}
					if(flag1==Up)
					{
						l--;
						if(l==7)
							l=14;
					}
					if(flag1==13)
					{
						if(l==8)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_name[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_name[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==6)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=5;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_name[i]='\0';
							strcpy(ptemp1->name,mod_name);
							strcpy(p->name,mod_name);
						}
						if(l==9)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_id[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_id[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==8)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=7;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_id[i]='\0';
							strcpy(ptemp1->id,mod_id);
							strcpy(p->id,mod_id);
						}
						if(l==10)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->chinese =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==11)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->math =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==12)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->english=mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==14)
							break;
						fp1=fopen("password.txt","w+");
						for(p1 ;p1!=NULL;p1=p1->next)
						{
							fprintf(fp1,"%s %s %s\n",p1->name,p1->id,p1->password);
						}
						fclose(fp1);
						fp=fopen("student.txt","w+");
						for(phead1 ;phead1!=NULL;phead1=phead1->next)
						{
							fprintf(fp,"%s %s %f %f %f %f\n",phead1->name,phead1->id,phead1->chinese
								,phead1->math,phead1->english,phead1->aver);
						}
						fclose(fp);
					}
				}
			}
			if(y==14)
				break;
		}
	}
}
