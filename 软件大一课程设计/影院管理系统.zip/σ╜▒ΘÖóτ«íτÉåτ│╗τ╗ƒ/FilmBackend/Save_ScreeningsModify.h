void Save_ScreeningsModify(struct film *phead)
{
	struct film *ptemp=phead,*t;
	FILE *fp;
	fp=fopen("/Users/wyz/Desktop/影院管理系统/文件/screenings.txt","w+");
	while(ptemp!=NULL)
	{
		fprintf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",ptemp->name,
			ptemp->director,ptemp->actor,ptemp->type,ptemp->score,
			ptemp->time,ptemp->price,ptemp->year,ptemp->month,
			ptemp->day);
		t=ptemp;
		t=t->link;
		
		for(;t!=NULL;t=t->link)
		{
			fprintf(fp,"%f %f %d\n",t->start_time,t->end_time,
				t->movieroom);
		}
		fprintf(fp,"%f %f %d\n",0.0,0.0,0);
		ptemp=ptemp->next;
	}
	fclose(fp);
}

