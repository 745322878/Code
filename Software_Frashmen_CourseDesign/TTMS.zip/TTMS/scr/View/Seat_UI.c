/*
 * Seat_UI.c
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include "Seat_UI.h"
#include "../TTMS/scr/Service/Seat_Srv.h"
#include "../TTMS/scr/Service/Studio_Srv.h"
#include "../TTMS/scr/Service/EntityKey.h"
#include "../TTMS/scr/Persistence/EntityKey_Persist.h"
#include "../TTMS/scr/Common/List.h"
#include <stdio.h>

//座位管理界面
void Seat_UI_MgtEntry(int roomID) {

    //函数实现部分
    seat_list_t     list;
    studio_t        data;
    seat_node_t     *p;
    int             Snumber,i,pageSize = 15;
    Pagination_t    paging;
    char            choice;
    
    List_Init(list,seat_node_t);
    
    if(Srv_FetchByID(roomID,&data))
    {
        Snumber = Seat_Srv_FetchByRoomID(list,roomID);
        if (Snumber)
        {
            paging.totalRecords = Snumber;
            paging.pageSize = pageSize;
            Paging_Locate_FirstPage(list,paging);           //定位到第一页

            do {
                system("clear");
                printf("========================= 座位 ==========================\n");
                printf("座位ID\t演出厅ID\t座位行号\t列号\t\t座位状态\n");
                printf("--------------------------------------------------------------\n");
                for (i = 0, p = (seat_node_t *) (paging.curPos); //当前页面的起始位置
                        p != list && i < paging.pageSize; i++,p = p->next) {
                    printf("%d%15d%8d%8d%15c\n", p->data.id, p->data.roomID,
                            p->data.row, p->data.column,
                            Seat_UI_Status2Char(p->data.status));
                }
                printf("--总记录:%2d -------------------- 页 %2d/%2d --\n",
                        paging.totalRecords, Pageing_CurPage(paging),
                        Pageing_TotalPages(paging));
                printf(" [P]上一页 | [N]下一页 | [A]增加  |  [D]删除  |  [U]更新  ｜  ［R］返回\n");
                printf("  \n");
                printf("==============================================================\n");
                printf("Your Choice:");
                while(getchar() != '\n');
                scanf("%c", &choice);
                
                switch (choice) {
                    case 'a':
                    case 'A':
                        if (Seat_UI_Add(list, roomID, data.linesCount, data.colsCount)) {
                            paging.totalRecords = Seat_Srv_FetchByRoomID(list,roomID);
                            Paging_Locate_LastPage(list, paging, seat_node_t);    //定位到最后一页
                        }
                        break;
                    case 'd':
                    case 'D':
                        if (Seat_UI_Delete(list, data.linesCount, data.colsCount)) {
                            paging.totalRecords = Seat_Srv_FetchByRoomID(list,roomID);
                            List_Paging(list, paging, seat_node_t);
                        }
                        break;
                    case 'u':
                    case 'U':
                        if (Seat_UI_Modify(list, data.linesCount, data.colsCount)) {
                            paging.totalRecords = Seat_Srv_FetchByRoomID(list,roomID);
                            List_Paging(list, paging, seat_node_t);
                        }
                        break;
                    case 'p':
                    case 'P':
                        if (1 < Pageing_CurPage(paging)) {
                            Paging_Locate_OffsetPage(list, paging, -1, seat_node_t); //前移
                        }
                        break;
                    case 'n':
                    case 'N':
                        if (Pageing_TotalPages(paging) > Pageing_CurPage(paging)) {
                            Paging_Locate_OffsetPage(list, paging, 1, seat_node_t);  //后移
                        }
                        break;
                }
//                data.seatsCount = Seat_Srv_FetchByRoomID(list,roomID);
//                Srv_Mod(&data);
            } while (choice != 'r' && choice != 'R');
            data.seatsCount = Seat_Srv_FetchByRoomID(list,roomID);
            Srv_Mod(&data);
        }
        else
        {
            Seat_Srv_RoomInit(list,roomID,data.linesCount,data.colsCount);
            data.seatsCount = Seat_Srv_FetchByRoomID(list,roomID);
            Srv_Mod(&data);
            printf("初始化座位成功!\n");
            sleep(1);
        }
    }
    List_Destroy(list,seat_node_t);
}

//根据座位状态获取界面显示符号
char Seat_UI_Status2Char(seat_status_t status) {

    //函数实现部分
    if (status == 0) {
        return ' ';
    }
    else if(status == 1){
        return '*';
    }
    else if(status == 9){
        return '~';
    }
}

//根据界面显示符号获取座位状态
seat_status_t Seat_UI_Char2Status(char statusChar) {

    //函数实现部分
    if (statusChar == ' ') {
        return 0;
    }
    else if(statusChar =='*'){
        return 1;
    }
    else if(statusChar == '~'){
        return 9;
    }
}

//添加演出厅新座位界面
int Seat_UI_Add(seat_list_t list, int roomID, int rowsCount,int colsCount) {

    //函数实现部分
    int         newCount = 0;
    int         key;
    char        choice;
    seat_t      pnew;
    printf("========================== 座位添加 ============================\n");
    do{
        //pnew = (studio_t *)malloc(sizeof(studio_t));
        do{
            printf("请输入行数:");
            scanf("%d",&pnew.row);
            printf("请输入列数:");
            scanf("%d",&pnew.column);
        }while (pnew.row > rowsCount+1 || pnew.column > colsCount+1);
        if(!(Seat_Srv_FindByRowCol(list,pnew.row,pnew.column)))
        {
            key = EntKey_Perst_GetNewKeys("seat",1); //主键服务
            pnew.id = key;
            printf("(0.🈳  1.🈶  9.损坏)\n");
            printf("请输入该座位的状态:");
            scanf("%d",&pnew.status);
            pnew.roomID = roomID;
            if (Seat_Srv_Add(&pnew)) {
                printf("添加成功!!\n");
                newCount++;
                sleep(1);
            }
            else
            {
                printf("添加失败!\n");
                sleep(1);
            }
            printf("继续? (y/n):");
            getchar();
            scanf("%c",&choice);
        }
        else
        {
            printf("座位已存在!!\n");
            sleep(1);
            continue;
        }
    }while (choice == 'y' || choice == 'Y');
    return newCount;
}

//根据id修改座位状态界面
int Seat_UI_Modify(seat_list_t list, int rowsCount, int colsCount) {

    //函数实现部分
    int             rtn = 0;
    int             row,   cols;
    seat_node_t     *temp;
    seat_t          data;
    printf("========================= 座位更新 =========================\n");
    while(1){
        do{
            printf("请输入行号:");
            scanf("%d",&row);
            printf("请输入列号:");
            scanf("%d",&cols);
        }while (row > rowsCount+1 || cols > colsCount+1);
    
        temp = Seat_Srv_FindByRowCol(list,row,cols);
        if (temp) {
            printf("(0.🈳  1.🈶  9.损坏)\n");
            printf("请输入改座位状态:");
            scanf("%d",&temp->data.status);
            data = temp->data;
            if (Seat_Srv_Modify(&data)) {
                rtn = 1;
                printf("更新成功!\n");
                sleep(1);
                return rtn;
            }
            else
            {
                printf("更新失败!\n");
                sleep(1);
                return rtn;
            }
        }
        else
        {
            printf("座位早已存在!!\n");
        }
    }
}

//根据ID删除座位界面
int Seat_UI_Delete(seat_list_t list, int rowsCount, int colsCount) {
    
    //函数实现部分
    int             rtn = 0;
    int             row,cols;
    seat_node_t     *temp;
    printf("========================= 座位删除 ==========================\n");
    while(1){
        do{
            printf("请输入行号:");
            scanf("%d",&row);
            printf("请输入列号:");
            scanf("%d",&cols);
        }while (row > rowsCount+1 || cols > colsCount+1);

        temp = Seat_Srv_FindByRowCol(list,row,cols);
        if (temp) {
            if(Seat_Srv_DeleteByID(temp->data.id))
            {
                rtn = 1;
                printf("删除成功!\n");
                sleep(1);
                return rtn;
            }
            else
            {
                printf("删除失败!\n");
                sleep(1);
                return rtn;
            }
        }
        else
        {
            printf("该座位早已存在!!\n");
        }
    }
}