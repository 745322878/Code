//��ȡ�ļ�
struct student *Read_file()
{
	
	struct student *ptemp,*phead,*r;
	FILE *fp;
	
	fp=fopen("student.txt","rt");
	if(fp==NULL)
	{
		return NULL;
	}
	phead=(struct student *)malloc(sizeof(struct student));
	phead->next=NULL;
	r=phead;
	while(!feof(fp))
	{
		ptemp=(struct student *)malloc(sizeof(struct student));
		fscanf(fp,"%s %s %f %f %f %f\n",ptemp->name,ptemp->id,&ptemp->chinese,&ptemp->math,&ptemp->english,&ptemp->aver);
		r->next=ptemp;
		r=ptemp;
	}
	r->next=NULL;

	fclose(fp);
	phead=phead->next ;
	
	return phead;
}