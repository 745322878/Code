/*
 * Studio_Srv.c
 *
 * Created on: 2015年6月25日
 *  Author on: Tang-tang
 */

#include "Studio_Srv.h"
#include "../TTMS/scr/Persistence/Studio_Perst.h"

//添加新演出厅的业务逻辑层函数实现部分
int Srv_Add(const studio_t *data) {
    
    //函数实现
    int rtn;
    rtn = Studio_Perst_Insert(data);
    return rtn;
}


//修改演出厅的业务逻辑层函数实现部分
int Srv_Mod(const studio_t *data) {
    
    //函数实现部分
    int rtn;
    rtn = Studio_Perst_Update(data);
    return rtn;
}

//根据ID删除演出厅业务逻辑层的函数实现部分
int Srv_Del(int id) {
    
    //函数实现
    int rtn;
    rtn = Studio_Perst_DeleteByID(id);
    return rtn;
}

//获取所有演出厅个数的实现部分
int Studio_Srv_FetchAll(studio_list_t list) {
    
    //函数实现部分
    int icount;
    icount = Studio_Perst_SelectAll(list);
    
    return icount;
}

//根据ID获取演出厅业务逻辑层的函数实现部分
int Srv_FetchByID(int id,studio_t *buf) {
    
    //函数实现部分
    int icount;
    icount = Studio_Perst_SelectByID(id,buf);
    
    return icount;
}

//根据ID在链表list中查找对应的放映厅节点
studio_node_t *Srv_FindByID(studio_list_t list,int id) {

    //函数实现部分
    studio_node_t *ptr;
    if (List_IsEmpty(list)) {
        return NULL;
    }
    else
    {
        ptr = list -> next;
        while (ptr != list) {
            if (ptr->data.id == id) {
                return ptr;
            }
            else
            {
                ptr = ptr -> next;
            }
        }
        return NULL;
    }
}