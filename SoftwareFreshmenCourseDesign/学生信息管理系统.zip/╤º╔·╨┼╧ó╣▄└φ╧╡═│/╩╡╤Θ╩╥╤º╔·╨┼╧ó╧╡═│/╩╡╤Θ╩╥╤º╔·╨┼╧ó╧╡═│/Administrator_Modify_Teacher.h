
void Administrator_Modify_Teacher()
{
	struct student *ptemp,*phead,*ptemp1,*phead1;
	char name[20],id[10],mod_name[20],mod_id[10];
	int flag,flag1;
	int l=9,x=35,y=8,i=0,t;
	char ch;
	FILE *fp;
	while(1)
	{
		phead=Read_Teacher_Password();
		ptemp=phead;
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t1.����\t\t\t|\t||\n");//8
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t2.�˺�\t\t\t|\t||\n");//11
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t0.����\t\t\t|\t||\n");//14
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(32,5);
		printf("ѡ���޸�����");
		goto_xy(x,y);
		printf("%c",16);
		flag=getch();
		if(flag==Down)
		{
			y=y+3;
			if(y==17)
				y=8;
		}
		if(flag==Up)
		{
			y=y-3;
			if(y==5)
				y=14;
		}
		if(flag==13)
		{
			if(y==8)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//9
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t�ʺ�:\t\t\t\t|\t||\n");//11
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����\t\t\t\t|\t||\n");//13
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("����������ѡ���޸����ݣ��س��޸�");
				goto_xy(37,l);
				t=0;
				i=0;
				while((ch=getch())!='\r')
				{
					
					if(ch!='\b')
					{
						putchar(ch);
						name[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
						name[i]='\0';
					if(ch=='\b'&& i>0)
					{
						printf("\b \b");
						i--;
					} 
					if(i==6)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=5;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;

					}
					
				}
				name[i]='\0';
				getchar();
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->name,name)==0)			
					{
						break;
					}
					ptemp=ptemp->next ;
				}
				if(ptemp==NULL)
				{
					goto_xy(30,17);
					printf("No such person!\n");
					goto_xy(45,17);
					Sleep(800);
					break;
				}
				while(1)
				{
					phead1=Read_Teacher_Password();
					ptemp1=phead1;
					while(ptemp1!=NULL)
					{
						if(strcmp(ptemp1->name,ptemp->name)==0||strcmp(ptemp1->id,ptemp->id)==0)			
						{
							break;
						}
						ptemp1=ptemp1->next ;
					}
					ptemp=ptemp1;
					system("cls");
					printf("\n\n");
					printf("\t ________________________________________________________________\n");//64
					printf("\t| ______________________________________________________________ |\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t _______________________________________________ \t||\n");
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//9
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t�ʺ�:\t\t\t\t|\t||\n");//11
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����\t\t\t\t|\t||\n");//13
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|_______________________________________________|\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||______________________________________________________________||\n");
					printf("\t|________________________________________________________________|\n");
					goto_xy(32,5);
					printf("����������ѡ���޸����ݣ��س��޸�");
					goto_xy(37,9);
					printf("%s",name);
					goto_xy(37,11);
					printf("%s",ptemp1->id );
					goto_xy(30,l);
					printf("%c",16);
					fflush(stdin);
					flag1=getch();
					if(flag1==Down)
					{
						l=l+2;
						if(l==15)
							l=9;
					}
					if(flag1==Up)
					{
						l=l-2;
						if(l==7)
							l=13;
					}
					if(flag1==13)
					{
						if(l==9)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_name[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_name[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==6)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=5;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_name[i]='\0';
							strcpy(ptemp1->name,mod_name);
						}
						if(l==11)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_id[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_id[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==8)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=7;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_id[i]='\0';
							strcpy(ptemp1->id,mod_id);
						}
						if(l==13)
							break;
						fp=fopen("teacher_password.txt","w");
						for(phead1 ;phead1!=NULL;phead1=phead1->next)
						{
							fprintf(fp,"%s %s %s\n",phead1->name,phead1->id,phead1->password );
						}
						fclose(fp);
					}
					
				}
			}
			if(y==11)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//9
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t�˺�:\t\t\t\t|\t||\n");//11
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����\t\t\t\t|\t||\n");//13
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("�����˺ţ�ѡ���޸����ݣ��س��޸�");
				goto_xy(37,11);
				t=0;
				i=0;
				while((ch=getch())!=13)
				{
					if(ch!='\b')
					{
						putchar(ch);
						id[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
					{
						id[0]='\0';
					}
					if(ch=='\b'&&i>0)
					{
						printf("\b \b");
						i--;
					}
					if(i==8)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=7;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;
					}
				}
				id[i]='\0';
				getchar();
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->id,id)==0)			
					{
						break;
					}
					ptemp=ptemp->next ;
				}
				if(ptemp==NULL)
				{
					goto_xy(30,17);
					printf("No such person!\n");
					goto_xy(45,17);
		
					Sleep(800);
					break;
				}
				while(1)
				{
					phead1=Read_Teacher_Password();
					ptemp1=phead1;
					while(ptemp1!=NULL)
					{
						if(strcmp(ptemp1->id,ptemp->id)==0||strcmp(ptemp1->name,ptemp->name)==0)			
						{
							break;
						}
						ptemp1=ptemp1->next ;
					}
					ptemp=ptemp1;
					system("cls");
					printf("\n\n");
					printf("\t ________________________________________________________________\n");//64
					printf("\t| ______________________________________________________________ |\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t _______________________________________________ \t||\n");
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//9
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t�ʺ�:\t\t\t\t|\t||\n");//11
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����\t\t\t\t|\t||\n");//13
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t\t\t\t\t|\t||\n");
					printf("\t||\t|_______________________________________________|\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||______________________________________________________________||\n");
					printf("\t|________________________________________________________________|\n");
					goto_xy(32,5);
					printf("�����˺ţ�ѡ���޸����ݣ��س��޸�");
					goto_xy(37,9);
					printf("%s",ptemp1->name );
					goto_xy(37,11);
					printf("%s",id );
					goto_xy(30,l);
					printf("%c",16);
					flag1=getch();
					if(flag1==Down)
					{
						l=l+2;
						if(l==15)
							l=9;
					}
					if(flag1==Up)
					{
						l=l-2;
						if(l==7)
							l=13;
					}
					if(flag1==13)
					{
						if(l==9)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_name[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_name[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==6)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=5;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_name[i]='\0';
							strcpy(ptemp1->name,mod_name);
						}
						if(l==11)
						{
							goto_xy(46,l);
							t=0;
							i=0;
							while((ch=getch())!='\r')
							{
								
								if(ch!='\b')
								{
									putchar(ch);
									mod_id[i]=ch;
									i++;
								}
								if(ch=='\b'&&i==0)
									mod_id[i]='\0';
								if(ch=='\b'&& i>0)
								{
									printf("\b \b");
									i--;
								} 
								if(i==8)
								{
									while((ch=getch())!='\r')
									{
										if(ch=='\b')
										{
											printf("\b \b");
											i=7;
											t=1;
											break;
										}
									}
									if(t==1)
										continue;
									break;

								}
								
							}
							mod_id[i]='\0';
							strcpy(ptemp1->id,mod_id);
						}
						if(l==13)
							break;
						fp=fopen("teacher_password.txt","w");
						for(phead1 ;phead1!=NULL;phead1=phead1->next)
						{
							fprintf(fp,"%s %s %s\n",phead1->name,phead1->id,phead1->password );
						}
						fclose(fp);
					}
				}
			}
			if(y==14)
				break;
		}	
	}
}
					
	

			
