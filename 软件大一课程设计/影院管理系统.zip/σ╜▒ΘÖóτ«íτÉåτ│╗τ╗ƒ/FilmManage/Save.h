void save_movie(struct readFilm *head,int n,struct readSe *shead,int i)
{
    FILE *fp;
    fp = fopen("movieTicket.txt","a+");
    if(fp == NULL)
    {
        mvprintw(10,40,"保存失败！");
        endwin();
        exit(0);
    }
    fscanf(fp,"%s %f  %f \n",head->a[n],shead->start[i],shead->end[i]);
    fclose(fp);
}