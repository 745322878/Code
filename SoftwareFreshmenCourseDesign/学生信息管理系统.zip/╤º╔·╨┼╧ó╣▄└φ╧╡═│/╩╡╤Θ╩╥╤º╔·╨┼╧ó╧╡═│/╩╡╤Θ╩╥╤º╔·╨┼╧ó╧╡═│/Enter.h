
struct student *Enter()
{
	struct student *ptemp,*phead;
	int choice=0,flag;
	int x=35,y=8,t=0,i=0;
	char ch;
	char name[20],id[10];
	float chinese,math,english;
	FILE *fp;
	while(1)
	{
		phead=Read_file();
		ptemp=phead;
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t1.����\t\t\t|\t||\n");//8
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t2.ѧ��\t\t\t|\t||\n");//11
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t0.����\t\t\t|\t||\n");//14
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(32,5);
		printf("��ѡ��¼������");
		goto_xy(x,y);
		printf("%c",16);
		flag=getch();
		if(flag==Down)
		{
			y=y+3;
			if(y==17)
				y=8;
		}
		if(flag==Up)
		{
			y=y-3;
			if(y==5)
				y=14;
		}

		if(flag==13)
		{
			if(y==8)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
			
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|                                               |\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
				printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");//13
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");//14
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("��������¼��ɼ�");
				goto_xy(37,8);
				t=0;
				i=0;
				while((ch=getch())!='\r')
				{
					
					if(ch!='\b')
					{
						putchar(ch);
						name[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
						name[i]='\0';
					if(ch=='\b'&& i>0)
					{
						printf("\b \b");
						i--;
					} 
					if(i==6)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=5;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;

					}
					
				}
				name[i]='\0';
				fflush(stdin);
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->name,name)==0)
					{
						
						goto_xy(37,9);
						printf("%s\n",ptemp->id );
						goto_xy(37,10);
						scanf("%f",&chinese );
						getchar();
						ptemp->chinese =chinese;
						goto_xy(37,11);
						scanf("%f",&math );
						ptemp->math =math;
						goto_xy(37,12);
						scanf("%f",&english );
						ptemp->english  =english;
						ptemp->aver=(chinese +math+english)/3;
						goto_xy(39,13);
						printf("%2.2f",ptemp->aver);
						Sleep(1000);
						break;
					}
					ptemp=ptemp->next;
				}
				fp=fopen("student.txt","w");
				for(phead ;phead!=NULL;phead=phead->next)
				{
					fprintf(fp,"%s %s %f %f %f %f\n",phead->name,phead->id,phead->chinese,phead->math,phead->english,phead->aver);
				}
				fclose(fp);
				if(ptemp==NULL)
				{
					goto_xy(30,16);
					printf("No such person!\n");
					goto_xy(45,16);
					choice=1;
					Sleep(1000);
				}
			}
			if(y==11)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
			
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|                                               |\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
				printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");//13
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");//14
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("����ѧ��¼��ɼ�");
				goto_xy(37,9);
				t=0;
				i=0;
				while((ch=getch())!=13)
				{
					if(ch!='\b')
					{
						putchar(ch);
						id[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
					{
						id[0]='\0';
					}
					if(ch=='\b'&&i>0)
					{
						printf("\b \b");
						i--;
					}
					if(i==8)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=7;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;
					}
				}
				id[i]='\0';
				fflush(stdin);
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->id,id)==0)
					{
						
						goto_xy(37,8);
						printf("%s\n",ptemp->name );
						goto_xy(37,10);
						scanf("%f",&chinese );
						getchar();
						ptemp->chinese =chinese;
						goto_xy(37,11);
						scanf("%f",&math );
						ptemp->math =math;
						goto_xy(37,12);
						scanf("%f",&english );
						ptemp->english  =english;
						ptemp->aver=(chinese +math+english)/3;
						goto_xy(39,13);
						printf("%2.2f",ptemp->aver);
						Sleep(1000);
						break;
					}
					ptemp=ptemp->next;
				}
				fp=fopen("student.txt","w");
				for(phead ;phead!=NULL;phead=phead->next)
				{
					fprintf(fp,"%s %s %f %f %f %f\n",phead->name,phead->id,phead->chinese,phead->math,phead->english,phead->aver);
				}
				fclose(fp);
				if(ptemp==NULL)
				{
					goto_xy(30,16);
					printf("No such person!\n");
					choice=1;
					goto_xy(45,16);
					Sleep(1000);
				}
				
			}
			if(y==14)
			{
				break;
			}
		}
	}
	Sleep(1000);
	return phead;
}