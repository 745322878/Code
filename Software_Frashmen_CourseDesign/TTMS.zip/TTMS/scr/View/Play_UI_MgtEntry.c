/*
 * Play_UI_MgtEntry.c
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include "Play_UI_MgtEntry.h"
//#include "Schedule_UI.h"

#include "../TTMS/scr/Common/List.h"
#include "../TTMS/scr/Service/Play.h"
#include "../TTMS/scr/Service/EntityKey.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//主界面函数
void Play_UI_MgtEnt(void) {

    //函数实现部分
    play_list_t     list;
    play_node_t     *p;
    int             Snumber,i,pageSize;
    Pagination_t    paging;
    char            choice;
    int             id;
    play_t          buf;
    
    List_Init(list,play_node_t);
    
    Snumber = Play_Srv_FetchAll(list);
    
    do{
        printf("请输入每页个数:");
        scanf("%d",&pageSize);
    }while (pageSize <= 0);
    
    paging.totalRecords = Snumber;
    paging.pageSize = pageSize;
    Paging_Locate_FirstPage(list,paging);           //定位到第一页
    
    do {
        system("clear");
        printf("==================================== 演出计划========================================\n");
        printf("剧目id\t剧目名称\t剧目类型\t剧目出品地区\t剧目等级\t开始放映日期\t放映结束日期\t票价\n");
        printf("---------------------------------------------------------------------------------------\n");
        for (i = 0, p = (play_node_t *) (paging.curPos); //当前页面的起始位置
             p != list && i < paging.pageSize; i++) {
            printf("%d\t%s\t%s\t%s\t%s\t%d\t\t%d.%d.%d\t%d.%d.%d\t%d\n", p->data.id, p->data.name,
                   (p->data.type == 1)?"film":(p->data.type == 2?"opear":"concert"),
                   p->data.area,
                   (p->data.rating == 1)?"child":(p->data.rating == 2?"teenage":"adult"),
                   p->data.duration,
                   p->data.start_date.year,p->data.start_date.month,p->data.start_date.day,
                   p->data.end_date.year,p->data.end_date.month,p->data.end_date.day,
                   p->data.price);
            p=p->next;
        }
        printf("--总记录:%2d --------- 页 %2d/%2d --\n",
               paging.totalRecords, Pageing_CurPage(paging),
               Pageing_TotalPages(paging));
        
        printf("[P]前一页 | [N]下一页 | [A]增加 |  [D]删除  |  [U]更新 | [S]场次 ｜［R]返回 \n   ");
        printf("=======================================================================================\n");
        printf("请选择:");
        while(getchar() != '\n');
        scanf("%c", &choice);
        
        switch (choice) {
            case 's':
            case 'S':
                printf("请输入演出计划ID:");
                scanf("%d",&id);
                if (Play_Perst_SelectByID(id,&buf)) {
                    Schedule_UI_MgtEntry(id);
                }
                else
                {
                    printf("该演出计划不存在！！");
                    sleep(1);
                }
                break;
            case 'a':
            case 'A':
                if (Play_UI_Add()) {
                    paging.totalRecords = Play_Srv_FetchAll(list);
                    Paging_Locate_LastPage(list, paging, play_node_t);    //定位到最后一页
                }
                break;
            case 'd':
            case 'D':
                printf("请输入ID:");
                scanf("%d",&id);
                if (Play_UI_Delete(id)) {
                    paging.totalRecords = Play_Srv_FetchAll(list);
                    List_Paging(list, paging, play_node_t);
                }
                break;
            case 'u':
            case 'U':
                printf("请输入ID:");
                scanf("%d",&id);
                if (Play_UI_Modify(id)) {
                    paging.totalRecords = Play_Srv_FetchAll(list);
                    List_Paging(list, paging, play_node_t);
                }
                break;
            case 'p':
            case 'P':
                if (1 < Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, -1, play_node_t); //前移
                }
                break;
            case 'n':
            case 'N':
                if (Pageing_TotalPages(paging) > Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, 1, play_node_t);  //后移
                }
                break;
        }
        
    } while (choice != 'r' && choice != 'R');
    
    List_Destroy(list,play_node_t);
}

//添加剧目界面
int Play_UI_Add(void) {

    //函数实现部分
    int     newCount = 0;
    int     key;
    char    choice;
    play_t  pnew;
    printf("======================= 演出计划增加========================\n");
    do{
        //pnew = (studio_t *)malloc(sizeof(studio_t));
        printf("请输入演出计划ID:\n");
        //fflush(stdin);
        scanf("%s",pnew.name);
        printf("(1.电影  2.话剧  3.音乐会）\n");
        printf("请输入演出类型:");
        scanf("%d",&pnew.type);
        printf("请输入演出地区:\n");
        scanf("%s",pnew.area);
        printf("(1.孩子  2.青年  3.成年)\n");
        printf("请输入演出等级:\n");
        scanf("%d",&pnew.rating);
        printf("请输入演出时长 (minute):");
        scanf("%d",&pnew.duration);
        printf("请输入演出开始日期 (like 2015 06 29):\n");
        scanf("%d %d %d",&pnew.start_date.year, &pnew.start_date.month, &pnew.start_date.day);
        printf("请输入演出结束日期 (like 2015 06 29):\n");
        scanf("%d %d %d",&pnew.end_date.year, &pnew.end_date.month, &pnew.end_date.day);
        printf("请输入演出票价:");
        scanf("%d",&pnew.price);
        key = EntKey_Srv_CompNewKey("play"); //主键服务
        pnew.id = key;
        if (Play_Srv_Add(&pnew)) {
            printf("添加成功!!\n");
            newCount++;
            printf("继续? (y/n):");
            getchar();
            scanf("%c",&choice);
        }
        else
        {
            printf("添加失败!\n");
            sleep(1);
            return newCount;
        }
    }while (choice == 'y' || choice == 'Y');
    return newCount;
}

//修改剧目界面
int Play_UI_Modify(int id) {

    //函数实现部分
    int     rtn = 0;
    play_t  temp;
    printf("========================= 演出计划更新=========================\n");
    if (Play_Srv_FetchByID(id,&temp)) {
        printf("--------------------------- 旧计划----------------------------\n");
        printf("ID: \t%d\n",temp.id);
        printf("剧目名称: \t%s\n",temp.name);
        printf("类型: \t%s\n",(temp.type == 1)?"film":(temp.type == 2?"opear":"concert"));
        printf("地区: \t%s\n",temp.area);
        printf("等级: \t%s\n",(temp.rating == 1)?"child":(temp.rating == 2?"teenage":"adult"));
        printf("时长: \t%d\n",temp.duration);
        printf("开始时间: \t%d %d %d\n", temp.start_date.year, temp.start_date.month, temp.start_date.day);
        printf("结束时间: \t%d %d %d\n",temp.end_date.year, temp.end_date.month, temp.end_date.day);
        printf("价格: \t%d\n",temp.price);
        printf("--------------------------- 新演出计划----------------------------\n");
        printf("请输入新演出计划名:\n");
        //fflush(stdin);
        scanf("%s",temp.name);
        printf("(1.电影  2.话剧  3.音乐会)\n");
        printf("请输入新演出计划类型:");
        scanf("%d",&temp.type);
        printf("请输入新演出计划地区:\n");
        scanf("%s",temp.area);
        printf("(1.孩子 2.青年 3.成年)\n");
        printf("请输入等级:\n");
        scanf("%d",&temp.rating);
        printf("请输入时长 (minute):");
        scanf("%d",&temp.duration);
        printf("请输入影片开始日期 (like 2015 06 29):\n");
        scanf("%d %d %d",&temp.start_date.year, &temp.start_date.month, &temp.start_date.day);
        printf("请输入影片结束日期 (like 2015 06 29):\n");
        scanf("%d %d %d",&temp.end_date.year, &temp.end_date.month, &temp.end_date.day);
        printf("请输入新演出计划票价:");
        scanf("%d",&temp.price);
        if (Play_Srv_Modify(&temp)) {
            rtn = 1;
            printf("更新成功!\n");
        }
        else
        {
            printf("更新失败!\n");
        }
    }
    else
    {
        printf("请按任意键退出！");
        getchar();
        return 0;
    }
    sleep(1);
    return rtn;

}

//删除剧目界面
int Play_UI_Delete(int id) {

    //函数实现部分
    int rtn = 0;
    printf("========================= 演出计划删除 =========================\n");
    if (Play_Srv_DeleteByID(id)) {
        rtn = 1;
        printf("删除成功!\n");
    }
    else
    {
        printf("删除失败!\n");
    }
    sleep(1);
    return rtn;
}

//查询剧目界面
int Play_UI_Query(int id) {

    //函数实现部分
    int     rtn = 0;
    play_t  buf;
    if (Play_Srv_FetchByID(id,&buf)) {
        rtn = 1;
        printf("=========================== 剧目信息 ===========================\n");
        printf("剧目ID\t剧目名称\t类型\t地区\t等级\t时长\t开始时间\t结束时间\t价格\n");
        printf("-----------------------------------------------------------------------\n");
        printf("%d\t%s\t%s\t%s\t%s\t%d\t%d.%d.%d\t%d.%d.%d\t%d\n", buf.id, buf.name,
               (buf.type == 1)?"film":(buf.type == 2?"opear":"concert"),
               buf.area,
               (buf.rating == 1)?"child":(buf.rating == 2?"teenage":"adult"),
               buf.duration,
               buf.start_date.year, buf.start_date.month, buf.start_date.day,
               buf.end_date.year, buf.end_date.month, buf.end_date.day,
               buf.price);
        printf("-----------------------------------------------------------------------\n");
        //printf("Automatically jump to the performance plan management layer!!");
        printf("请按任意键返回!!");
        while(getchar() != '\n');
    }
    else
    {
        printf("没有次演出计划!!");
        sleep(1);
        
    }
    return rtn;
}

/*
//以列表形式显示剧目信息
void Play_UI_ShowList(play_list_t list, Pagination_t paging) {

    //函数实现部分
}
*/