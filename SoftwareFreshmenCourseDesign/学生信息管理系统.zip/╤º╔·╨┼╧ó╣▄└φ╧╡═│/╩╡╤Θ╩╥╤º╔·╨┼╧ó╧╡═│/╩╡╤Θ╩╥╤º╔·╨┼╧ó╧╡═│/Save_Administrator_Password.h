
void Save_Administrator_Password(struct student *phead)
{		
		struct student *ptemp=phead;
		FILE *fp;
		fp=fopen("administrator_password.txt","w");
		for(ptemp;ptemp!=NULL;ptemp=ptemp->next )
		{
			fprintf(fp,"%s\n",ptemp->password );
		}
		fclose(fp);
}
