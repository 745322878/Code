void Modify()
{
	struct film  *phead=Read_file();
	struct film *ptemp=phead;
	char name[20];
	int flag;
	int line=6,i;
	echo();
	curs_set(1);
	clear();
	mvprintw(3,32,"修改影片信息");
	mvchgat(2,23,30,A_NORMAL,2,NULL);
	mvchgat(3,23,30,A_NORMAL,2,NULL);
	mvchgat(4,23,30,A_NORMAL,2,NULL);
	
	attron(A_BOLD);
	mvprintw(8,30,"请输入影片名称：");
	attroff(A_BOLD);
	mvchgat(9,30,16,A_NORMAL,7,NULL);
	move(9,30);
	attron(A_BOLD|COLOR_PAIR(7));
	scanw("%s",name);
	attroff(A_BOLD|COLOR_PAIR(7));
	curs_set(0);
	for(;ptemp!=NULL;ptemp=ptemp->next)
	{
		if(strcmp(ptemp->name,name)==0)
		{
			break;
		}
	
	}
	if(ptemp==NULL)
	{
		mvchgat(15,30,16,A_NORMAL,2,NULL);
		attron(A_BOLD|COLOR_PAIR(2));
		mvprintw(15,32,"没有此电影!😂 ");
		attroff(A_BOLD|COLOR_PAIR(2));
		getch();		
	}
	else
	{
		while(1)
		{
			clear();
			box(stdscr,ACS_VLINE,ACS_HLINE);
			bkgd(COLOR_PAIR(6));
			attron(A_BOLD);
			mvprintw(6,34,"影片名称");
			attroff(A_BOLD);
			mvchgat(6,30,16,A_NORMAL,2,NULL);

			attron(A_BOLD);
			mvprintw(8,35,"导演名");
			attroff(A_BOLD);
			mvchgat(8,30,16,A_NORMAL,2,NULL);

			attron(A_BOLD);
			mvprintw(10,35,"主演名");
			attroff(A_BOLD);
			mvchgat(10,30,16,A_NORMAL,2,NULL);
			
			attron(A_BOLD);
			mvprintw(12,34,"影片类型:");
			attroff(A_BOLD);
			mvchgat(12,30,16,A_NORMAL,2,NULL);
			
			attron(A_BOLD);
			mvprintw(14,34,"影片评分:");
			attroff(A_BOLD);
			mvchgat(14,30,16,A_NORMAL,2,NULL);
			
			attron(A_BOLD);
			mvprintw(16,34,"影片片长:");
			attroff(A_BOLD);
			mvchgat(16,30,16,A_NORMAL,2,NULL);
			
			attron(A_BOLD);
			mvprintw(18,34,"影片价格:");
			attroff(A_BOLD);
			mvchgat(18,30,16,A_NORMAL,2,NULL);
			
			attron(A_BOLD);
			mvprintw(20,34,"上映日期:");
			attroff(A_BOLD);
			mvchgat(20,30,16,A_NORMAL,2,NULL);

			attron(A_BOLD);
			mvprintw(22,36,"返回");
			attroff(A_BOLD);
			mvchgat(22,30,16,A_NORMAL,2,NULL);
			
			mvchgat(line,30,16,A_BLINK,1,NULL);
			noecho();
			flag=getch();
			if(flag==KEY_DOWN)
			{
				line+=2;
			
				if(line==24)
						line=6;
			}
			else if(flag==KEY_UP)
			{
				line-=2;
				if(line==4)
						line=22;
			}
			else if(flag=='\r'||flag=='\n')
			{
				if(line==6)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%s",ptemp->name);
					attroff(A_BOLD|COLOR_PAIR(7));
					noecho();
					curs_set(0);
				}
				else if(line==8)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%s",ptemp->director);
					attroff(A_BOLD|COLOR_PAIR(7));
					noecho();
					curs_set(0);

				}
				else if(line==10)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%s",ptemp->actor);
					attroff(A_BOLD|COLOR_PAIR(7));
					noecho();
					curs_set(0);
				}
				else if(line==12)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%s",ptemp->type);
					attroff(A_BOLD|COLOR_PAIR(7));
					noecho();
					curs_set(0);
				}
				else if(line==14)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%f",&ptemp->score);
					attroff(A_BOLD|COLOR_PAIR(7));
					noecho();
					curs_set(0);
				}
				else if(line==16)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
					attron(A_BOLD|COLOR_PAIR(7));
					scanw("%d",&ptemp->time);
					attroff(A_BOLD|COLOR_PAIR(7));
					noecho();
	                curs_set(0);
				}
				else if(line==18)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
                    echo();
                    move(line+1,30);
                    attron(A_BOLD|COLOR_PAIR(7));
                    scanw("%f",&ptemp->price);
                    attroff(A_BOLD|COLOR_PAIR(7));
                    noecho();
                    curs_set(0);
				}
				else if(line==20)
				{
					mvchgat(line+1,30,16,A_NORMAL,7,NULL);
					curs_set(1);
					echo();
					move(line+1,30);
           		    attron(A_BOLD|COLOR_PAIR(7));
				    scanw("%d",&ptemp->year);
					mvprintw(21,35,"-");
					scanw("%d",&ptemp->month);
					mvprintw(21,38,"-");
					scanw("%d",&ptemp->day);
					attroff(A_BOLD|COLOR_PAIR(7));
	   		        noecho();
					curs_set(0);
				}
				else if(line==22)
						break;
				Save_file(phead);
			
			}
			
	
		}
	}
}
