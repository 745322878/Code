void id_print()
{
		int t=0;
		int i=0;
		while((ch=getch())!=13)
		{
			if(ch!='\b')
			{
				putchar(ch);
				id[i]=ch;
				i++;
			}
			if(ch=='\b'&&i==0)
			{
				id[0]='\0';
			}
			if(ch=='\b'&&i>0)
			{
				printf("\b \b");
				i--;
			}
			if(i==8)
			{
				while((ch=getch())!='\r')
				{
					if(ch=='\b')
					{
						printf("\b \b");
						i=7;
						t=1;
						break;
					}
				}
				if(t==1)
					continue;
				break;
			}
		}
		id[i]='\0';
}
void name_print()
{
	int t=0;
	int i=0;
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			putchar(ch);
			name[i]=ch;
			i++;
		}
		if(ch=='\b'&&i==0)
			name[i]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		} 
		if(i==8)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=7;
					t=1;
					break;
				}
			}
			if(t==1)
				continue;
			break;

		}
		
	}
	name[i]='\0';
}
void()