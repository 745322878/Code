void FormatSeat()
{
	FILE *fp;
	struct film *phead=Read_file();
	char file_name[20];
	while(phead!=NULL)
	{
		strcpy(file_name,phead->name);
		fp=fopen(file_name,"w+");
		fclose(fp);
		phead=phead->next;
	}
	
	clear();
	box(stdscr,ACS_VLINE,ACS_HLINE);
	bkgd(COLOR_PAIR(6));
     
    
	mvchgat(12,28,18,A_NORMAL,2,NULL);
    attron(A_BOLD|COLOR_PAIR(2));
    mvprintw(12,30,"格式化成功!😎 ");
    attroff(A_BOLD|COLOR_PAIR(2));
    getch();
}
