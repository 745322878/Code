int k;
struct ShowFilm *chuan1(struct film *phead)
{
		struct ShowFilm *pnew,*ptemp,*xhead;
		int i;
		k=0;
		xhead=(struct ShowFilm *)malloc(sizeof(struct ShowFilm));
		xhead->left=NULL;
		xhead->right=NULL;
		ptemp=xhead;
		while(1)
		{
				pnew=(struct ShowFilm *)malloc(sizeof(struct ShowFilm));
				for(i=0;i<2&&phead!=NULL;i++)
				{
						strcpy(pnew->name[i],phead->name);
						strcpy(pnew->director[i],phead->director);
						strcpy(pnew->actor[i],phead->actor);
						strcpy(pnew->type[i],phead->type);
						pnew->score[i]=phead->score;
						pnew->time[i]=phead->time;
						pnew->year[i]=phead->year;
						pnew->month[i]=phead->month;
						pnew->day[i]=phead->day;
						pnew->price[i]=phead->price;
						phead=phead->next;
				}
				ptemp->right=pnew;
				pnew->left=ptemp;
				pnew->right=NULL;
				ptemp=pnew;
				k++;
				if(phead==NULL)
				{
						strcpy(ptemp->name[i],"NULL");
						break;
				}
		}
		xhead=xhead->right;
		xhead->left=NULL;
		return xhead;
}

void Sort()
{
	struct film *p=Read_file();
	struct film *t,*q,*r,*phead;
	struct ShowFilm *xhead,*ptemp;
	int flag,line=9,i,j,t1=0;
	int print_line=1,tline;
	int choose=0,item,flag1;
	phead=(struct film *)malloc(sizeof(struct film));
	phead->next=NULL;
	while(1)
	{
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE);
		bkgd(COLOR_PAIR(6));
		mvprintw(3,32,"影片信息排序");
		mvchgat(2,23,30,A_NORMAL,2,NULL);
		mvchgat(3,23,30,A_NORMAL,2,NULL);
		mvchgat(4,23,30,A_NORMAL,2,NULL);
	
		mvprintw(9,34,"价格");
		mvchgat(8,28,15,A_NORMAL,2,NULL);
		mvchgat(9,28,15,A_NORMAL,2,NULL);
		mvchgat(10,28,15,A_NORMAL,2,NULL);
	
		mvprintw(14,34,"评分");
		mvchgat(13,28,15,A_NORMAL,2,NULL);
		mvchgat(14,28,15,A_NORMAL,2,NULL);
		mvchgat(15,28,15,A_NORMAL,2,NULL);
	
		mvprintw(19,34,"返回");
		mvchgat(18,28,15,A_NORMAL,2,NULL);
		mvchgat(19,28,15,A_NORMAL,2,NULL);
		mvchgat(20,28,15,A_NORMAL,2,NULL);
		
		mvchgat(line-1,28,15,A_BLINK,1,NULL);
		mvchgat(line,28,15,A_BLINK,1,NULL);
		mvchgat(line+1,28,15,A_BLINK,1,NULL);
		flag=getch();
		if(flag==KEY_DOWN)
		{
			line+=5;
			if(line==24)
				line=9;
		}
		else if(flag==KEY_UP)
		{
			line-=5;
			if(line==4)
					line=19;
		}
		else if(flag=='\r'||flag=='\n')
		{
			if(line==9)
			{
				if(p==NULL)
				{
					clear();
					box(stdscr,ACS_VLINE,ACS_HLINE);
					bkgd(COLOR_PAIR(6));
					mvchgat(12,30,20,A_NORMAL,2,NULL);
					attron(A_BOLD|COLOR_PAIR(2));
					mvprintw(12,32,"影库还没有影片😂 ");
					attroff(A_BOLD|COLOR_PAIR(2));
					choose=1;
					getch();
				}
				while(p!=NULL)
				{	if(phead->next==NULL)
					{
						phead->next=p;
			    	    q=p->next;		  
						p->next=NULL;
						p=q	;
					}
					else
					{
						q=phead->next;
						r=phead;
						while(q!=NULL&&p->price<q->price)
						{
							r=q;
							q=q->next;
						}
						t=p->next;
						p->next=r->next;
						r->next=p;
						p=t;
					}  
				}
				break;
			}
			else if(line==14)
			{
				if(p==NULL)
				{
					clear();
					box(stdscr,ACS_VLINE,ACS_HLINE);
					bkgd(COLOR_PAIR(6));
					mvchgat(12,30,20,A_NORMAL,2,NULL);
					attron(A_BOLD|COLOR_PAIR(2));
					mvprintw(12,32,"影库还没有影片😂 ");
					attroff(A_BOLD|COLOR_PAIR(2));
					choose=1;
					getch();
				}
				while(p!=NULL)
				{
					if(phead->next==NULL)
					{
						phead->next=p;
						q=p->next;
						p->next=NULL;
						p=q;
					}
					else
					{
						q=phead->next;
						r=phead;
						while(q!=NULL&&p->score<q->score)
						{
							r=q;
							q=q->next;
						}
						t=p->next;
						p->next=r->next;
						r->next=p;
						p=t;
					}
				}
				break;
			}	
				
			else if(line==19)
			{
				choose=1;
				break;
			}
		}
	}
	if(choose==1)
		;
	else
	{
		phead=phead->next;
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE);
		bkgd(COLOR_PAIR(6));
		Show(phead);
	}
}
		
