void Seat_reset()
{
	int i,j,seat_array[6][10]={0};
	FILE *fp;
	struct film *phead=Read_file();
	char file_name[20];
	while(phead!=NULL)
	{
		strcpy(file_name,phead->name);
		fp=fopen(file_name,"w+");
		for(i = 0; i < 6; i++)
		{
			for(j = 0; j < 10; j++)
			{
				fprintf(fp,"%d\n",seat_array[i][j]); 
			}				    
		}
		fclose(fp);
		phead=phead->next;
	
	}
	clear();
	box(stdscr,ACS_VLINE,ACS_HLINE);
	bkgd(COLOR_PAIR(6));
	
	mvprintw(14,32,"😘 座位重置成功😘 ");
	mvchgat(13,23,30,A_NORMAL,2,NULL);
	mvchgat(14,23,30,A_NORMAL,2,NULL);
	mvchgat(15,23,30,A_NORMAL,2,NULL);
	getch();
}
