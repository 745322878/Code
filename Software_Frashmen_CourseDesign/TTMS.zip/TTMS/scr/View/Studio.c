/*
 * Studio.c
 *
 * Created on: 2015年6月25日
 *  Author on: Tang-tang
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Studio.h"
#include "../TTMS/scr/Service/EntityKey.h"
#include "../TTMS/scr/Service/Studio_Srv.h"
#include "../TTMS/scr/View/Seat_UI.h"

//添加新演出厅界面函数的实现部分
int Studio_UI_Add(void) {

    //函数实现
    int         newCount = 0;
    int         key;
    char        choice;
    studio_t    pnew;
    printf("========================== 演出厅增加 ==========================\n");
    do{
        //pnew = (studio_t *)malloc(sizeof(studio_t));
        printf("请输入演出厅名称\n");
        //fflush(stdin);
        scanf("%s",pnew.name);
        printf("请输入座位行数:");
        scanf("%d",&pnew.linesCount);
        printf("请输入座位列数:");
        scanf("%d",&pnew.colsCount);
        key = EntKey_Srv_CompNewKey("studio"); //主键服务
        pnew.id = key;
        pnew.seatsCount = 0;
        if (Srv_Add(&pnew)) {
            printf("增加成功!!\n");
            newCount++;
            printf("继续? (y/n):");
            getchar();
            scanf("%c",&choice);
        }
        else
        {
            printf("增加失败!\n");
            sleep(1);
            return newCount;
        }
    }while (choice == 'y' || choice == 'Y');
    return newCount;
}

//修改演出厅界面函数的实现部分
int Studio_UI_Mod(int id) {

    //函数实现
    int         rtn = 0;
    studio_t    temp;
    printf("========================== 演出厅更新 =========================\n");
    if (Srv_FetchByID(id,&temp)) {
        printf("请输入新的演出厅名称:\n");
        fflush(stdin);
        scanf("%s",temp.name);
        printf("请输入新的座位行数:");
        scanf("%d",&temp.linesCount);
        printf("请输入新的座位列数:");
        scanf("%d",&temp.colsCount);
        if (Srv_Mod(&temp)) {
            rtn = 1;
            printf("更新成功！\n");
        }
        else
        {
            printf("更新失败!\n");
        }
    }
    else
    {
        printf("请按任意键返回!");
        getchar();
        return 0;
    }
    /*
    printf("[Enter] to return!");
    fflush(stdin);
    getchar();
     */
    sleep(1);
    return rtn;
}

//删除演出厅界面函数的实现部分
int Studio_UI_Del(int id) {

    // 函数实现
    int rtn = 0;
    printf("========================== 演出厅删除 =========================\n");
    if (Srv_Del(id)) {
        rtn = 1;
        printf("删除成功!\n");
    }
    else
    {
        printf("删除失败!\n");
    }
    /*
    printf("[Enter] to return!");
    fflush(stdin);
    getchar();
     */
    sleep(1);
    return rtn;
}

//演出厅管理界面层函数实现
void MgtEntry(void) {

    //函数实现部分
    studio_list_t   list;
    studio_node_t   *p;
    int             Snumber,i,pageSize;
    Pagination_t    paging;
    char            choice;
    int             id;
    
    
    List_Init(list,studio_node_t);      //初始化链表
    //载入全部演出厅
    
    Snumber = Studio_Srv_FetchAll(list);    //获取所有演出厅的个数
    
    do{
        printf("请输入每页个数:");
        scanf("%d",&pageSize);
    }while (pageSize <= 0);
    
    paging.totalRecords = Snumber;
    paging.pageSize = pageSize;
    Paging_Locate_FirstPage(list,paging);           //定位到第一页
    
    do {
        system("clear");
        printf("=========================== 演出厅 ===========================\n");
        printf("演出厅ID\t\t演出厅名称\t\t座位行数\t座位列数\t座位数\n");
        printf("＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊\n");
        for (i = 0, p = (studio_node_t *) (paging.curPos); //当前页面的起始位置
             p != list && i < paging.pageSize; i++) {
            printf("%d%20s%15d%15d%20d\n", p->data.id, p->data.name,
                   p->data.linesCount, p->data.colsCount, p->data.seatsCount);
            p=p->next;
        }
        printf("--总记录:%2d ------------------------------- 页 %2d/%2d --\n",
               paging.totalRecords, Pageing_CurPage(paging),
               Pageing_TotalPages(paging));
        printf("［P]前一页 | [N]下一页 ｜ [A]增加  |  [D]删除  |  [U]更新 | [S]座位 ｜［R］返回\n");
        printf("＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊\n");
        printf("Your Choice:");
        while(getchar() != '\n');
        scanf("%c", &choice);
        
        switch (choice) {
            case 'a':
            case 'A':
                if (Studio_UI_Add()) {
                    paging.totalRecords = Studio_Srv_FetchAll(list);
                    Paging_Locate_LastPage(list, paging, studio_node_t);    //定位到最后一页
                }
                break;
            case 'd':
            case 'D':
                printf("请输入ID:");
                scanf("%d",&id);
                if (Studio_UI_Del(id)) {
                    paging.totalRecords = Studio_Srv_FetchAll(list);
                    List_Paging(list, paging, studio_node_t);
                }
                break;
            case 'u':
            case 'U':
                printf("请输入ID:");
                scanf("%d",&id);
                if (Studio_UI_Mod(id)) {
                    paging.totalRecords = Studio_Srv_FetchAll(list);
                    List_Paging(list, paging, studio_node_t);
                }
                break;
            case 's':
            case 'S':
                printf("请输入ID：");
                scanf("%d",&id);
                Seat_UI_MgtEntry(id);
                paging.totalRecords = Studio_Srv_FetchAll(list);
                List_Paging(list, paging, studio_node_t);
                break;
            case 'p':
            case 'P':
                if (1 < Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, -1, studio_node_t); //前移
                }
                break;
            case 'n':
            case 'N':
                if (Pageing_TotalPages(paging) > Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, 1, studio_node_t);  //后移
                }
                break;
        }
        
    } while (choice != 'r' && choice != 'R');
    
    List_Destroy(list,studio_node_t);
}
