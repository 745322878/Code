/*
 * Studio_Perst.c
 *
 * Created on: 2015年6月25日
 *  Author on: Tang-tang
 */

#include "Studio_Perst.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char STUDIO_FILE[] = "StudioData.dat";
static const char STUDIO_TEMP_FILE[] = "StudioTemp.dat";

//在文件中存入演出厅函数
int Studio_Perst_Insert(const studio_t *data) {

    //函数实现部分
    int     rtn = 0;
    FILE    *fp;
    fp = fopen(STUDIO_FILE,"ab");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",STUDIO_FILE);
        getchar();
        return 0;
    }
    rtn = fwrite( data, sizeof(studio_t), 1, fp);
    
    fclose(fp);
    
    return rtn;
}

//在文件中更新演出厅函数
int Studio_Perst_Update(const studio_t *data) {

    //函数实现部分
    int         found = 0;
    studio_t    buf;
    FILE        *fp;
    fp = fopen(STUDIO_FILE,"rb+");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",STUDIO_FILE);
        getchar();
        return 0;
    }
    
    while(!feof(fp))
    {
        if(fread( &buf, sizeof(studio_t), 1, fp))
        {
            if(buf.id == data->id)
            {
                fseek(fp,-sizeof(studio_t),SEEK_CUR);       //移到当前行的头部
                fwrite( data, sizeof(studio_t), 1, fp);
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
    
}

//根据ID在文件中获取演出厅函数
int Studio_Perst_SelectByID(int id,studio_t *buf) {
    
    //函数实现部分
    int         found = 0;
    FILE        *fp;
    studio_t    data;
    fp = fopen(STUDIO_FILE,"rb");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",STUDIO_FILE);
        getchar();
        return 0;
    }
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(studio_t), 1, fp))
        {
            if(id == data.id)
            {
                *buf = data;
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
}

//在文件中获取所有演出厅函数
int Studio_Perst_SelectAll(studio_list_t list) {

    //函数实现部分
    studio_t        data;
    studio_node_t   *newNode;
    int             recCount = 0;
    FILE            *fp;
    fp = fopen(STUDIO_FILE,"rb");
    if(fp == NULL)
    {
        //printf("Failed to open file %s!\n[Enter] to return!",STUDIO_FILE);
        //getchar();
        return 0;
    }
    
    List_Free(list,studio_node_t);
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(studio_t), 1, fp))
        {
            newNode = (studio_node_t *)malloc(sizeof(studio_node_t));
            if(newNode)
            {
                newNode->data = data;
                List_AddTail(list,newNode);
                recCount++;
            }
            else
            {
                printf("Memory application failure!!\n[Enter] to continue!");
                getchar();
                break;
            }
        }
    }
    fclose(fp);
    return recCount;
}

//根据ID在文件中删除演出厅函数
int Studio_Perst_DeleteByID(int id) {

    //函数实现部分
    int         found = 0;
    FILE        *fdata, *ftemp;
    studio_t    buf;
    system("cp StudioData.dat StudioTemp.dat");
    system("rm StudioData.dat");
    system("touch StudioData.dat");
    
    fdata = fopen(STUDIO_FILE,"wb");
    ftemp = fopen(STUDIO_TEMP_FILE,"rb");
    
    if(fdata == NULL || ftemp == NULL)
    {
        printf("Failed to open file!\n[Enter] to return");
        getchar();
        return 0;
    }
    
    while(!feof(ftemp))
    {
        if(fread( &buf, sizeof(studio_t), 1, ftemp))
        {
            if(buf.id != id)
            {
                fwrite( &buf, sizeof(studio_t), 1, fdata);
            }
            else if(buf.id == id)
            {
                found = 1;
            }
        }
    }
    
    fclose(ftemp);
    fclose(fdata);
    system("rm StudioTemp.dat");
    
    return found;
}