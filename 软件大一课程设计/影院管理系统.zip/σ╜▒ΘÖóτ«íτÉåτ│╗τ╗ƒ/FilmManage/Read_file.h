struct film *Read_file()
{
    struct film *phead,*ptemp,*r;
    struct session *session,*q;
	FILE *fp;
	fp = fopen("/Users/wyz/Desktop/影院管理系统/文件/screenings.txt","rt");
	if(fp == NULL)
		return NULL;
	phead = (struct film *)malloc(sizeof(struct film));
	phead->next = NULL;
	r = phead;
	while(!feof(fp))
	{
		ptemp = (struct film *)malloc(sizeof(struct film));
        fscanf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",ptemp->name,
               ptemp->director,ptemp->actor,ptemp->type,
               &ptemp->score,&ptemp->time,&ptemp->price,
               &ptemp->year,&ptemp->month,&ptemp->day);
        ptemp->movieSe = (struct session *)malloc(sizeof(struct session));
        q = ptemp->movieSe;
        while (1)
        {
            session = (struct session *)malloc(sizeof(struct session));
            fscanf(fp,"%f %f %d\n",&session->start,&session->end,&session->movieRoom);
            printw("%d",session->movieRoom);
            if(session->end == 0.0)
            {
                break;
            }
            q->next = session;
            q = session;
        }
        q->next = NULL;
        ptemp->movieSe = ptemp->movieSe->next;
        r->next = ptemp;
		r = ptemp;
	}
	r->next = NULL;
	fclose(fp);
	phead = phead->next;
    //getch();
	return phead;
}

