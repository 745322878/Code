void FormatFilm()
{
	FILE *fp;
	fp=fopen("film_information.txt","w+");
	//fprintf(fp,"NULL");
	fclose(fp);
	fp=fopen("/Users/wyz/Desktop/影院管理系统/文件/screenings.txt","w+");
	//fprintf(fp,"NULL");
	fclose(fp);
	clear();
	box(stdscr,ACS_VLINE,ACS_HLINE);
	bkgd(COLOR_PAIR(6));
	
	mvchgat(12,28,18,A_NORMAL,2,NULL);
	attron(A_BOLD|COLOR_PAIR(2));
	mvprintw(12,30,"格式化成功!😎 ");
	attroff(A_BOLD|COLOR_PAIR(2));
	getch();
}
