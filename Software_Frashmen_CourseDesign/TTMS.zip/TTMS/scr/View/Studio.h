/*
 * Studio.h
 * 
 * Created on: 2015年6月25日
 *  Author on: Tang-tang
 */

#ifndef _STUDIO_H_
#define _STUDIO_H_

#include "../TTMS/scr/Common/common.h"
#include "../TTMS/scr/Common/list.h"
#include "../TTMS/scr/Service/Studio_Srv.h"

//添加新演出厅界面函数的定义部分
int Studio_UI_Add(void);

//修改演出厅界面函数的定义部分
int Studio_UI_Mod(int id);

//删除演出厅界面函数的定义部分
int Studio_UI_Del(int id);

//演出厅管理界面层函数定义部分
void MgtEntry(void);


#endif
