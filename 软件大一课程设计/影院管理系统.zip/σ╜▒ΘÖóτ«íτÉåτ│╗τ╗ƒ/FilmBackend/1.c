#include <stdio.h>
#include "All.h"
int main(void)
{
	setlocale(LC_ALL,"");
	initscr();
	/*struct film *ptemp;
	ptemp=Read_Screenings();
	ptemp=ptemp->next->next->next;
	printw("%s",ptemp->name);
	ptemp=ptemp->link;
	for(;ptemp != NULL;ptemp = ptemp->link)
	{
		printw("%d",ptemp->movieroom);
		printw("\n");
	}*/
    
	Menu();
	getch();
	endwin();
	return 0;
}
