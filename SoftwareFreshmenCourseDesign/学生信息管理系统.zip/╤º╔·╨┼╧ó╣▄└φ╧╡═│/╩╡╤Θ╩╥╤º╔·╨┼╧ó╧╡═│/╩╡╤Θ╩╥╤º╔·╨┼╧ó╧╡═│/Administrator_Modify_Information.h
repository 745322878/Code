
void Administrator_Modify_Information()
{
	int flag,l=10;
	while(1)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|                                               |\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t1.�޸���ʦ��Ϣ\t\t\t|\t||\n");//10
		printf("\t||\t|\t\t2.�޸�ѧ����Ϣ\t\t\t|\t||\n");
		printf("\t||\t|\t\t0.\t����\t\t\t|\t||\n");//12
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(30,l);
		printf("%c",16);
		flag=getch();
		if(flag==Down)
		{
			l++;
			while(l==13)
				l=10;
		}
		if(flag==Up)
		{
			l--;
			while(l==9)
				l=12;
		}
		if(flag==13)
		{
			if(l==10)
			{
					system("cls");
					Administrator_Modify_Teacher();
			}
			if(l==11)
			{
					system("cls");
					Administrator_Modify();
			}
			if(l==12)
				break;

		}
	
	}
}