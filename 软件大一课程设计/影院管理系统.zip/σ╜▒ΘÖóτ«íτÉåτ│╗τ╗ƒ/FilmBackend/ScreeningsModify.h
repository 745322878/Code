void ScreeningsModify()
{
	struct film *phead=Read_Screenings();
	struct film *ptemp=phead;
	struct film *pnew,*t,*shead;
	int line=13,flag,flag1,row=10;
	char name[20];
	int print_line=1,tline;
	float thour,hour,minute;
	int i,j;
	FILE *fp;
			
	clear();
	curs_set(1);		//打开光标回显
	box(stdscr,ACS_VLINE,ACS_HLINE);
	bkgd(COLOR_PAIR(6));

	mvprintw(3,34,"场次设置");
	mvchgat(2,23,30,A_NORMAL,2,NULL);
	mvchgat(3,23,30,A_NORMAL,2,NULL);
	mvchgat(4,23,30,A_NORMAL,2,NULL);
			
	echo();				//getch()回显
	attron(A_BOLD);
	mvprintw(8,30,"请输入影片名称：");
	attroff(A_BOLD);
	mvchgat(9,30,16,A_NORMAL,7,NULL);
	move(9,30);
	attron(A_BOLD|COLOR_PAIR(7));
	scanw("%s",name);
	attroff(A_BOLD|COLOR_PAIR(7));
			
	noecho();			//getch()不回显
	curs_set(0);			//关闭光标回显

	if(ptemp==NULL)
	{
		mvchgat(15,30,16,A_NORMAL,2,NULL);
		attron(A_BOLD|COLOR_PAIR(2));
		mvprintw(15,32,"没有此电影!😂 ");
		attroff(A_BOLD|COLOR_PAIR(2));
		getch();		
	}
	else
	{
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE);
		bkgd(COLOR_PAIR(6));
		while(ptemp!=NULL)
		{
			if(strcmp(ptemp->name,name)==0)
					break;
			ptemp=ptemp->next;
		}	
		if(ptemp==NULL)
		{
			mvchgat(12,30,16,A_NORMAL,2,NULL);
			attron(A_BOLD|COLOR_PAIR(2));
			mvprintw(12,32,"没有此电影!😁 ");
			attroff(A_BOLD|COLOR_PAIR(2));
			getch();
		}
		else
		{
			shead=(struct film *)malloc(sizeof(struct film));
			pnew=(struct film *)malloc(sizeof(struct film));
			shead->link=NULL;
			t=shead;
			while(1)
			{
				clear();
				box(stdscr,'|','-');
				bkgd(COLOR_PAIR(6));
				tline=1;
				
				print_line=1;
				for(i=1;i<21;i++)
				{
					mvprintw(print_line,i,"*");
				}
				for(i=1;i<10;i++)
				{
					mvprintw(print_line+i,1,"*");
					mvprintw(print_line+i,20,"*");
				}
				for(i=1;i<21;i++)
					mvprintw(print_line+10,i,"*");
				mvprintw(tline+5,7,"%s",ptemp->name);
				mvprintw(tline+1,14,"%2.1f分",ptemp->score);
				mvprintw(tline+3,26,"导演");
				mvprintw(tline+3,35,"%s",ptemp->director);
				mvprintw(tline+4,26,"主演");
				mvprintw(tline+4,35,"%s",ptemp->actor);
				mvprintw(tline+5,26,"类型:");
				mvprintw(tline+5,35,"%s",ptemp->type);
				mvprintw(tline+6,26,"首映:");
				mvprintw(tline+6,35,"%d-%d-%d",ptemp->year,
							ptemp->month,ptemp->day);
				mvprintw(tline+7,26,"片长:");
				mvprintw(tline+7,35,"%d分钟",ptemp->time);
				mvprintw(tline+8,26,"价格:");
				mvprintw(tline+8,35,"%2.2f元",ptemp->price);
				print_line=13;
												
				mvprintw(print_line,13,"10:00");
				mvprintw(print_line,23,"14:00");
				mvprintw(print_line,33,"17:00");
				mvprintw(print_line,43,"20:00");
				mvprintw(print_line,53,"23:00");
				mvprintw(print_line,63,"2:00");
				mvchgat(print_line,10,60,A_NORMAL,2,NULL);
				for(i=10;i<70;i++)
						mvprintw(print_line+1,i,"-");
				for(j=print_line+2;j<print_line+4;j++)
				{
					for(i=15;i<75;i+=10)
					{
						mvprintw(j,i,"|");
					}
				}
				for(j=print_line+5;j<print_line+7;j++)
				{
					for(i=15;i<75;i+=10)
					{
						mvprintw(j,i,"|");
					}
				}
				for(i=10;i<70;i++)
						mvprintw(print_line+7,i,"-");
												
				attron(A_BOLD);
				mvprintw(24,38,"返回");
				attroff(A_BOLD);
				mvchgat(24,36,8,A_NORMAL,2,NULL);
											
				noecho();			//getch（）不回显
				curs_set(0);		//光标不回显
				while(1)
				{
					noecho();
					curs_set(0);
					mvchgat(line,10,60,A_NORMAL,2,NULL);
					mvchgat(line,row,10,A_BLINK,1,NULL);
					flag=getch();
					if(flag==KEY_RIGHT)
					{
						row+=10;
						if(row==70)
							row=10;
					}
					else if(flag==KEY_LEFT)
					{	
						row-=10;
						if(row==0)
							row=60;
					}
					else if(flag==KEY_DOWN)
					{
						mvchgat(line,10,60,A_NORMAL,2,NULL);
						mvchgat(24,36,8,A_BLINK,1,NULL);
						while(1)
						{
							flag=getch();	
							if(flag=='\r'||flag=='\n')
							{
								flag1=1;
								break;
							}
						}
						if(flag1==1)
						{
							flag1=2;
							break;
						}
					}
					else if(flag=='\r'||flag=='\n')
					{
						mvchgat(print_line+8,10,60,A_NORMAL,2,NULL);
						curs_set(1);
						echo();
						t=ptemp;
						if(row==10)
							t=t->link;
						else if(row==20)
							t=t->link->link;
						else if(row==30)
							t=t->link->link->link;
						else if(row==40)
							t=t->link->link->link->link;
						else if(row==50)
							t=t->link->link->link->link->link;
						else if(row==60)
							t=t->link->link->link->link->link->link;
						mvchgat(print_line+4,row+3,5,A_NORMAL,7,NULL);
						move(print_line+4,row+5);
						attron(A_BOLD|COLOR_PAIR(7));
						scanw("%d",&t->movieroom);
						attroff(A_BOLD|COLOR_PAIR(7));
							
					}
				}
				if(flag1==2)
						break;
			}
			Save_ScreeningsModify(phead);
		}
	}
}
		
