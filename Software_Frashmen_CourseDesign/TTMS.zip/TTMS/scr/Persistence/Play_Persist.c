/*
 * Play_Persist.c
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include "Play_Persist.h"
#include "../TTMS/scr/Service/Play.h"
#include "../TTMS/scr/Common/list.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

static const char PLAY_DATA_FILE[] = "play.dat";
static const char PLAY_DATA_TEMP_FILE[] = "PlayTemp.dat";

//将参数所指的剧目信息写入剧目文件中
int Play_Perst_Insert(play_t *data) {

    //函数实现部分
    //函数实现部分
    int     rtn = 0;
    FILE    *fp;
    fp = fopen(PLAY_DATA_FILE,"ab");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",PLAY_DATA_FILE);
        getchar();
        return 0;
    }
    rtn = fwrite( data, sizeof(play_t), 1, fp);
    
    fclose(fp);
    
    return rtn;
}

//将参数所指的剧目信息更新到剧目文件中
int Play_Perst_Update(play_t *data) {

    //函数实现部分
    int     found = 0;
    play_t  buf;
    FILE    *fp;
    fp = fopen(PLAY_DATA_FILE,"rb+");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",PLAY_DATA_FILE);
        getchar();
        return 0;
    }
    
    while(!feof(fp))
    {
        if(fread( &buf, sizeof(play_t), 1, fp))
        {
            if(buf.id == data->id)
            {
                fseek(fp,-sizeof(play_t),SEEK_CUR);       //移到当前行的头部
                fwrite( data, sizeof(play_t), 1, fp);
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
}

//按照id从文件中删除剧目数据
int Play_Perst_DeleteByID(int id) {

    //函数实现部分
    int     found = 0;
    FILE    *fdata, *ftemp;
    play_t  buf;
    system("cp play.dat PlayTemp.dat");
    system("rm play.dat");
    system("touch play.dat");
    
    fdata = fopen(PLAY_DATA_FILE,"wb");
    ftemp = fopen(PLAY_DATA_TEMP_FILE,"rb");
    
    if(fdata == NULL || ftemp == NULL)
    {
        printf("Failed to open file!\n[Enter] to return");
        getchar();
        return 0;
    }
    
    while(!feof(ftemp))
    {
        if(fread( &buf, sizeof(play_t), 1, ftemp))
        {
            if(buf.id != id)
            {
                fwrite( &buf, sizeof(play_t), 1, fdata);
            }
            else if(buf.id == id)
            {
                found = 1;
            }
        }
    }
    
    fclose(ftemp);
    fclose(fdata);
    system("rm PlayTemp.dat");
    
    return found;
}

//从文件中载入所有剧目
int Play_Perst_SelectAll(play_list_t list) {

    //函数实现部分
    play_t          data;
    play_node_t     *newNode;
    int             recCount = 0;
    FILE            *fp;
    fp = fopen(PLAY_DATA_FILE,"rb");
    if(fp == NULL)
    {
        //printf("Failed to open file %s!\n[Enter] to return!",STUDIO_FILE);
        //getchar();
        return 0;
    }
    
    List_Free(list,play_node_t);
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(play_t), 1, fp))
        {
            newNode = (play_node_t *)malloc(sizeof(play_node_t));
            if(newNode)
            {
                newNode->data = data;
                List_AddTail(list,newNode);
                recCount++;
            }
            else
            {
                printf("Memory application failure!!\n[Enter] to continue!");
                getchar();
                break;
            }
        }
    }
    fclose(fp);
    return recCount;
}

//按照id从文件中获取剧目数据
int Play_Perst_SelectByID(int id,play_t *buf) {

    //函数实现部分
    int     found = 0;
    FILE    *fp;
    play_t  data;
    fp = fopen(PLAY_DATA_FILE,"rb");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",PLAY_DATA_FILE);
        getchar();
        return 0;
    }
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(play_t), 1, fp))
        {
            if(id == data.id)
            {
                *buf = data;
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
}

//按照名称查找剧目
int Play_Perst_SelectByName(play_list_t list, char condt[]) {

    //函数实现部分
    play_t      data;
    play_node_t *newNode;
    int         iCount = 0;
    FILE        *fp;
    fp = fopen(PLAY_DATA_FILE,"rb");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",PLAY_DATA_FILE);
        getchar();
        return 0;
    }
    
    List_Free(list,play_node_t);
    
    while (!feof(fp))
    {
        if (fread( &data, sizeof(play_t), 1, fp))
        {
            if (strcmp(condt,data.name) == 0)
            {
                newNode->data = data;
                List_AddTail(list,newNode);
                iCount++;
            }
        }
    }
    return iCount;
}

//按照名称过滤剧目
int Play_Perst_FilterByName(play_list_t list, char filter[]) {

    //函数实现部分
    play_t      data;
    play_node_t *newNode;
    int         iCount = 0;
    FILE        *fp;
    fp = fopen(PLAY_DATA_FILE,"rb");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",PLAY_DATA_FILE);
        getchar();
        return 0;
    }
    
    List_Free(list,play_node_t);
    
    while (!feof(fp))
    {
        if (fread( &data, sizeof(play_t), 1, fp))
        {
            if (strcmp(filter,data.name) != 0)
            {
                newNode->data = data;
                List_AddTail(list,newNode);
                iCount++;
            }
        }
    }
    return iCount;

}