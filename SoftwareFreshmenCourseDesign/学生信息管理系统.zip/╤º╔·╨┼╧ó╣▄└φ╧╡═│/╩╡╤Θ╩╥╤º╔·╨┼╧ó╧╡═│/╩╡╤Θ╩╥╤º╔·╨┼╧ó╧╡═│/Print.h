//���ѧ����Ϣ
void Print(struct student *phead)
{
	
	struct student *ptemp;
	ptemp=phead;
	if(ptemp==NULL)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t\t_______________________________________________\t\n");
		printf("\t\t\t\t\t\t\t\t\t\n");
		printf("\t\t\t\t\t\t\t\t\t\n");
		printf("\t\t����\tѧ��\t����\t��ѧ\tӢ��\tƽ����\t\t\n");
		printf("\t\t\t\t\t\t\t\t\t\n");
		printf("\t\t\t\t\t\t\t\t\t\n");
		printf("\t\t\t\t\t\t\t\t\t\n");
		printf("\t\t_______________________________________________\t\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		getch();
	}
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t\t_______________________________________________\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t����\tѧ��\t����\t��ѧ\tӢ��\tƽ����\t\t\n");
	while(ptemp!=NULL)
	{
		printf("\t\t%s\t%s  %1.1f\t%1.1f\t%1.1f\t%1.1f\t\t\n"
			,ptemp->name,ptemp->id,ptemp->chinese,ptemp->math,ptemp->english,ptemp->aver);
		ptemp=ptemp->next;
		
	}
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t_______________________________________________\t\t\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");

	getch();
}