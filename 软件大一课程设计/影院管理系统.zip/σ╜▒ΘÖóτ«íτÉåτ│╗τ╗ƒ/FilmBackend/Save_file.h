void Save_file(struct film *phead)
{
	struct film *ptemp=phead;
	FILE *fp;
	fp=fopen("film_information.txt","w+");
	for(;ptemp!=NULL;ptemp=ptemp->next)
	{
		fprintf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",ptemp->name,
				ptemp->director,ptemp->actor,ptemp->type,ptemp->score,
				ptemp->time,ptemp->price,ptemp->year,
				ptemp->month,ptemp->day);
	}
	fclose(fp);
}
