void Menu()
{
	int flag;
	int line=8,row=13;
	struct film *phead;
	noecho();			//getch()时关闭回显
	keypad(stdscr,1);	//开启功能键响应模式（上下左右）	
	curs_set(0);		//关闭光标回显
	//box(stdscr,ACS_VLINE,ACS_HLINE);	//画边框
	start_color();						//开启颜色管理功能
	init_pair(1,COLOR_BLACK,COLOR_CYAN);	//颜色配对
	init_pair(2,COLOR_BLACK,COLOR_MAGENTA);
    init_pair(3,COLOR_BLACK,COLOR_BLUE);
	init_pair(4,COLOR_BLACK,COLOR_RED);
	init_pair(5,COLOR_BLACK,COLOR_YELLOW);
	init_pair(6,COLOR_BLACK,COLOR_GREEN);
	init_pair(7,COLOR_BLACK,COLOR_WHITE);
	//bkgd(COLOR_PAIR(6));		//背景色设置
	while(1)
	{
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE); 
		bkgd(COLOR_PAIR(6));
		keypad(stdscr,1);
		move(3,32);
		attron(A_BOLD);
        printw("影院管理系统");
		attroff(A_BOLD);
		mvchgat(2,23,30,A_NORMAL,2,NULL);
		mvchgat(3,23,30,A_NORMAL,2,NULL);
		mvchgat(4,23,30,A_NORMAL,2,NULL);
		move(8,18);
		attron(A_BOLD);			//输出修饰
		printw("增加");
		attroff(A_BOLD);		//关闭输出修饰
		mvchgat(7,13,15,A_NORMAL,7,NULL);
		mvchgat(8,13,15,A_NORMAL,7,NULL);
		mvchgat(9,13,15,A_NORMAL,7,NULL);
		
		move(13,18);
		attron(A_BOLD);
		printw("删除");
		attroff(A_BOLD);
		mvchgat(12,13,15,A_NORMAL,7,NULL);
		mvchgat(13,13,15,A_NORMAL,7,NULL);
		mvchgat(14,13,15,A_NORMAL,7,NULL);
		
		move(18,18);
		attron(A_BOLD);
		printw("查找");
		attroff(A_BOLD);
		mvchgat(17,13,15,A_NORMAL,7,NULL);
		mvchgat(18,13,15,A_NORMAL,7,NULL);
		mvchgat(19,13,15,A_NORMAL,7,NULL);
		
		move(8,53);
		attron(A_BOLD);   
		printw("修改");
		attroff(A_BOLD);
		mvchgat(7,48,15,A_NORMAL,7,NULL);
		mvchgat(8,48,15,A_NORMAL,7,NULL);
		mvchgat(9,48,15,A_NORMAL,7,NULL);
		
		move(13,53);
		attron(A_BOLD);
		printw("排序");
		attroff(A_BOLD);
		mvchgat(12,48,15,A_NORMAL,7,NULL);
		mvchgat(13,48,15,A_NORMAL,7,NULL);
		mvchgat(14,48,15,A_NORMAL,7,NULL);

		move(18,53);
		attron(A_BOLD);
		printw("显示");
		attroff(A_BOLD);
		mvchgat(17,48,15,A_NORMAL,7,NULL);
		mvchgat(18,48,15,A_NORMAL,7,NULL);
		mvchgat(19,48,15,A_NORMAL,7,NULL);
		
		attron(A_BOLD);
		mvprintw(23,16,"座位与场次");
		attroff(A_BOLD);
		mvchgat(22,13,15,A_NORMAL,7,NULL);
		mvchgat(23,13,15,A_NORMAL,7,NULL);
		mvchgat(24,13,15,A_NORMAL,7,NULL);
	
		move(23,52);
		attron(A_BOLD);
		printw("退出程序");
		attroff(A_BOLD);
		mvchgat(22,48,15,A_NORMAL,7,NULL);
		mvchgat(23,48,15,A_NORMAL,7,NULL);
		mvchgat(24,48,15,A_NORMAL,7,NULL);
		mvchgat(line-1,row,15,A_BLINK,1,NULL);
		mvchgat(line,row,15,A_BLINK,1,NULL);
		mvchgat(line+1,row,15,A_BLINK,1,NULL);	
		
		flag=getch();
		if(flag==KEY_DOWN)
		{
			
			line+=5;
			mvchgat(line-1,row,15,A_BLINK,1,NULL);
			mvchgat(line,row,15,A_BLINK,1,NULL);
			mvchgat(line+1,row,15,A_BLINK,1,NULL);
			
			if(line==28)
			{
					line=8;
			}
		}
		else if(flag==KEY_UP)
		{
			line-=5;
			mvchgat(line-1,row,15,A_BLINK,1,NULL);
			mvchgat(line,row,15,A_BLINK,1,NULL);
			mvchgat(line+1,row,15,A_BLINK,1,NULL);
			if(line==3)
			{
				line=23;
			}
			
		}
		else if(flag==KEY_RIGHT)
		{
			row+=35;
			mvchgat(line-1,row,15,A_BLINK,1,NULL);
			mvchgat(line,row,15,A_BLINK,1,NULL);
			mvchgat(line+1,row,15,A_BLINK,1,NULL);
			if(row==83)
					row=13;
		}
		else if(flag==KEY_LEFT)
		{
			row-=35;
			mvchgat(line-1,row,15,A_BLINK,1,NULL);
			mvchgat(line,row,15,A_BLINK,1,NULL);
			mvchgat(line+1,row,15,A_BLINK,1,NULL);
			if(row==-22)
					row=48;
		}
		else if(flag=='\r'||flag=='\n')
		{
			
			if(line==8&&row==13)
				Add();
			else if(line==13&&row==13)
				Delete();
			else if(line==18&&row==13)
				Search();
			else if(line==23&&row==13)
				Front();
			else if(line==8&&row==48)
				Modify();
			else if(line==13&&row==48)
				Sort();
			else if(line==18&&row==48)
			{
				phead=Read_file();
				Show(phead);
			}
			else if(line==23&&row==48)
				Exit();
		}
	
		
	}
}
