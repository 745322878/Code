#include<stdio.h>
#include "All.h"
int main(void)
{
	Welcome();
	Menu_Land();
	return 0;
}








