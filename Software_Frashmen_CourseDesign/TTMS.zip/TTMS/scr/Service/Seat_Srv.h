/*
 * Seat_Srv.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef _SEAT_SRV_H_
#define _SEAT_SRV_H_

typedef enum {

    SEAT_NONE = 0,      //空位
    SEAT_GOOD = 1,      //有座位
    SEAT_BROKEN = 9,    //损坏的座位
    
}seat_status_t;

typedef struct {

    int             id;         //座位ID
    int             roomID;     //所在演出厅ID
    int             row;        //座位行号
    int             column;     //座位列号
    seat_status_t   status;     //座位在该行的状态
    
}seat_t;

typedef struct seat_node {

    seat_t              data;
    struct seat_node    *next;
    struct seat_node    *prev;
    
}seat_node_t, *seat_list_t;

//演出厅座位初始化服务
int Seat_Srv_RoomInit(seat_list_t list, int roomID, int rowsCount, int colsCount);

//单个添加座位函数
int Seat_Srv_Add(const seat_t *data);

//批量添加座位函数
int Seat_Srv_AddBatch(seat_list_t list);

//修改座位函数
int Seat_Srv_Modify(const seat_t *data);

//根据ID删除座位
int Seat_Srv_DeleteByID(int id);

//根据演出厅ID删除其所有座位
int Seat_Srv_DeleteAllByRoomID(int roomID);

//根据ID获取座位
int Seat_Srv_FetchByID(int id, seat_t *data);

//根据演出厅ID提取有效座位
int Seat_Srv_FetchValidByRoomID(seat_list_t list, int roomID);

//根据演出厅ID获取座位链表
int Seat_Srv_FetchByRoomID(seat_list_t list, int roomID);

//根据行列号获取座位
seat_node_t *Seat_Srv_FindByRowCol(seat_list_t list, int row, int column);

//根据ID获取对应链表上座位结点
seat_node_t *Seat_Srv_FindByID(seat_list_t list, int seatID);

//对座位链表list进行排序函数
void Seat_Srv_SortSeatList(seat_list_t list);

//将结点node加入到已排序链表list中
void Seat_Srv_AddToSoftedList(seat_list_t list, seat_node_t *node);

#endif
