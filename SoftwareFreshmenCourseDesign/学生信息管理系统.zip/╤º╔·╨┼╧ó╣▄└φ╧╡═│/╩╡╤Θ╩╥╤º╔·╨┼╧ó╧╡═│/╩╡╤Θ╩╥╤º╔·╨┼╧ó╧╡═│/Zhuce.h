struct student *Zhuce()
{
	struct student  *pnew,*phead,*p;
	int l=8;
	int i=0,t;
	char ch;
	char id[10],name[10];
	system("cls");
	p=Read_Password();
	pnew=(struct student  *)malloc(sizeof(struct student));
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t _______________________________________________ \t||\n");
	printf("\t||\t|\t________________________\t\t|\t||\n");
	printf("\t||\t|\t|       ID:             |\t\t|\t||\n");//8
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t| Password:             |\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|     name:             |\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|\t   ע��\t\t|\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t\t\t\t\t\t|\t||\n");
	printf("\t||\t|_______________________________________________|\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");
	goto_xy(35,l);
	t=0;
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			putchar(ch);
			id[i]=ch;
			i++;
		}
		if(ch=='\b'&&i==0)
			id[0]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		} 
		if(i==8)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=7;
					t=1;
					break;
				}
			}
			if(t==1)
				continue;
			break;

		}
		
	}
	id[i]='\0';
	
	strcpy(pnew->id,id );
	for(p;p!=NULL;p=p->next )
	{
		if(strcmp(p->id ,pnew->id )==0)
		{
			goto_xy(30,16);
			printf("���û���ע��!\n");
			Sleep(1000);
			break;
		}
	}
	if(p==NULL)
	{
		strcpy(pnew->password,"111111");
		goto_xy(35,10);	
		printf("%s",pnew->password );
		goto_xy(35,12);
		t=0;
		i=0;
		while((ch=getch())!='\r')
		{
			
			if(ch!='\b')
			{
				putchar(ch);
				name[i]=ch;
				i++;
			}
			if(ch=='\b'&&i==0)
				name[i]='\0';
			if(ch=='\b'&& i>0)
			{
				printf("\b \b");
				i--;
			} 
			if(i==6)
			{
				while((ch=getch())!='\r')
				{
					if(ch=='\b')
					{
						printf("\b \b");
						i=5;
						t=1;
						break;
					}
				}
				if(t==1)
					continue;
				break;

			}
			
		}
		name[i]='\0';
		strcpy(pnew->name ,name);
		pnew->next =NULL;
		phead=pnew;
		phead->chinese =0;
		phead->math =0;
		phead->english =0;
		phead->aver=0;
		Save_Password(phead);
		Save_file(phead);
		goto_xy(30,16);
		printf("ע��ɹ�!");
		Sleep(800);
			
			
	}
	
	return phead;
}
