struct film *Read_file()
{
    struct film *phead,*ptemp,*r;
	FILE *fp;
	fp=fopen("film_information.txt","r");
	if(fp==NULL)		//文件打开失败或没有文件
		return NULL;
	//求文件大小
	//if(filelength(fileno(fp))==0)		//需要io.h
	//		return NULL;
	fseek(fp,0,SEEK_END);
	if(ftell(fp)==0)		//文件大小是否为0
		return NULL;
	//fseek(fp,0,0);
	rewind(fp);
	phead=(struct  film *)malloc(sizeof(struct film));
	phead->next=NULL;
	r=phead;
	while(!feof(fp))
	{
		ptemp=(struct film *)malloc(sizeof(struct film));
		fscanf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",ptemp->name,			
						ptemp->director,ptemp->actor,ptemp->type,
						&ptemp->score,&ptemp->time,&ptemp->price,
						&ptemp->year,&ptemp->month,&ptemp->day);
		r->next=ptemp;
		r=ptemp;
	}
	r->next=NULL;
	fclose(fp);
	phead=phead->next;
	return phead;
}
