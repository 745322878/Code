void Add()
{
	struct film *pnew,*phead,*p;
	int icount=0,row;
	int  flag,flag1,flag2=0;
	int line=13,roach=30;
	FILE *fp;
	int ch;
	char filename[20];
	int t=0,i=0,j,seat_array[6][10]={0};
	while(1)
	{	
		clear();
		noecho();	//getch()不回显
		p=Read_file();
		pnew=(struct film *)malloc(sizeof(struct film ));
		mvprintw(3,32,"添加影片信息");
		mvchgat(2,23,30,A_NORMAL,2,NULL);
		mvchgat(3,23,30,A_NORMAL,2,NULL);
		mvchgat(4,23,30,A_NORMAL,2,NULL);
		
		attron(A_BOLD);
		mvprintw(6,30,"请输入影片名称:");
		attroff(A_BOLD);
		mvchgat(7,30,16,A_NORMAL,7,NULL);

		attron(A_BOLD);
		mvprintw(8,30,"请输入导演名:");
		attroff(A_BOLD);
		mvchgat(9,30,16,A_NORMAL,7,NULL);
		
		attron(A_BOLD);
		mvprintw(10,30,"请输入主演名:");
		attroff(A_BOLD);
		mvchgat(11,30,16,A_NORMAL,7,NULL);

		attron(A_BOLD);
		mvprintw(12,30,"请输入影片类型:");
		attroff(A_BOLD);
		mvchgat(13,30,16,A_NORMAL,7,NULL);
		
		attron(A_BOLD);
		mvprintw(14,30,"请输入影片评分:");
		attroff(A_BOLD);
		mvchgat(15,30,16,A_NORMAL,7,NULL);

		attron(A_BOLD);
		mvprintw(16,30,"请输入影片片长:");
		attroff(A_BOLD);
		mvchgat(17,30,16,A_NORMAL,7,NULL);
		
		attron(A_BOLD);
		mvprintw(18,30,"请输入影片价格:");
		attroff(A_BOLD);
		mvchgat(19,30,16,A_NORMAL,7,NULL);

		attron(A_BOLD);
		mvprintw(20,30,"请输入上映日期:");
		attroff(A_BOLD);
		mvchgat(21,30,16,A_NORMAL,7,NULL);


		attron(A_BOLD);
		mvprintw(23,30,"继续");
		attroff(A_BOLD);
		mvchgat(23,30,4,A_NORMAL,7,NULL);
		
		attron(A_BOLD);
		mvprintw(23,42,"返回");
		attroff(A_BOLD);
		mvchgat(23,42,4,A_NORMAL,7,NULL);

		move(7,30);
		curs_set(1);				//开启光标回显
		echo();						//开启getch()回显 
		keypad(stdscr,0);			//关闭功能键
		attron(A_BOLD|COLOR_PAIR(7));
/*		while((ch=getch())!='\r')
		{
			if(ch!=KEY_BACKSPACE)
			{	
				name[i]=ch;		
				i++;
			}
			if(ch==KEY_DL&&i==0)
				name[0]='\0';
			if(ch==KEY_DL&&i!=0)
			{
				printw("KEY_DL KEY_DL");
						i--;
			}
			if(i==16)
			{
				while((ch=getch())!='\r')
				{
					if(ch==KEY_DL)
					{
						printw("KEY_DL KEY_DL");
						i=15;
						t=1;
						break;
					}
				}
				if(t==1)
						continue;
				break;
			}
			name[i]='\0';
		}
		
		strcpy(pnew->name,name);*/
		scanw("%s",pnew->name);
		strcpy(filename,pnew->name);
		
		attroff(A_BOLD|COLOR_PAIR(7));
		for(;p!=NULL;p=p->next )
		{
			if(strcmp(p->name ,pnew->name )==0)
			{
				curs_set(0);
				mvprintw(25,32,"该影片已添加");
				mvchgat(25,30,16,A_NORMAL,2,NULL);
				mvchgat(25,30,16,A_NORMAL,1,NULL);
				getch();
				flag2=1;
				break;
			}
		}
		if(flag2==1)
				break;

		move(9,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%s",pnew->director);
		attroff(A_BOLD|COLOR_PAIR(7));

		move(11,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%s",pnew->actor);
		attroff(A_BOLD|COLOR_PAIR(7));
		
		move(13,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%s",pnew->type);
		attroff(A_BOLD|COLOR_PAIR(7));
		
		move(15,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%f",&pnew->score);
		attroff(A_BOLD|COLOR_PAIR(7));

		move(17,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%d",&pnew->time);
		attroff(A_BOLD|COLOR_PAIR(7));

		move(19,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%f",&pnew->price);
		attroff(A_BOLD|COLOR_PAIR(7));
		
		move(21,30);
		attron(A_BOLD|COLOR_PAIR(7));
		scanw("%d",&pnew->year);
		mvprintw(21,35,"-");
		scanw("%d",&pnew->month);
		mvprintw(21,38,"-");
		scanw("%d",&pnew->day);
		attroff(A_BOLD|COLOR_PAIR(7));

		curs_set(0);		//关闭光标回显
		noecho();			//关闭getch（）回显
		keypad(stdscr,1);		// 打开功能键
		fp=fopen("film_information.txt","a+");
		for(;pnew!=NULL;pnew=pnew->next)
		{
			fprintf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",pnew->name,
							pnew->director,pnew->actor,pnew->type,
							pnew->score,pnew->time,pnew->price,pnew->year,
							pnew->month,pnew->day);
		}
		fclose(fp);
			
		fp=fopen(filename,"w+");
		for(i = 0; i < 6; i++)
		{
			for(j = 0; j < 10; j++)
			{
				fprintf(fp,"%d\n",seat_array[i][j]); 					
			}
		}
		fclose(fp);

		noecho();
		row=30;
		while(1)
		{
			
			mvchgat(23,30,4,A_NORMAL,7,NULL);
			mvchgat(23,42,4,A_NORMAL,7,NULL);
			mvchgat(23,row,4,A_BLINK,1,NULL);
			flag=getch();
			if(flag==KEY_RIGHT)
			{
				row+=12;
				
				if(row==54)
					row=30;
			}
			else if(flag==KEY_LEFT)
			{
				row-=12;
				if(row==18)
					row=42;
			}
			else if(flag=='\r'||flag=='\n')
			{
				if(row==30)
				{
					flag1=1;
					break;
				}
				if(row==42)
				{
						flag1=0;
						break;
				}
			}
		}
		if(flag1==0)
				break;
		
	}
	noecho();
	curs_set(0);
}
	
