
void Menu_Administrator();
void Menu_Teacher();
void Menu_Student();
void Menu_Land( )
{

	int  flag;
	int l=9;
	while(1)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|                                               |\t||\n");
		printf("\t||\t|\t\t    1.ѧ����¼\t\t\t|\t||\n");//9
		printf("\t||\t|\t\t    2.��ʦ��¼\t\t\t|\t||\n");
		printf("\t||\t|\t\t    3.����Ա��¼\t\t|\t||\n");
		printf("\t||\t|\t\t    0.�˳�����\t\t\t|\t||\n");//12
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(34,l);
		printf("%c",16);
		
		flag=getch();
		if(flag==Down)
		{
			l++;
			while(l==13)
				l=9;
		}
		if(flag==Up)
		{
			l--;
			while(l==8)
				l=12;
		}
		if(flag==13)
		{
			if(l==9)
			{
				Land_Student();
				Menu_Student();
			}
			if(l==10)
			{
				Land_Teacher();
				Menu_Teacher();
			}
			if(l==11)
			{
				Land_Administrator();
				Menu_Administrator();
			}
			if(l==12)
			{
				Exit();
			    exit(1);
			}
		}

	}
}
