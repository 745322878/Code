void Normal(int y,int x,int n)
{
    mvchgat(y-1,x-4,14,A_NORMAL,n,NULL);
    mvchgat(y,x-4,14,A_NORMAL,n,NULL);
    mvchgat(y+1,x-4,14,A_NORMAL,n,NULL);
}

void Blink(int y,int x,int n)
{
    mvchgat(y-1,x-4,14,A_BLINK,n,NULL);
    mvchgat(y,x-4,14,A_BLINK,n,NULL);
    mvchgat(y+1,x-4,14,A_BLINK,n,NULL);
}

void move_1(int y,int x,int end,int start)
{
    keypad(stdscr,2);
    int ch;
    while (1) {
        ch = 0;
        if(y != 21)
        {
            mvchgat(y,x,8,A_BLINK,3,NULL);
        }
        else
        {
            Blink(y,x,3);
        }
        switch (getch()) {
            case KEY_DOWN:
                if(y >= start  && y <= end)
                {
                    if(y==end)
                    {
                        mvchgat(y,x,8,A_NORMAL,2,NULL);
                        y=21;
                        x=60;
                        move(y,x);
                        Blink(y,x,3);
                    }
                    else
                    {
                        mvchgat(y,x,8,A_NORMAL,2,NULL);
                        y += 2;
                        move(y,x);
                        mvchgat(y,x,8,A_BLINK,3,NULL);
                    }
                }
                break;
            case KEY_UP:
                if ((y > start && y <= end) || y==21)
                {
                    if(y==21)
                    {
                        Normal(y,x,2);
                        y=end;
                        x=62;
                        move(y,x);
                        mvchgat(y,x,8,A_BLINK,3,NULL);
                    }
                    else
                    {
                        mvchgat(y,x,8,A_NORMAL,2,NULL);
                        y -= 2;
                        move(y,x);
                        mvchgat(y,x,8,A_BLINK,3,NULL);
                    }
                }
                break;
            case KEY_LEFT:
                if(y==21 && x>12)
                {
                    Normal(y,x,2);
                    x -= 24;
                    move(y,x);
                    Blink(y,x,3);
                }
                break;
            case KEY_RIGHT:
                if(y==21 && x<60)
                {
                    Normal(y,x,2);
                    x += 24;
                    move(y,x);
                    Blink(y,x,3);
                }
                break;
            case '\n':
                ch = 1;
                break;
            default:
                break;
        }
        if(ch==1)
        {
            a[0]=y;
            a[1]=x;
            break;
        }
    }
}

void seat_blink(int y,int x)
{
    int line,cols;
    line = (y-11)/2;
    cols = (x-20)/4;
    if(x >= 20 && x <= 56 && seat_array[line][cols] == 0)
    {
        mvchgat(y,x,4,A_BLINK,7,NULL);
    }
    else if(x >= 20 && x <= 56 && seat_array[line][cols] == 1)
    {
        mvchgat(y,x,4,A_BLINK,5,NULL);
    }
    else if(x >= 20 && x <= 56 && seat_array[line][cols] == 2)
    {
        mvchgat(y,x,4,A_BLINK,6,NULL);
    }
    else
    {
        mvchgat(y,x,8,A_BLINK,8,NULL);
    }
}

void seat_normal(int y,int x)
{
    int line,cols;
    line = (y-11)/2;
    cols = (x-20)/4;
    if(x >= 20 && x <= 56 && seat_array[line][cols] == 0)
    {
        mvchgat(y,x,4,A_NORMAL,7,NULL);
    }
    else if(x >= 20 && x <= 56 && seat_array[line][cols] == 1)
    {
        mvchgat(y,x,4,A_NORMAL,5,NULL);
    }
    else if(x >= 20 && x <= 56 && seat_array[line][cols] == 2)
    {
        mvchgat(y,x,4,A_NORMAL,6,NULL);
    }
    else
    {
        mvchgat(y,x,8,A_NORMAL,2,NULL);
    }
}

int choise,cancle,enter;
void Move_2(int y,int x)
{
    keypad(stdscr,1);
    int ch;
    choise = 0;
    cancle = 0;
    while(1)
    {
        enter = 0;
        ch = 0;
        seat_blink(y,x);
        switch(getch())
        {
            case KEY_DOWN:
                if(y >= 11 && y < 21)
                {
                    if(y == 21 && x == 66)
                    {
                        ;
                    }
                    else
                    {
                        seat_normal(y,x);
                        y += 2;
                        move(y,x);
                        seat_blink(y,x);
                    }
                }
                break;
            case KEY_UP:
                if(y > 11 && y <= 21)
                {
                    if(y == 19 && x == 66)
                    {
                        ;
                    }
                    else
                    {
                        seat_normal(y,x);
                        y -= 2;
                        move(y,x);
                        seat_blink(y,x);
                    }
                }
                break;
            case KEY_LEFT:
                if((x <= 56 && x > 20) || x == 66)
                {
                    if(x == 66)
                    {
                        seat_normal(y,x);
                        y = 21;
                        x = 56;
                        move(y,x);
                        seat_blink(y,x);
                    }
                    else
                    {
                        seat_normal(y,x);
                        x -= 4;
                        move(y,x);
                        seat_blink(y,x);
                    }
                }
                break;
            case KEY_RIGHT:
                if(x <= 56 && x >= 20)
                {
                    if(x == 56)
                    {
                        seat_normal(y,x);
                        y = 21;
                        x = 66;
                        move(y,x);
                        seat_blink(y,x);
                    }
                    else
                    {
                        seat_normal(y,x);
                        x += 4;
                        move(y,x);
                        seat_blink(y,x);
                    }
                }
                break;
            case '-':
                cancle = 1;
                choise = 0;
                ch = 1;
                break;
            case '+':
                choise = 1;
                cancle = 0;
                ch = 1;
                break;
            case '\n':
                enter = 1;
                ch = 1;
                break;
            default:
                break;
        }
        if(ch == 1)
        {
            a[2] = y;
            a[3] = x;
            break;
        }
    }
}

void move_3(int y,int x)
{
    keypad(stdscr,2);
    int ch;
    while(1)
    {
        ch = 0;
        Blink(y,x,3);
        switch(getch())
        {
            case KEY_RIGHT:
                if(x < 60 && x >= 16)
                {
                    Normal(y,x,2);
                    x += 44;
                    move(y,x);
                    Blink(y,x,3);
                }
                break;
            case KEY_LEFT:
                if(x <= 60 && x > 16)
                {
                    Normal(y,x,2);
                    x -= 44;
                    move(y,x);
                    Blink(y,x,3);
                }
                break;
            case '\n':
                ch = 1;
                break;
            default:
                break;
        }
        if(ch == 1)
        {
            a[4] = y;
            a[5] = x;
            break;
        }
    }
}
