struct readFilm *chuan(struct film *phead)
{
    struct readFilm *pnew, *ptemp, *xhead;
    int i;
    xhead = (struct readFilm *)malloc(sizeof(struct readFilm));
    xhead->left = NULL;
    xhead->right = NULL;
    ptemp = xhead;
    while(1)
    {
        pnew = (struct readFilm *)malloc(sizeof(struct readFilm));
        for(i = 0;i < 6 && phead != NULL; i++)
        {
            strcpy(pnew->a[i],phead->name);
            pnew->b[i] = phead->price;
            strcpy(pnew->Director[i],phead->director);
            strcpy(pnew->Actor[i],phead->actor);
            pnew->Score[i] = phead->score;
            pnew->Times[i] = phead->time;
            strcpy(pnew->Type[i],phead->type);
            pnew->Year[i] = phead->year;
            pnew->Month[i] = phead->month;
            pnew->Day[i] = phead->day;
            pnew->movie[i] = phead->movieSe;
            phead = phead->next;
        }
        ptemp->right = pnew;
        pnew->left = ptemp;
        pnew->right = NULL;
        ptemp = pnew;
        if(phead == NULL)
        {
            strcpy(ptemp->a[i],"NULL");
            break;
        }
    }
    xhead = xhead->right;
    xhead->left = NULL;
    return xhead;
}

void byTicket(struct film *phead)
{
    struct readFilm *xhead;
    int i, get, k, l, set;
    char moviename[50];
    a[0]=5;
    a[1]=62;
    xhead = chuan(phead);
loop:
    Menu_1(y,x);
    for(i = 0;i < 6;i++)
    {
        if(!strcmp(xhead->a[i],"NULL"))
        {
            get = i-1;
            break;
        }
        mvprintw(5+(i*2),2,"%d",i+1);
        mvprintw(5+(i*2),16,"%s",xhead->a[i]);
        mvprintw(5+(i*2),40,"¥%.2f",xhead->b[i]);
        mvprintw(5+(i*2),64,"购票");
        mvchgat(5+(i*2),62,8,A_NORMAL,2,NULL);
        get = i;
    }
    while(1)
    {
        move_1(a[0],a[1],5+(get*2),5);
        k=a[0];
        l=a[1];
        if(a[1] == 62)
        {
            set = (k-5)/2;
            //strcpy(moviename,xhead->a[set]);
            Session(xhead->movie[set],xhead,set);
            a[0]=k;
            a[1]=l;
            goto loop;
        }
        else if(a[0] == 21 && a[1] == 60 && xhead->right != NULL)
        {
            clear();
            Menu_1(a[0],a[1]);
            xhead = xhead->right;
            for(i = 0;i < 6;i++)
            {
                if(!strcmp(xhead->a[i],"NULL"))
                {
                    get = i-1;
                    break;
                }
                mvprintw(5+(i*2),2,"%d",i+1);
                mvprintw(5+(i*2),16,"%s",xhead->a[i]);
                mvprintw(5+(i*2),40,"¥%.2f",xhead->b[i]);
                mvprintw(5+(i*2),64,"购票");
                mvchgat(5+(i*2),62,8,A_NORMAL,2,NULL);
                get = i;
            }
        }
        else if(a[0] == 21 && a[1] == 36 && xhead->left != NULL)
        {
            clear();
            Menu_1(a[0],a[1]);
            xhead = xhead->left;
            for(i = 0;i < 6;i++)
            {
                if(!strcmp(xhead->a[i],"NULL"))
                {
                    get = i-1;
                    break;
                }
                mvprintw(5+(i*2),2,"%d",i+1);
                mvprintw(5+(i*2),16,"%s",xhead->a[i]);
                mvprintw(5+(i*2),40,"¥%.2f",xhead->b[i]);
                mvprintw(5+(i*2),64,"购票");
                mvchgat(5+(i*2),62,8,A_NORMAL,2,NULL);
                get = i;
            }
        }
        else if(a[0] == 21 && a[1] == 12)
        {
            Menu_end();
            getch();
            endwin();
            exit(0);
        }
    }
}