void Exit()
{
	clear();
	box(stdscr,ACS_VLINE,ACS_HLINE);
	bkgd(COLOR_PAIR(6));
	mvprintw(13,34,"😊 谢谢使用😊 ");
	mvprintw(14,32,"😝 欢迎下次使用😝 ");
	mvchgat(12,24,30,A_NORMAL,2,NULL);
	mvchgat(13,24,30,A_NORMAL,2,NULL);
	mvchgat(14,24,30,A_NORMAL,2,NULL);
	mvchgat(15,24,30,A_NORMAL,2,NULL);
	getch();
	endwin();
	exit(0);
}
