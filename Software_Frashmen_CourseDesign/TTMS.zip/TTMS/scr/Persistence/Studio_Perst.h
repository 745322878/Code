/*
 * Studio_Perst.h
 *
 * Created on: 2015年6月25日
 *  Author on: Tang-tang
 */

#ifndef _STUDIO_PERST_H_
#define _STUDIO_PERST_H_

#include "../TTMS/scr/Service/Studio_Srv.h"

//在文件中存入演出厅函数
int Studio_Perst_Insert(const studio_t *data);

//在文件中更新演出厅函数
int Studio_Perst_Update(const studio_t *data);

//根据ID在文件中获取演出厅函数
int Studio_Perst_SelectByID(int id,studio_t *buf);

//在文件中获取所有演出厅函数
int Studio_Perst_SelectAll(studio_list_t list);

//根据ID在文件中删除演出厅函数
int Studio_Perst_DeleteByID(int id);


#endif