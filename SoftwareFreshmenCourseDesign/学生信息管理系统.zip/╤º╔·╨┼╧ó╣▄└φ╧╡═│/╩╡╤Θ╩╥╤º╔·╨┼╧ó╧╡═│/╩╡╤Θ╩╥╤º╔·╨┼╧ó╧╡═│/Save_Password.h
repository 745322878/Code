void Save_Password(struct student *phead)
{		
		struct student *ptemp=phead;

		FILE *fp;
		fp=fopen("password.txt","a+");
		for(ptemp;ptemp!=NULL;ptemp=ptemp->next )
		{
			fprintf(fp,"%s %s %s\n",ptemp->name,ptemp->id,ptemp->password );
		}
		fclose(fp);
}
