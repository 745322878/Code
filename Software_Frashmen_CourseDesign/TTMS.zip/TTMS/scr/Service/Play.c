/*
 * Play.c
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include "Play.h"
#include "../TTMS/scr/Common/list.h"
#include "../TTMS/scr/Persistence/Play_Persist.h"
#include <string.h>

//获取所有剧目服务
int Play_Srv_FetchAll(play_list_t list) {

    //  函数实现部分
    return Play_Perst_SelectAll(list);
}

//新增数据为data的剧目信息服务
int Play_Srv_Add(const play_t *data) {

    //函数实现部分
    return  Play_Perst_Insert(data);
}

//修改主键为ID的剧目信息服务
int Play_Srv_Modify(const play_t *data) {

    //函数实现部分
    return Play_Perst_Update(data);
}

//删除主键为ID的剧目信息服务
int Play_Srv_DeleteByID(int id) {

    //函数实现部分
    return Play_Perst_DeleteByID(id);
}

//查找主键为ID的剧目信息，并将其信息保存在buf所指的内存单元中
int Play_Srv_FetchByID(int id, play_t *buf) {

    //函数实现部分
    return Play_Perst_SelectByID(id,buf);
}

int Play_Srv_FetchByName(play_list_t list, char condt[]) {

    return Play_Perst_SelectByName(list,condt);
}

int Play_Srv_FilterByName(play_list_t list, char filter[]) {

    return Play_Perst_FilterByName(list,filter);
}