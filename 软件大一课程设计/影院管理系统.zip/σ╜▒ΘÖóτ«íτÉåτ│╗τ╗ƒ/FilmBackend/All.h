
#include<stdlib.h>
#include<string.h>
#include<curses.h>
#include<locale.h>
//#include<aio.h>

#include "Struct.h"
#include "Read_file.h"
#include "Save_file.h"
#include "Read_Screenings.h"
#include "Save_Screenings.h"
#include "Save_ScreeningsModify.h"

#include "Add.h"
#include "Show.h"
#include "SearchShow.h"
#include "Delete.h"
#include "Search.h"
#include "Modify.h"
#include "Sort.h"
#include "Exit.h"
#include "Seat.h"
#include "Screenings.h"
#include "ScreeningsModify.h"
#include "FormatSeat.h"
#include "FormatFilm.h"
#include "Format.h"
#include "Front.h" //前端

#include "Menu.h"
