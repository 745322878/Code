#define N 15
#define M 5
void Welcome()
{
	int i,barlen,percent,j;
	goto_xy(N,M);
	printf(" _________________________________________\n");
	goto_xy(0+N,1+M);
	printf("|\t\t\t\t\t|\n");
	goto_xy(0+N,2+M);
	printf("|\t��ӭ��½ѧ����Ϣ����ϵͳ\t|\n");
	goto_xy(0+N,3+M);
	printf("|\t\t\t\t\t|\n");
	goto_xy(0+N,4+M);
	printf("|________________________________________|\n");
	goto_xy(0+N,5+M);
	printf("|\t\t\t\t\t|\n");
	goto_xy(0+N,6+M);
	printf("|");
	goto_xy(14+N,6+M);
	printf("���ڵ�½��");
	for(i=0;i<3;i++)
	{
		printf(".");
		Sleep(100);
		
	}
	printf("\t\t|\n");
	goto_xy(0+N,7+M);
	printf("|\t\t\t\t\t|\n");
	barlen=40;
	for(i=0;i<101;i=i+10)
	{
		percent=i;
		goto_xy(N,8+M);
		putchar('|');
		for(j=1;j<=barlen;j++)
		{
			if(j<=barlen*percent/100)
				putchar('>');
			else 
				putchar(' ');
		}
		putchar('|');
		goto_xy(17+N,7+M);
		printf("%3d%%",percent);
		goto_xy(N,8+M);
		Sleep(100);
	}
	system("cls");
	
}