struct student						
{
	
	char name[20];
	char sex[2];
	float chinese;
	float math;
	float english;
	float aver;
	int data;
	int flag;
	char id[10];
	char password[10];
	struct student *next;
};