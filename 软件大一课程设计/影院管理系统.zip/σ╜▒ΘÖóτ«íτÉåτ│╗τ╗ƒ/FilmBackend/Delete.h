void Delete()
{
	struct film *phead=Read_file();
	struct film *ptemp=phead,*pre,*shead;
	shead = (struct film *)malloc(sizeof(struct film));
	shead->next = ptemp;
	char name[20];
	clear();
	curs_set(1);
	mvprintw(3,32,"删除影片信息");
	mvchgat(2,23,30,A_NORMAL,2,NULL);
	mvchgat(3,23,30,A_NORMAL,2,NULL);
	mvchgat(4,23,30,A_NORMAL,2,NULL);	

	attron(A_BOLD);
	mvprintw(8,30,"请输入影片名称:");
	attroff(A_BOLD);
	mvchgat(9,30,16,A_NORMAL,7,NULL);
	move(9,30);
	echo();
	attron(A_BOLD|COLOR_PAIR(7));
	scanw("%s",name);
	attroff(A_BOLD|COLOR_PAIR(7));
	noecho();
	curs_set(0);		//光标不回显
	if(phead==NULL)
	{
		mvprintw(15,30,"影库还木有影片！😏 ");
		mvchgat(15,28,22,A_NORMAL,2,NULL);
		getch();
	}
	else
	{
		while(shead!=NULL)
		{
			if(strcmp(shead->name,name)==0)
			{
				break;
			}
			pre = shead;
			shead = shead->next;
		}
		if(shead==NULL)
		{
			mvprintw(15,30,"没有这部影片！😁 ");
			mvchgat(15,28,20,A_NORMAL,2,NULL);
			getch();
		}
		else
		{
			pre->next=shead->next;
			mvprintw(15,32,"删除成功");
			mvchgat(15,30,16,A_NORMAL,2,NULL);
			getch();
		}
		Save_file(phead);
	}
}
