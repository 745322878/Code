//������
void Total_Rank(struct student *h)
{
	struct student *ptemp=h,*phead,*q,*r,*t;
	phead=(struct student *)malloc(sizeof(struct student ));
	phead->next=NULL;
	while(ptemp!=NULL)
	{
		if(phead->next==NULL)
		{
			phead->next=ptemp;
			q=ptemp->next;
			ptemp->next=NULL;
			ptemp=q;
		}
		else
		{
			q=phead->next;
			r=phead;
			while(q!=NULL&&ptemp->aver<q->aver )
			{
				r=q;
				q=q->next;
			}
			t=ptemp->next;
			ptemp->next=r->next;
			r->next=ptemp;
			ptemp=t;
		}
	}
	t=phead;
	phead=phead->next;
	free(t);
	TotalRank_Print(phead);
}