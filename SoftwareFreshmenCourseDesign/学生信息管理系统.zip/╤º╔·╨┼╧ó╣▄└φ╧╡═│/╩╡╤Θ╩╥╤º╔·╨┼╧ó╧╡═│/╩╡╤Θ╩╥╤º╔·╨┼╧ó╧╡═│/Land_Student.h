void Land_Student()
{
	struct student *ptemp;
	char id[10],password[10];
	char id1[10];
	int l=8;
	int t=0;
	int flag=0,times=0,i=0;
	char ch;
	FILE *fp;
	ptemp=Read_Password();
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t _______________________________________________ \t||\n");
	printf("\t||\t|\t________________________\t\t|\t||\n");
	printf("\t||\t|\t|       ID:             |\t\t|\t||\n");//8
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t| Password:             |\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|\t   ��¼\t\t|\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t\t\t\t\t\t|\t||\n");
	printf("\t||\t|_______________________________________________|\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");
	goto_xy(35,l);
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			
			id[i]=ch;
			putchar(ch);
			i++;
		}
		if(ch=='\b'&&i==0)
			id[0]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		} 
		if(i==8)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=7;
					t=1;
					break;
				}
			}
			if(t==1)
				continue;
			break;

		}
		
	}
	id[i]='\0';
	fflush(stdin);
	goto_xy(35,10);
	t=0;
	i=0;
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			password[i]=ch;
			putchar('*');
			i++;
		}
		if(ch=='\b'&&i==0)
			password[0]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		}
		if(i==6)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=5;
					t=1;
					break;
				}
			}
			if(t==1)
				continue;
			break;

		}
		
	}
	password[i]='\0';
	
	goto_xy(33,12);
	printf("%c",16);
	getch(); 
	while(times<2)
	{	
		times++;
		
		for(ptemp;ptemp!=NULL;ptemp=ptemp->next )
		{
			if( strcmp(ptemp->id ,id)==0 && strcmp(ptemp->password ,password)==0)
			{
				strcpy(id1,ptemp->id);
				flag=1;
				times=0;
				break;
			}
		}
		
		ptemp=Read_Password();

		if(flag==1)
			break;
		
		else
		{
			
			system("cls");
			goto_xy(24,14);
			printf("������%d�ε�¼����!\n",3-times);
			system("cls");
			printf("\n\n");
			printf("\t ________________________________________________________________\n");//64
			printf("\t| ______________________________________________________________ |\n");
			printf("\t||\t\t\t\t\t\t\t\t||\n");
			printf("\t||\t\t\t\t\t\t\t\t||\n");
			printf("\t||\t _______________________________________________ \t||\n");
			printf("\t||\t|\t________________________\t\t|\t||\n");
			printf("\t||\t|\t|       ID:             |\t\t|\t||\n");//8
			printf("\t||\t|\t|_______________________|\t\t|\t||\n");
			printf("\t||\t|\t| Password:             |\t\t|\t||\n");
			printf("\t||\t|\t|_______________________|\t\t|\t||\n");
			printf("\t||\t|\t|\t   ��¼\t\t|\t\t|\t||\n");
			printf("\t||\t|\t|_______________________|\t\t|\t||\n");
			printf("\t||\t|\t\t\t\t\t\t|\t||\n");
			printf("\t||\t|_______________________________________________|\t||\n");
			printf("\t||\t\t\t\t\t\t\t\t||\n");
			printf("\t||\t\t\t\t\t\t\t\t||\n");
			printf("\t||______________________________________________________________||\n");
			printf("\t|________________________________________________________________|\n");
			goto_xy(26,14);
			printf("������%d�ε�¼����!\n",3-times);
			goto_xy(35,8);
			t=0;
			i=0;
			while((ch=getch())!=13)
			{
				if(ch!='\b')
				{
					putchar(ch);
					id[i]=ch;
					i++;
				}
				if(ch=='\b'&&i==0)
				{
					id[0]='\0';
				}
				if(ch=='\b'&&i>0)
				{
					printf("\b \b");
					i--;
				}
				if(i==8)
				{
					while((ch=getch())!='\r')
					{
						if(ch=='\b')
						{
							printf("\b \b");
							i=7;
							t=1;
							break;
						}
					}
					if(t==1)
						continue;
					break;
				}
			}
			id[i]='\0';
			
			fflush(stdin);
			goto_xy(35,10);
			t=0;
			i=0;
			while((ch=getch())!='\r')
			{
				
				if(ch!='\b')
				{
					password[i]=ch;
					putchar('*');
					i++;
				}
				if(ch=='\b'&&i==0)
					password[0]='\0';
				if(ch=='\b'&& i>0)
				{
					printf("\b \b");
					i--;
				}
				if(i==6)
				{
					while((ch=getch())!='\r')
					{
						if(ch=='\b')
						{
							printf("\b \b");
							i=5;
							t=1;
							break;
						}
					}
					if(t==1)
						continue;
					break;
				}
				
			}
			password[i]='\0';
			goto_xy(33,12);
			printf("%c",16);
			getch();
			
			
			
		}
			
		for(ptemp;ptemp!=NULL;ptemp=ptemp->next )
		{
			if( strcmp(ptemp->id ,id)==0 && strcmp(ptemp->password ,password)==0)
			{
				strcpy(id1,ptemp->id);
				flag=1;
				times=0;
				break;
			}
		}
		ptemp=Read_Password();
		if(flag==1)
			break;
	}

	if(times==2)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|\t________________________\t\t|\t||\n");
		printf("\t||\t|\t|       ID:             |\t\t|\t||\n");//8
		printf("\t||\t|\t|_______________________|\t\t|\t||\n");
		printf("\t||\t|\t| Password:             |\t\t|\t||\n");
		printf("\t||\t|\t|_______________________|\t\t|\t||\n");
		printf("\t||\t|\t|\t   ��¼\t\t|\t\t|\t||\n");
		printf("\t||\t|\t|_______________________|\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(26,14);
		printf("������¼����,ϵͳ�˳���\n");
		Sleep(800);
		Exit();
		exit(1);
	}
	fp=fopen("Land_Student_file.txt","w");
	fprintf(fp,"%s\n",id1);
	fclose(fp);
}