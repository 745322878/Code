/*
 * Play.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef _PLAY_H_
#define _PLAY_H_

#include "../TTMS/scr/Common/common.h"

//剧目结构体
typedef enum {
    PLAY_TYPE_FILM=1,
    PLAY_TYPE_OPEAR=2,
    PLAY_TYPE_CONCERT=3
} play_type;

typedef enum {
    PLAY_RATE_CHILD = 1,
    PLAY_RATE_TEENAGE = 2,
    PLAY_RATE_ADULT = 3
} play_rating;

typedef struct {

    int             id;           //剧目ID
    char            name[40];     //剧目名称
    play_type       type;         //剧目类型
    char            area[9];      //剧目出品地区
    play_rating     rating;       //剧目等级
    int             duration;     //时长，以分钟为单位
    user_date_t     start_date;   //开始放映日期
    user_date_t     end_date;     //放映结束日期
    int             price;        //票价
}play_t;

typedef struct play_node {

    play_t data;
    struct play_node *next;
    struct play_node *prev;
}play_node_t, *play_list_t;

//获取所有剧目服务
int Play_Srv_FetchAll(play_list_t list);

//新增数据为data的剧目信息服务
int Play_Srv_Add(const play_t *data);

//修改主键为ID的剧目信息服务
int Play_Srv_Modify(const play_t *data);

//删除主键为ID的剧目信息服务
int Play_Srv_DeleteByID(int id);

//查找主键为ID的剧目信息，并将其信息保存在buf所指的内存单元中
int Play_Srv_FetchByID(int id, play_t *buf);

//根据剧目名称载入剧目，返回剧目个数
int Play_Srv_FetchByName(play_list_t list, char condt[]);

//根据剧目名称过滤词filter对list进行过滤，返回过滤后剩余剧目的数量
int Play_Srv_FilterByName(play_list_t list, char filter[]);

#endif