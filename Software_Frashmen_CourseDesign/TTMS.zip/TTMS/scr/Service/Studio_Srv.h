/*
 * Studio_Srv.h
 *
 * Created on: 2015年6月25日
 *  Author on: Tang-tang
 */

#ifndef _STUDIO_SRV_H_
#define _STUDIO_SRV_H_

#include "../TTMS/scr/Common/list.h"   //链表操作头文件
#include "../TTMS/scr/Service/EntityKey.h"    //获取主键头文件

typedef struct{
    int     id;                 //放映厅id
    char    name[30];           //放映厅名称
    int     linesCount;         //座位行数
    int     colsCount;          //座位列数
    int     seatsCount;         //座位数
} studio_t;

typedef struct studio_node {
    studio_t            data;              //放映厅数据
    struct studio_node  *next;   //后移指针
    struct studio_node  *prev;   //前移指针
} studio_node_t, *studio_list_t;


//添加新演出厅的业务逻辑层函数定义部分
int Srv_Add(const studio_t *data);

//修改演出厅的业务逻辑层函数定义部分
int Srv_Mod(const studio_t *data);

//根据ID删除演出厅业务逻辑层的函数定义部分
int Srv_Del(int id);

//获取所有演出厅的个数的函数定义部分
int Studio_Srv_FetchAll(studio_list_t list);

//根据ID获取演出厅业务逻辑层的函数定义部分
int Srv_FetchByID(int id,studio_t *buf);

//根据ID在链表list中查找对应的放映厅节点
studio_node_t *Srv_FindByID(studio_list_t list,int id);

#endif