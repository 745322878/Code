#include "Ticket_Persist.h"
#include "../TTMS/scr/Service/Ticket.h"
#include "../TTMS/scr/Service/Seat_Srv.h"
#include "../TTMS/scr/Common/list.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>

static const char TICKET_DATA_FILE[] = "Ticket.dat";
static const char TICKET_DATA_TEMP_FILE[] = "TicketTemp.dat";

int Ticket_Perst_Insert(ticket_list_t list){
	
	assert(NULL!=list);
	
	FILE *fp = fopen(TICKET_DATA_FILE, "ab");
	
	int rtn = 0;
	if (NULL == fp) {
		printf("Cannot open file %s!\n", TICKET_DATA_FILE);
		return 0;
	}

	rtn = fwrite(list, sizeof(ticket_t), 1, fp);

	fclose(fp);
	return rtn;
}

int Ticket_Perst_Delete(int schedule_id) {

	if(rename(TICKET_DATA_FILE, TICKET_DATA_TEMP_FILE)<0)
	{
	    	printf("Cannot open file %s!\n", TICKET_DATA_FILE);
	    	return 0;
	}
	FILE *fpSour, *fpTarg;
	fpSour = fopen(TICKET_DATA_TEMP_FILE, "rb");
	if (NULL == fpSour )
	{
		printf("Cannot open file %s!\n", TICKET_DATA_FILE);
		return 0;
	}

	fpTarg = fopen(TICKET_DATA_FILE, "wb");
	if ( NULL == fpTarg )
	{
		printf("Cannot open file %s!\n", TICKET_DATA_TEMP_FILE);
		return 0;
	}


	ticket_t buf;

	int found = 0;
	while (!feof(fpSour))
	{
		if (fread(&buf, sizeof(ticket_t), 1, fpSour))
		{
			if (schedule_id == buf.id)
			{
				found = 1;
				continue;
			}
			fwrite(&buf, sizeof(ticket_t), 1, fpTarg);
		}
	}

	fclose(fpTarg);
	fclose(fpSour);

	remove(TICKET_DATA_TEMP_FILE);
	return found;
}

int Ticket_Perst_SelectByID(int ID, ticket_t *buf) 
{
	assert(NULL!=buf);

	FILE *fp = fopen(TICKET_DATA_FILE, "rb");
	if (NULL == fp)
	{
		return 0;
	}

	ticket_t data;
	int found = 0;

	while (!feof(fp)) {
		if (fread(&data, sizeof(ticket_t), 1, fp)) {
			if (ID == data.id) {
				*buf = data;
				found = 1;
				break;
			}
        }
    }
    return found;
}

int Ticket_Perst_Update(const ticket_t * data){

    assert(NULL!=data);

	FILE *fp = fopen(TICKET_DATA_FILE, "rb+");
	if (NULL == fp) {
		printf("Cannot open file %s!\n", TICKET_DATA_FILE);
		return 0;
	}

	ticket_t buf;
	int found = 0;

	while (!feof(fp)) {
		if (fread(&buf, -sizeof(ticket_t), 1, fp)) {
			if (buf.id == data->id) {
				fseek(fp, sizeof(ticket_t), SEEK_CUR);
				fwrite(data, sizeof(ticket_t), 1, fp);
				found = 1;
				break;
			}

		}
	}
	fclose(fp);

	return found;
}


int Ticket_Perst_SelectAll(ticket_list_t list) {
	
    ticket_node_t *newNode;
	ticket_t data;
	int recCount = 0;

	assert(NULL!=list);

	List_Free(list, ticket_node_t);

	FILE *fp = fopen(TICKET_DATA_FILE, "rb");
	if (NULL == fp) {
		return 0;
	}

	while (!feof(fp)) {
		if (fread(&data, sizeof(ticket_t), 1, fp)) {
			newNode = (ticket_node_t*) malloc(sizeof(ticket_node_t));
			if (!newNode) {
				printf("Warning, Memory OverFlow!!!\n Cannot Load more Data into memory!!!\n");
				break;
			}
			newNode->data = data;
			List_AddTail(list, newNode);
			recCount++;
		}
	}
	fclose(fp);
	return recCount;
}




int Ticket_Perst_SelectBySchID(ticket_list_t list, int schedule_id){
 	
	ticket_node_t *newNode;
	
	ticket_t data;
	int recCount = 0;

	assert(NULL!=list);

	List_Free(list, ticket_node_t);

	FILE *fp = fopen(TICKET_DATA_FILE, "rb");
	if (NULL == fp) {
		return 0;
	}

	while (!feof(fp)) {
		if (fread(&data.schedule_id, sizeof(ticket_t), 1, fp)) {
			newNode = (ticket_node_t*) malloc(sizeof(ticket_node_t));
			if (!newNode) {
				printf("Warning, Memory OverFlow!!!\n Cannot Load more Data into memory!!!\n");
				break;
			}
			newNode->data.schedule_id = data.schedule_id;
			List_AddTail(list, newNode);
			recCount++;
		}
	}
	fclose(fp);
	return recCount;
}

/*
//根据票主键列表载入票
int Ticket_Perst_SelectByKeyList(ticket_list_t list, entkey_list_t keyList) {
	
    ticket_node_t *newNode;
	 
	entity_key_t data;
	int recCount = 0;

	assert(NULL!=list);

	List_Free(list, ticket_node_t);

	FILE *fp = fopen(TICKET_DATA_FILE, "rb");
	if (NULL == fp) { 
		return 0;
	}

	while (!feof(fp)) {
		if (fread(&data, sizeof(ticket_t), 1, fp)) {
			newNode = (ticket_node_t*) malloc(sizeof(ticket_node_t));
			if (!newNode) {
				printf("Warning, Memory OverFlow!!!\n Cannot Load more Data into memory!!!\n");
				break;
			}
			newNode->data = data;
			List_AddTail(list, newNode);
			recCount++;
		}
	}
	fclose(fp);
	return recCount;
}
 */
