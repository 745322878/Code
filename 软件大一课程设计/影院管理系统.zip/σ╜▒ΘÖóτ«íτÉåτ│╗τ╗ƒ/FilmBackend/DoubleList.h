int k=0;
struct ShowFilm *chuan(struct film *phead)
{
	struct ShowFilm *pnew,*ptemp,*xhead;
	int i;
	xhead=(struct ShowFilm *)malloc(sizeof(struct ShowFilm));
	xhead->left=NULL;
	xhead->right=NULL;
	ptemp=xhead;
	while(1)
	{
		pnew=(struct ShowFilm *)malloc(sizeof(struct ShowFilm));
		for(i=0;i<2&&phead!=NULL;i++)
		{
			strcpy(pnew->name[i],phead->name);
			strcpy(pnew->director[i],phead->director);
			strcpy(pnew->actor[i],phead->actor);
			pnew->score[i]=phead->score;
			pnew->time[i]=phead->time;
			pnew->year[i]=phead->year;
			pnew->month[i]=phead->month;
			pnew->day[i]=phead->day;
			pnew->price[i]=phead->price;
			phead=phead->next;

		}
		ptemp->right=pnew;
		pnew->left=ptemp;
		pnew->right=NULL;
		ptemp=pnew;
		k++;
		if(phead=NULL)
		{
			strcpy(ptemp->name[i],"NULL");
					break;
		}
	}
	xhead=xhead->next;
	xhead->left=NULL;
	return xhead;
}

