/*
 * Seat_Persist.c
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include "Seat_Persist.h"
#include "../TTMS/scr/Service/Seat_Srv.h"
#include "../TTMS/scr/Common/list.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>

static const char SEAT_DATA_FILE[] = "Seat.dat";
static const char SEAT_DATA_TEMP_FILE[] = "SeatTmp.dat";

//在文件中存入单个座位
int Seat_Perst_Insert(const seat_t *data) {

    //函数实现部分
    int     rtn = 0;
    FILE    *fp;
    fp = fopen(SEAT_DATA_FILE,"ab");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",SEAT_DATA_FILE);
        getchar();
        return 0;
    }
    rtn = fwrite( data, sizeof(seat_t), 1, fp);
    
    fclose(fp);
    return rtn;
}

//在文件中批量存入座位
int Seat_Perst_InsertBatch(seat_list_t list) {

    //函数实现部分
    FILE            *fp;
    seat_node_t     *p = list -> next;
    int             rtn = 0;
    fp = fopen(SEAT_DATA_FILE,"ab");
    if (fp == NULL) {
        printf("Failed to open file %s!\n[Enter] to return!",SEAT_DATA_FILE);
        getchar();
        return 0;
    }
    while (p != list) {
        if(fwrite( &(p->data), sizeof(seat_t), 1, fp)){
            rtn++;
            p = p->next;
        }
    }
    fclose(fp);
    return rtn;
}

//在文件中更新座位
int Seat_Perst_Update(const seat_t *data) {

    //函数实现部分
    int         found = 0;
    seat_t      buf;
    FILE        *fp;
    fp = fopen(SEAT_DATA_FILE,"rb+");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",SEAT_DATA_FILE);
        getchar();
        return 0;
    }
    
    while(!feof(fp))
    {
        if(fread( &buf, sizeof(seat_t), 1, fp))
        {
            if(buf.id == data->id)
            {
                fseek(fp,-sizeof(seat_t),SEEK_CUR);       //移到当前行的头部
                fwrite( data, sizeof(seat_t), 1, fp);
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
}

//根据ID在文件中删除座位
int Seat_Perst_DeleteByID(int ID) {

    //函数实现部分
    int         found = 0;
    FILE        *fdata, *ftemp;
    seat_t      buf;
    system("cp Seat.dat SeatTmp.dat");
    system("rm Seat.dat");
    system("touch Seat.dat");
    
    fdata = fopen(SEAT_DATA_FILE,"wb");
    ftemp = fopen(SEAT_DATA_TEMP_FILE,"rb");
    
    if(fdata == NULL || ftemp == NULL)
    {
        printf("Failed to open file!\n[Enter] to return");
        getchar();
        return 0;
    }
    
    while(!feof(ftemp))
    {
        if(fread( &buf, sizeof(seat_t), 1, ftemp))
        {
            if(buf.id != ID)
            {
                fwrite( &buf, sizeof(seat_t), 1, fdata);
            }
            else if(buf.id == ID)
            {
                found = 1;
            }
        }
    }
    
    fclose(ftemp);
    fclose(fdata);
    system("rm SeatTmp.dat");
    
    return found;
}

//根据演出厅ID在文件中删除其所有座位
int Seat_Perst_DeleteAllByRoomID(int roomID) {

    //函数实现部分
    int         found = 0;
    FILE        *fdata, *ftemp;
    seat_t      buf;
    system("cp Seat.dat SeatTmp.dat");
    system("rm Seat.dat");
    system("touch Seat.dat");
    
    fdata = fopen(SEAT_DATA_FILE,"wb");
    ftemp = fopen(SEAT_DATA_TEMP_FILE,"rb");
    
    if(fdata == NULL || ftemp == NULL)
    {
        printf("Failed to open file!\n[Enter] to return");
        getchar();
        return 0;
    }
    
    while(!feof(ftemp))
    {
        if(fread( &buf, sizeof(seat_t), 1, ftemp))
        {
            if(buf.roomID != roomID)
            {
                fwrite( &buf, sizeof(seat_t), 1, fdata);
            }
            else if(buf.roomID == roomID)
            {
                found = 1;
            }
        }
    }
    
    fclose(ftemp);
    fclose(fdata);
    system("rm SeatTmp.dat");
    
    return found;
}

//根据ID在文件中获取座位
int Seat_Perst_SelectByID(int ID, seat_t *buf) {

    //函数实现部分
    int         found = 0;
    FILE        *fp;
    seat_t      data;
    fp = fopen(SEAT_DATA_FILE,"rb");
    if(fp == NULL)
    {
        printf("Failed to open file %s!\n[Enter] to return!",SEAT_DATA_FILE);
        getchar();
        return 0;
    }
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(seat_t), 1, fp))
        {
            if(ID == data.id)
            {
                *buf = data;
                found = 1;
                break;
            }
        }
    }
    fclose(fp);
    return found;
}

//在演出厅中获取所有座位
int Seat_Perst_SelectAll(seat_list_t list) {

    //函数实现部分
    seat_t          data;
    seat_node_t     *newNode;
    int             recCount = 0;
    FILE            *fp;
    fp = fopen(SEAT_DATA_FILE,"rb");
    if(fp == NULL)
    {
        return 0;
    }
    
    List_Free(list,seat_node_t);
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(seat_t), 1, fp))
        {
            newNode = (seat_node_t *)malloc(sizeof(seat_node_t));
            if(newNode)
            {
                newNode->data = data;
                List_AddTail(list,newNode);
                recCount++;
            }
            else
            {
                printf("Memory application failure!!\n[Enter] to continue!");
                getchar();
                break;
            }
        }
    }
    fclose(fp);
    return recCount;
}

//根据演出厅ID获取其所有座位
int Seat_Perst_SelectByRoomID(seat_list_t list, int roomID) {

    //函数实现部分
    seat_t          data;
    seat_node_t     *newNode;
    int             recCount = 0;
    FILE            *fp;
    fp = fopen(SEAT_DATA_FILE,"rb");
    if(fp == NULL)
    {
        return 0;
    }
    
    List_Free(list,seat_node_t);
    
    while(!feof(fp))
    {
        if(fread( &data, sizeof(seat_t), 1, fp))
        {
            newNode = (seat_node_t *)malloc(sizeof(seat_node_t));
            if(newNode)
            {
                newNode->data = data;
                if(data.roomID == roomID)
                {
                    List_AddTail(list,newNode);
                    recCount++;
                }
            }
            else
            {
                printf("Memory application failure!!\n[Enter] to continue!");
                getchar();
                break;
            }
        }
    }
    fclose(fp);
    return recCount;
}