
//void Exit();
void Administrator_Modify_Password()
{
	struct student *phead;
	char new_password[10];
	int t=0,i=0;
	char ch;
	phead=(struct student *)malloc(sizeof(struct student ));
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t _______________________________________________ \t||\n");
	printf("\t||\t|\t________________________\t\t|\t||\n");
	printf("\t||\t|\t|                       |\t\t|\t||\n");//8
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|New_Password:          |\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|\t    �޸�\t|\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t\t\t\t\t\t|\t||\n");
	printf("\t||\t|_______________________________________________|\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");
	goto_xy(38,10);
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			new_password[i]=ch;
			putchar('*');
			i++;
		}
		if(ch=='\b'&&i==0)
			new_password[0]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		}
		if(i==6)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=5;
					t=1;
					break;
				}
			}
			if(t==1)
				continue;
			break;

		}
		
	}
	new_password[i]='\0';
	goto_xy(33,12);
	printf("%c",16);
	getch();
	strcpy(phead->password,new_password);
	Save_Administrator_Password(phead);
	Sleep(600);
}



