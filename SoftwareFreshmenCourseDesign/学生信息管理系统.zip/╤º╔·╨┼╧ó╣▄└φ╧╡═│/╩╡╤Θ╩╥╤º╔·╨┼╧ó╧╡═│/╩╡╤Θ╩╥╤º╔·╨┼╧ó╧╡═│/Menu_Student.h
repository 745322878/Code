void Menu_Student( )
{
	struct student *phead,*ptemp;
	int  flag;
	int l=9;
	ptemp=Read_Password();
	while(1)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|                                               |\t||\n");
		printf("\t||\t|\t\t    1.��ѯ�ɼ�\t\t\t|\t||\n");//9
		printf("\t||\t|\t\t    2.������\t\t\t|\t||\n");
		printf("\t||\t|\t\t    3.���Ƴɼ�����\t\t|\t||\n");
		printf("\t||\t|\t\t    4.�޸�����\t\t\t|\t||\n");
		printf("\t||\t|\t\t    0.\t����\t\t\t|\t||\n");//13
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(34,l);
		printf("%c",16);
		flag=getch();
		if(flag==Down )
		{
			l++;
			while(l==14)
				l=9;
		}
		if(flag==Up)
		{
			l--;
			while(l==8)
				l=13;
		}
		if(flag==13)
		{
			if(l==9)
			{
				Student_Search();
			}
			if(l==10)
			{
				system("cls");
				phead=Read_file();
				Total_Rank(phead);	
			}
			if(l==11)
			{
				system("cls");
				Rank();
			}
			if(l==12)
			{
				system("cls");
				Student_Modify_Password();
				break;
			}
			if(l==13)
			{
				system("cls");
				break;
			}
		}
	}
}
