struct session
{
    float start;
    float end;
    int movieRoom;
    struct session *next;
};

struct readFilm
{
    char a[6][50];
    float b[6];
    char Director[6][20];   //导演
    char Actor[6][20];      //主演
    float Score[6];         //评分
    int Times[6];           //时长
    char Type[6][10];       //类型
    int Year[6];
    int Month[6];
    int Day[6];
    struct session *movie[6];
    struct readFilm *right;
    struct readFilm *left;
};

struct readSe
{
    float start[10];
    float end[10];
    int room[10];
    struct readSe *left;
    struct readSe *right;
};

struct film
{
	char name[50];      //影片名称
	char director[20];  //导演名
	char actor[20];     //主演名
	float score;        //评分
	int time;           //片长
	char type[10];      // 类型
	int year;
	int month;
	int day;

    
	float price;        //价格
    struct session *movieSe;
	struct film *next;
};

struct readFilm *chuan(struct film *phead);
void byTicket(struct film *phead);
struct readSe *pack(struct session *yhead);
void Session(struct session *yhead,struct readFilm *head,int n);
void menu_seat(struct readSe *shead,int n);
void set_seat(struct readSe *shead,int n,struct readFilm *head,int u);
//void save_movie(struct readFilm *head,int n,struct readSe *shead,int i);




