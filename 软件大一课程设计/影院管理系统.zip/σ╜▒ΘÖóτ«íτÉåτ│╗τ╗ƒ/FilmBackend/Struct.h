struct film
{
	char name[20];			//影片名称
	char director[20];		//	导演名
	char actor[20];			//	主演名
	char type[10];
	float score;			//	评分
	int time;				//	片长
	int year;				//	上映日期
	int month;
	int day;
	float price;            //价格  

	int movieroom;
	float start_time;			//	电影开始时间
	float  end_time;				//	电影结束时间
	struct film *next;
	struct film *link;
};
struct ShowFilm
{
	char name[2][20];
	char director[2][20];
    char actor[2][20];
    char type[2][20];
    float score[2];
    int time[2];
	int year[2];
    int month[2];
    int day[2];
    float price[2];
    struct ShowFilm *left;
    struct ShowFilm *right;
};         
