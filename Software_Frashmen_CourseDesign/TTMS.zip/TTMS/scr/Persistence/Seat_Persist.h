/*
 * Seat_Persist.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef _SEAT_PERSIST_H_
#define _SEAT_PERSIST_H_

#include "../TTMS/scr/Service/Seat_Srv.h"

//在文件中存入单个座位
int Seat_Perst_Insert(const seat_t *data);

//在文件中批量存入座位
int Seat_Perst_InsertBatch(seat_list_t list);

//在文件中更新座位
int Seat_Perst_Update(const seat_t *data);

//根据ID在文件中删除座位
int Seat_Perst_DeleteByID(int ID);

//根据演出厅ID在文件中删除其所有座位
int Seat_Perst_DeleteAllByRoomID(int roomID);

//根据ID在文件中获取座位
int Seat_Perst_SelectByID(int ID, seat_t *buf);

//在演出厅中获取所有座位
int Seat_Perst_SelectAll(seat_list_t list);

//根据演出厅ID获取其所有座位
int Seat_Perst_SelectByRoomID(seat_list_t list, int roomID);

#endif