
	#include<stdlib.h>
	#include<string.h>
	#include<windows.h>
	#include<conio.h>
	#include "Define.h"
	#include "Struct_student.h"
	#include "goto_xy.h"
	#include "Welcome.h"

	//
	#include "Save_Password.h"
	#include "Save_Teacher_Password.h"
	#include "Save_Administrator_Password.h"
	#include "Read_Password.h"
	#include "Read_Teacher_Password.h"
	#include "Read_Administrator_Password.h"

	#include "Save_file.h"
	#include "Read_file.h"

	//#include "Input.h"
	#include "Enter.h"
	#include "Search.h"
	#include "Modify.h"
	#include "Print.h"
	#include "Teacher_Modify_Password.h"
	//
	#include "TotalRank_Print.h"
	#include "Total_Rank.h"
	#include "Rank.h"
	#include "Student_Modify_Password.h"
	#include "Student_Search.h"
	//
	#include "Administrator_Modify.h"
	#include "Administrator_Modify_Teacher.h"
	#include "Administrator_Modify_Information.h"
	#include "Administrator_Modify_Password.h"
	#include "Zhuce.h"
	#include "Zhuce_Teacher.h"
	#include "Exit.h"	

	#include "Land_Student.h"
	#include "Land_Teacher.h"
	#include "Land_Administrator.h"
	#include "Menu_Student.h"
	#include "Menu_Teacher.h"
	#include "Menu_Administrator.h"
	#include "Menu_Land.h"

