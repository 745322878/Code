/*
 * Seat_Srv.c
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include "Seat_Srv.h"
#include <stdio.h>
#include <stdlib.h>
#include "../TTMS/scr/Common/list.h"
#include "../TTMS/scr/Persistence/Seat_Persist.h"
#include "../TTMS/scr/Persistence/EntityKey_Persist.h"

//演出厅座位初始化服务
int Seat_Srv_RoomInit(seat_list_t list, int roomID, int rowsCount, int colsCount) {

    //函数实现部分
    int         seatID;
    seat_node_t *p;
    int i,j;
    int count = rowsCount * colsCount;
    
    List_Init(list,seat_node_t);
    
    seatID = EntKey_Perst_GetNewKeys("seat",count);
    for (i = 0; i < rowsCount; i++) {
        for (j = 0; j < colsCount; j++) {
            p = (seat_node_t *)malloc(sizeof(seat_node_t));
            p->data.id = seatID;
            p->data.roomID = roomID;
            p->data.row = i+1;
            p->data.column = j+1;
            p->data.status = 1;
            List_AddTail(list,p);
            seatID++;
        }
    }
    if(Seat_Perst_InsertBatch(list))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

//单个添加座位函数
int Seat_Srv_Add(const seat_t *data) {

    //函数实现部分
    return Seat_Perst_Insert(data);
}

//批量添加座位函数
int Seat_Srv_AddBatch(seat_list_t list) {

    //函数实现部分
    return Seat_Perst_InsertBatch(list);
}

//修改座位函数
int Seat_Srv_Modify(const seat_t *data) {

    //函数实现部分
    return Seat_Perst_Update(data);
}

//根据ID删除座位
int Seat_Srv_DeleteByID(int id) {

    //函数实现部分
    return Seat_Perst_DeleteByID(id);
}

//根据演出厅ID删除其所有座位
int Seat_Srv_DeleteAllByRoomID(int roomID) {

    //函数实现部分
    return Seat_Perst_DeleteAllByRoomID(roomID);
}

//根据ID获取座位
int Seat_Srv_FetchByID(int id, seat_t *data) {

    //函数实现部分
    return Seat_Perst_SelectByID(id,data);
}

//根据演出厅ID提取有效座位
int Seat_Srv_FetchValidByRoomID(seat_list_t list, int roomID) {

    //函数实现部分
    seat_node_t     *p = list->next;
    int             count;
    count = Seat_Perst_SelectByRoomID(list,roomID);
    
    while (p != list) {
        if (p->data.status == 9) {
            count--;
        }
        p = p->next;
    }
    //Seat_Srv_SortSeatList(list);
    return count;
}

//根据演出厅ID获取座位链表
int Seat_Srv_FetchByRoomID(seat_list_t list, int roomID) {

    //函数实现部分
    int             SeatCount;
    SeatCount = Seat_Perst_SelectByRoomID(list,roomID);
    seat_node_t     *p = list->next;
    
    while (p != list) {
        if (p->data.status == 9) {
            List_DelNode(p);
            SeatCount--;
        }
        p = p->next;
    }
    //Seat_Srv_SortSeatList(list);
    return SeatCount;
}

//根据行列号获取座位
seat_node_t *Seat_Srv_FindByRowCol(seat_list_t list, int row, int column) {

    //函数实现部分
    seat_node_t     *p = list->next;
    
    while (p != list) {
        if (p->data.row == row && p->data.column == column) {
            return p;
        }
        p = p->next;
    }
    return NULL;
}

//根据ID获取对应链表上座位结点
seat_node_t *Seat_Srv_FindByID(seat_list_t list, int seatID) {

    //函数实现部分
    seat_node_t     *p = list->next;
    
    while (p != list) {
        if (p->data.id == seatID) {
            return p;
        }
        p = p->next;
    }
    return NULL;
}

//对座位链表list进行排序函数
void Seat_Srv_SortSeatList(seat_list_t list) {

    //函数实现部分
    seat_node_t     *listLeft;
    seat_node_t     *p;
    if (List_IsEmpty(list)) {
        return ;
    }
    list->prev->next = NULL;
    listLeft = list->next;
    list->next = list->prev = list;
    do{
        p = listLeft;
        listLeft = listLeft -> next;
        Seat_Srv_AddToSoftedList(list,p);
    }while(listLeft != NULL);
}

//将结点node加入到已排序链表list中
void Seat_Srv_AddToSoftedList(seat_list_t list, seat_node_t *node) {

    //函数实现部分
    seat_node_t     *p;
    if (List_IsEmpty(list)) {
        List_AddTail(list,node);
    }
    else
    {
        p = list->next;
        while (p != list) {
            if (!(p->data.row < node->data.row ||
                (p->data.row == node->data.row &&
                 p->data.column < node->data.column))) {
                    List_InsertBefore(p,node);
                    break;
            }
            else{
                p = p->next;
            }
        }
    }
}