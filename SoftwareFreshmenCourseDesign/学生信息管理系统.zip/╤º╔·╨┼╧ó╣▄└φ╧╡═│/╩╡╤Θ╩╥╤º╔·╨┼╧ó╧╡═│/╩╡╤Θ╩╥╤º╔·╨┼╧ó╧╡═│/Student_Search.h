
void Student_Search()
{
	struct student *p,*ptemp,*phead,*r;
	FILE *fp;
	fp=fopen("Land_Student_file.txt","r");
	phead=(struct student *)malloc(sizeof(struct student));
	phead->next=NULL;
	r=phead;
	while(!feof(fp))
	{
		ptemp=(struct student *)malloc(sizeof(struct student));
		fscanf(fp,"%s\n",ptemp->id );
		r->next=ptemp;
		r=ptemp;
	}
	r->next=NULL;
	fclose(fp);
	phead=phead->next ;
	p=Read_file();
	for(p;p!=NULL;p=p->next )
	{
		if(strcmp(p->id ,phead->id )==0)
				break;
	}
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t\t_______________________________________________\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");//8
	printf("\t\t����\tѧ��\t����\t��ѧ\tӢ��\tƽ����\t\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t%s\t%s  %1.2f\t%1.2f\t%1.2f\t%1.2f\t\t\n",p->name ,p->id ,p->chinese ,p->math ,p->english,p->aver);
	printf("\t\t\t\t\t\t\t\t\t\n");
	printf("\t\t_______________________________________________\t\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");
	getch();

}