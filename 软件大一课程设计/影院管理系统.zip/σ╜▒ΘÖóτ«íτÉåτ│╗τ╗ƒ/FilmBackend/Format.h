void Format()
{
	FILE *fp;
	int line=9,flag;
	while(1)
	{
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE);
		bkgd(COLOR_PAIR(6));

		
		attron(A_BOLD);
		mvprintw(3,35,"格式化");
		attroff(A_BOLD);
		mvchgat(2,23,30,A_NORMAL,2,NULL);
		mvchgat(3,23,30,A_NORMAL,2,NULL);
		mvchgat(4,23,30,A_NORMAL,2,NULL);

		attron(A_BOLD);         //输出修饰
		mvprintw(9,32,"影片信息");
		attroff(A_BOLD);        //关闭输出修饰
		mvchgat(8,28,15,A_NORMAL,2,NULL);
		mvchgat(9,28,15,A_NORMAL,2,NULL);
	    mvchgat(10,28,15,A_NORMAL,2,NULL);
	
		attron(A_BOLD);         //输出修饰
        mvprintw(14,32,"座位信息");
        attroff(A_BOLD);        //关闭输出修饰
        mvchgat(13,28,15,A_NORMAL,2,NULL);
        mvchgat(14,28,15,A_NORMAL,2,NULL);
        mvchgat(15,28,15,A_NORMAL,2,NULL);
		
		mvprintw(19,34,"返回");
		mvchgat(18,28,15,A_NORMAL,2,NULL);
		mvchgat(19,28,15,A_NORMAL,2,NULL);
		mvchgat(20,28,15,A_NORMAL,2,NULL);
										
		mvchgat(line-1,28,15,A_BLINK,1,NULL);
		mvchgat(line,28,15,A_BLINK,1,NULL);
		mvchgat(line+1,28,15,A_BLINK,1,NULL);
		flag=getch();
		if(flag==KEY_DOWN)
		{
			line+=5;
			if(line==24)				
				line=9;
		}
		else if(flag==KEY_UP)
		{
			line-=5;
			if(line==4)
					line=19;
		}
		else if(flag=='\n'||flag=='\r')
		{
			if(line==9)
					FormatFilm();
			else if(line==14)
					FormatSeat();
			else 
				break;

		}
	}
}
