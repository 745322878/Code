
void Exit();
void Teacher_Modify_Password()
{
	struct student *phead,*ptemp,*p,*t;
	char new_password[10];
	int t1=0,i=0;
	char ch;
	FILE *fp;
	fp=fopen("Land_Teacher_file.txt","r");
	phead=(struct student *)malloc(sizeof(struct student));
	phead->next=NULL;
	while(!feof(fp))
	{
		ptemp=(struct student *)malloc(sizeof(struct student));
		fscanf(fp,"%s\n",ptemp->id );
		phead->next=ptemp;
	}
	ptemp->next=NULL;
	fclose(fp);
	phead=phead->next ;
	t=Read_Teacher_Password();
	p=t;
	for(p;p!=NULL;p=p->next )
	{
		if(strcmp(p->id ,phead->id )==0)
				break;
	}
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t _______________________________________________ \t||\n");
	printf("\t||\t|\t________________________\t\t|\t||\n");
	printf("\t||\t|\t|                       |\t\t|\t||\n");//8
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|New_Password:          |\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|\t    �޸�\t|\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t\t\t\t\t\t|\t||\n");
	printf("\t||\t|_______________________________________________|\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");
	goto_xy(38,10);
	t1=0;
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			new_password[i]=ch;
			putchar(ch);
			i++;
		}
		if(ch=='\b'&&i==0)
			new_password[0]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		}
		if(i==6)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=5;
					t1=1;
					break;
				}
			}
			if(t1==1)
				continue;
			break;
		}
		
	}
	new_password[i]='\0';
	goto_xy(33,12);
	printf("%c",16);
	getch();
	strcpy(p->password,new_password);
	fp=fopen("teacher_password.txt","w");
	for(t;t!=NULL;t=t->next )
	{
		fprintf(fp,"%s %s %s\n",t->name,t->id,t->password );
	}
	fclose(fp);
}
