/*
 * Play_Persist.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef _PLAY_PERSIST_H_
#define _PLAY_PERSIST_H_

#include "../TTMS/scr/Service/Play.h"

//将参数所指的剧目信息写入剧目文件中
int Play_Perst_Insert(play_t *data);

//将参数所指的剧目信息更新到剧目文件中
int Play_Perst_Update(play_t *data);

//按照id从文件中删除剧目数据
int Play_Perst_DeleteByID(int id);

//从文件中载入所有剧目
int Play_Perst_SelectAll(play_list_t list);

//按照id从文件中查找剧目信息
int Play_Perst_SelectByID(int id,play_t *buf);

//按照名称查找剧目
int Play_Perst_SelectByName(play_list_t list, char condt[]);

//按照名称过滤剧目
int Play_Perst_FilterByName(play_list_t list, char filter[]);

#endif