void Search()
{
	struct film *phead=Read_file();
    struct film *ptemp=phead,*shead;
	struct film *t;
	char name[20];
	int flag,line=8;
	int print_line=1,item=0,tline;
	//float price,i;
	shead=(struct film *)malloc(sizeof(struct film));
	shead->next=NULL;
	t=shead;
	while(1)
	{
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE);
		bkgd(COLOR_PAIR(6));
		noecho();
		mvprintw(3,32,"查询影片信息");
		mvchgat(2,23,30,A_NORMAL,2,NULL);
		mvchgat(3,23,30,A_NORMAL,2,NULL);
		mvchgat(4,23,30,A_NORMAL,2,NULL);
		
		attron(A_BOLD);
		mvprintw(8,34,"影片名称");
		attroff(A_BOLD);
		mvchgat(8,30,16,A_NORMAL,2,NULL);

		attron(A_BOLD);
		mvprintw(10,35,"导演名");
		attroff(A_BOLD);
		mvchgat(10,30,16,A_NORMAL,2,NULL);		
	
		attron(A_BOLD);
		mvprintw(12,35,"主演名");
		attroff(A_BOLD);
		mvchgat(12,30,16,A_NORMAL,2,NULL);
		
		attron(A_BOLD);
		mvprintw(14,36,"返回");
		attroff(A_BOLD);
		mvchgat(14,30,16,A_NORMAL,2,NULL);
		
		mvchgat(line,30,16,A_BLINK,1,NULL);
		flag=getch();
		echo();
		if(flag==KEY_DOWN)
		{
			line+=2;
			if(line==16)
				line=8;
		}
		else if(flag==KEY_UP)
		{
			line-=2;
			if(line==6)
				line=14;
		}
		else if(flag=='\r'||flag=='\n')
		{
			if(line==8)
			{
				mvchgat(line+1,30,16,A_NORMAL,7,NULL);
				curs_set(1);
				move(line+1,30);
				attron(A_BOLD|COLOR_PAIR(7));
				keypad(stdscr,0);
				scanw("%s",name);

				attroff(A_BOLD|COLOR_PAIR(7));
				keypad(stdscr,1);
				curs_set(0);
				
				clear();
				box(stdscr,ACS_VLINE,ACS_HLINE);
				bkgd(COLOR_PAIR(6));
				noecho();
				
				if(phead==NULL)
				{
						mvchgat(12,30,16,A_NORMAL,2,NULL);
						attron(A_BOLD|COLOR_PAIR(2));
						mvprintw(12,32,"没有此电影!😁 ");
						attroff(A_BOLD|COLOR_PAIR(2));
						
				}
				else
				{
					while(ptemp!=NULL)
					{
						if(memcmp(ptemp->name,name,strlen(name))==0)
						{
							t->next=ptemp;
							t=ptemp;
							item=1;
						}
						ptemp=ptemp->next;
					
					}
					t->next=NULL;
					shead=shead->next;
					//Show(shead);
					if(item==0)
					{
						mvchgat(12,30,16,A_NORMAL,2,NULL);
						attron(A_BOLD|COLOR_PAIR(2));
						mvprintw(12,32,"没有此电影!😁 ");
						attroff(A_BOLD|COLOR_PAIR(2));
		
					}
					Show(shead);
				}
				break;
			}
			
			else if (line==10)
			{
				mvchgat(line+1,30,16,A_NORMAL,7,NULL);
				curs_set(1);
				move(line+1,30);
				attron(A_BOLD|COLOR_PAIR(7));
				keypad(stdscr,0);
				scanw("%s",name);
			
				attroff(A_BOLD|COLOR_PAIR(7));
			   	keypad(stdscr,1);
				curs_set(0);
					
				clear();
				box(stdscr,ACS_VLINE,ACS_HLINE);
				bkgd(COLOR_PAIR(6));
				noecho();
				
				if(phead==NULL)
				{
						mvchgat(12,30,16,A_NORMAL,2,NULL);
						attron(A_BOLD|COLOR_PAIR(2));
						mvprintw(12,32,"没有此电影!😁 ");
						attroff(A_BOLD|COLOR_PAIR(2));
					
				}
				else
				{
					while(ptemp!=NULL)
					{
						if(memcmp(ptemp->director,name,strlen(name))==0)
						{
								t->next=ptemp;
								t=ptemp;
								item=1;
						}
						ptemp=ptemp->next;
											
					}
					t->next=NULL;
					shead=shead->next;
				//	Show(shead);
					if(item==0)
					{
						mvchgat(12,30,16,A_NORMAL,2,NULL);
						attron(A_BOLD|COLOR_PAIR(2));
						mvprintw(12,32,"没有此电影!😁 ");
						attroff(A_BOLD|COLOR_PAIR(2));
						
					}
					Show(shead);
				}
				break;
			}
			else if (line==12)
			{
				mvchgat(line+1,30,16,A_NORMAL,7,NULL);
				curs_set(1);
				move(line+1,30);
				attron(A_BOLD|COLOR_PAIR(7));
				keypad(stdscr,0);
				scanw("%s",name);

				attroff(A_BOLD|COLOR_PAIR(7));
				keypad(stdscr,1);
				curs_set(0);
				
				clear();
				box(stdscr,ACS_VLINE,ACS_HLINE);
				bkgd(COLOR_PAIR(6));
				noecho();
				
				if(phead==NULL)
				{
						mvchgat(12,30,16,A_NORMAL,2,NULL);
						attron(A_BOLD|COLOR_PAIR(2));
						mvprintw(12,32,"没有此电影!😁 ");
						attroff(A_BOLD|COLOR_PAIR(2));
					
				}
				else
				{
					while(ptemp!=NULL)
					{
						if(memcmp(ptemp->actor,name,strlen(name))==0)
						{
								t->next=ptemp;
								t=ptemp;
								item=1;
						}
						ptemp=ptemp->next;
											
					}
					t->next=NULL;
					shead=shead->next;
					//Show(shead);
					if(item==0)
					{
						mvchgat(12,30,16,A_NORMAL,2,NULL);
						attron(A_BOLD|COLOR_PAIR(2));
						mvprintw(12,32,"没有此电影!😁 ");
						attroff(A_BOLD|COLOR_PAIR(2));
						
					}
					Show(shead);
				}
				break;
			}	
				
			else if(line==14)
					break;
			
		}
	}
	//getch();
}

