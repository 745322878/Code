void Menu_Teacher()
{
	int flag;
	int l=8;
	struct student *phead;

	while(1)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
	
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|                                               |\t||\n");
		printf("\t||\t|\t\t1.¼��ѧ���ɼ�\t\t\t|\t||\n");//8
		printf("\t||\t|\t\t2.��ѯѧ���ɼ�\t\t\t|\t||\n");
		printf("\t||\t|\t\t3.�޸�ѧ���ɼ�\t\t\t|\t||\n");
		printf("\t||\t|\t\t4.��ʾѧ���ɼ�\t\t\t|\t||\n");
		printf("\t||\t|\t\t5.�ܳɼ�����\t\t\t|\t||\n");
		printf("\t||\t|\t\t6.���Ƴɼ�����\t\t\t|\t||\n");
		printf("\t||\t|\t\t7.  �޸�����\t\t\t|\t||\n");
		printf("\t||\t|\t\t0.\t����\t\t\t|\t||\n");//15
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(28,l);
		printf("%c",16);
		flag=getch();
		if(flag==Down )
		{
			l++;
			while(l==16)
				l=8;
		}
		if(flag==Up)
		{
			l--;
			while(l==7)
				l=15;
		}
		if(flag==13)
		{
			if(l==8)
			{
				system("cls");
				phead=Enter();
			}
			if(l==9)
			{
				system("cls");
				fflush(stdin);
				Search();	
			}
			if(l==10)
			{
				system("cls");
				phead=Modify();
			}
			if(l==11)
			{
				system("cls");
				phead=Read_file();
				Print(phead);
			}
			if(l==12)
			{
				system("cls");
				phead=Read_file();
				Total_Rank(phead);
			}
			if(l==13)
			{
				system("cls");
				phead=Read_file();	
				Rank(phead);
			}
			if(l==14)
			{
				system("cls");
				Teacher_Modify_Password();
			}
			if(l==15)
			{
				system("cls");
				break;
			}
		}
	}
}
			