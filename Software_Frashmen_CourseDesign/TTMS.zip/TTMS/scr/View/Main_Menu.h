/*
 * Main_Menu.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef MAIN_MENU_H_
#define MAIN_MENU_H_

#include "../TTMS/scr/View/Studio.h"
#include "../TTMS/scr/View/Play_UI_MgtEntry.h"

void Main_Menu(void);

#endif