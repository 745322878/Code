void Menu_1(int y,int x)
{
    int i;
    clear();
    box(stdscr,ACS_VLINE,ACS_HLINE);
    //attron(A_BOLD);
    mvprintw(2,34,"今日影片");
    mvchgat(1,1,77,A_NORMAL,1,NULL);
    mvchgat(2,1,77,A_NORMAL,1,NULL);
    mvchgat(3,1,77,A_NORMAL,1,NULL);
    mvprintw(21,36,"上一页");
    mvchgat(20,32,14,A_NORMAL,2,NULL);
    mvchgat(21,32,14,A_NORMAL,2,NULL);
    mvchgat(22,32,14,A_NORMAL,2,NULL);
    mvprintw(21,60,"下一页");
    mvchgat(20,56,14,A_NORMAL,2,NULL);
    mvchgat(21,56,14,A_NORMAL,2,NULL);
    mvchgat(22,56,14,A_NORMAL,2,NULL);
    mvprintw(21,10,"退出程序");
    mvchgat(20,8,14,A_NORMAL,2,NULL);
    mvchgat(21,8,14,A_NORMAL,2,NULL);
    mvchgat(22,8,14,A_NORMAL,2,NULL);
    move(y,x);
}

void Menu_2(int y,int x,struct readFilm *head,int n)
{
    clear();
    box(stdscr,ACS_VLINE,ACS_HLINE);
    //attron(A_BOLD);
    //以下内容需要更改
    mvprintw(3,5,"%s",head->a[n]);
    mvprintw(2,20,"导演：%s",head->Director[n]);
    mvprintw(4,20,"评分：%.1f",head->Score[n]);
    mvprintw(2,37,"类型：%s",head->Type[n]);
    mvprintw(4,37,"主演：%s",head->Actor[n]);
    mvprintw(2,58,"片长：%d分钟",head->Times[n]);
    mvprintw(4,58,"上映时间：%d-%d-%d",head->Year[n],head->Month[n],head->Day[n]);
    mvchgat(1,1,77,A_NORMAL,1,NULL);
    mvchgat(2,1,77,A_NORMAL,1,NULL);
    mvchgat(3,1,77,A_NORMAL,1,NULL);
    mvchgat(4,1,77,A_NORMAL,1,NULL);
    mvchgat(5,1,77,A_NORMAL,1,NULL);
    mvprintw(6,38,"场次");
//    mvprintw(7,8,"2.00~4.30");
//    mvprintw(7,25,"1号厅");
//    mvprintw(7,36,"已售/总数：40/50");
//    mvprintw(7,64,"选择");
//    mvchgat(7,62,8,A_NORMAL,2,NULL);
    //以下内容无需更改
    mvprintw(21,36,"上一页");
    mvchgat(20,32,14,A_NORMAL,2,NULL);
    mvchgat(21,32,14,A_NORMAL,2,NULL);
    mvchgat(22,32,14,A_NORMAL,2,NULL);
    mvprintw(21,60,"下一页");
    mvchgat(20,56,14,A_NORMAL,2,NULL);
    mvchgat(21,56,14,A_NORMAL,2,NULL);
    mvchgat(22,56,14,A_NORMAL,2,NULL);
    mvprintw(21,14,"返回");
    mvchgat(20,10,12,A_NORMAL,2,NULL);
    mvchgat(21,10,12,A_NORMAL,2,NULL);
    mvchgat(22,10,12,A_NORMAL,2,NULL);
    move(y,x);
}

void Menu_3(struct readSe *shead,int n)
{
    clear();
    box(stdscr,ACS_VLINE,ACS_HLINE);
    attron(A_BOLD);
    mvprintw(2,34,"座位选择(%d号厅)",shead->room[n]);
    mvchgat(1,1,78,A_NORMAL,1,NULL);
    mvchgat(2,1,78,A_NORMAL,1,NULL);
    mvchgat(3,1,78,A_NORMAL,1,NULL);
    mvprintw(6,36,"大荧幕");
    mvchgat(5,28,22,A_NORMAL,1,NULL);
    mvchgat(6,28,22,A_NORMAL,1,NULL);
    mvchgat(7,28,22,A_NORMAL,1,NULL);
    mvprintw(6,77,"门");
    mvprintw(8,77,"口");
    mvchgat(6,76,3,A_NORMAL,1,NULL);
    mvchgat(7,76,3,A_NORMAL,1,NULL);
    mvchgat(8,76,3,A_NORMAL,1,NULL);
    mvprintw(5,4,"◥██◤");
    mvprintw(5,10,"未售");
    mvchgat(5,4,4,A_NORMAL,7,NULL);
    mvprintw(6,4,"◥██◤");
    mvprintw(6,10,"已选");
    mvchgat(6,4,4,A_NORMAL,5,NULL);
    mvprintw(7,4,"◥██◤");
    mvprintw(7,10,"未售");
    mvchgat(7,4,4,A_NORMAL,6,NULL);
    mvprintw(20,2,"按+选择");
    mvprintw(22,2,"按-取消");
    mvprintw(19,68,"返回");
    mvchgat(19,66,8,A_NORMAL,2,NULL);
    mvprintw(21,68,"确认");
    mvchgat(21,66,8,A_NORMAL,2,NULL);
    move(11,20);
}

int Menu_massage(struct readFilm *head,int n,int all,int line[],int cols[],int m,
                  struct readSe *shead,int i)
{
    int j,l = 0,p,flag = 0;
    clear();
    box(stdscr,ACS_VLINE,ACS_HLINE);
    //attron(A_BOLD);
    if(all != 0)
    {
        mvprintw(2,34,"电影票信息");
        mvchgat(1,10,58,A_NORMAL,1,NULL);
        mvchgat(2,10,58,A_NORMAL,1,NULL);
        mvchgat(3,10,58,A_NORMAL,1,NULL);
        mvprintw(5,14,"电影名称：%s\t",head->a[n]);
        mvprintw(7,16,"场次：%.2f~%.2f %d号厅",shead->start[i],shead->end[i],shead->room[i]);
        mvprintw(9,16,"座位：");
        for(j = 0,p = j; j < all; j++)
        {
            if((j % 5 != 0 || j == 0) && line[j] != 0 && cols[j] != 0)
            {
                mvprintw(9+l,22+(p*8),"%d行%d列",line[j],cols[j]);
                p++;
            }
            else if(j % 5 == 0 && j != 0 && line[j] != 0 && cols[j] != 0)
            {
                l++;
                p = 0;
                mvprintw(9+l,22+(p*8),"%d行%d列",line[j],cols[j]);
                p++;
            }
        }
        mvprintw(11+l,16,"价格：\t¥%.2f",head->b[n]);
        mvprintw(17,16,"总价：\t¥%.2f",all*(head->b[n]));
    }
    else if(all == 0)
    {
        flag = 1;
        mvprintw(9,34,"您还未购买");
        mvchgat(8,12,58,A_NORMAL,1,NULL);
        mvchgat(9,12,58,A_NORMAL,1,NULL);
        mvchgat(10,12,58,A_NORMAL,1,NULL);
    }
    mvprintw(21,59,"确认购买");
    mvchgat(20,56,14,A_NORMAL,2,NULL);
    mvchgat(21,56,14,A_NORMAL,2,NULL);
    mvchgat(22,56,14,A_NORMAL,2,NULL);
    mvprintw(21,17,"返回");
    mvchgat(20,12,14,A_NORMAL,2,NULL);
    mvchgat(21,12,14,A_NORMAL,2,NULL);
    mvchgat(22,12,14,A_NORMAL,2,NULL);
    return flag;
}

void Menu_succeed()
{
    clear();
    box(stdscr,ACS_VLINE,ACS_HLINE);
   // attron(A_BOLD);
    mvprintw(9,34,"😄 购买成功😄");
    mvchgat(8,12,58,A_NORMAL,1,NULL);
    mvchgat(9,12,58,A_NORMAL,1,NULL);
    mvchgat(10,12,58,A_NORMAL,1,NULL);
    mvprintw(21,59,"确认");
    mvchgat(20,56,14,A_NORMAL,2,NULL);
    mvchgat(21,56,14,A_NORMAL,2,NULL);
    mvchgat(22,56,14,A_NORMAL,2,NULL);
    mvprintw(21,17,"返回");
    mvchgat(20,12,14,A_NORMAL,2,NULL);
    mvchgat(21,12,14,A_NORMAL,2,NULL);
    mvchgat(22,12,14,A_NORMAL,2,NULL);
}

void Menu_end()
{
    clear();
    box(stdscr,ACS_VLINE,ACS_HLINE);
    //attron(A_BOLD);
    mvprintw(12,32,"😊 谢谢使用，再见!😊");
    mvchgat(11,30,24,A_NORMAL,1,NULL);
    mvchgat(12,30,24,A_NORMAL,1,NULL);
    mvchgat(13,30,24,A_NORMAL,1,NULL);
}
