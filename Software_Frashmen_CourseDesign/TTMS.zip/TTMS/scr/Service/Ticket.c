#include "Ticket.h"
#include "../TTMS/scr/Service/EntityKey.h"
#include "../TTMS/scr/Common/list.h"
//#include "../Service/Schedule.h"
#include "../TTMS/scr/Service/Play.h"
#include "../TTMS/scr/Persistence/Ticket_Persist.h"
#include "../TTMS/scr/Persistence/Play_Persist.h"
//#include "../TTMS/scr/Persistence/Schedule_Persist.h"
#include "../TTMS/scr/Service/Seat_Srv.h"

#include <stdio.h>
#include <stdlib.h>

int Ticket_Srv_AddBatch(int schedule_id, int studio_id){
    seat_list_t     head;
		
    seat_node_t     *pos;
    ticket_list_t   list;
    ticket_node_t   *newNode;
    int ID;
    int count;
    List_Init(head, seat_node_t);
    
    count= Seat_Srv_FetchValidByRoomID(head, studio_id);
    
    if(count!=0){
		List_Init(list, ticket_node_t);
		ID=EntKey_Srv_CompNewKey("ticket");
		pos = head->next;
		while(pos != head){
			newNode = (ticket_node_t *)malloc(sizeof(ticket_node_t));
			newNode->data.seat_id = pos->data.id;
			List_AddTail(list, newNode);
			pos=pos->next;
		}
        return Ticket_Perst_Insert(list);
    }
    else{
        return 0;
    }
}

int Ticket_Srv_DeleteBatch(int schedule_id) {
	
       return Ticket_Perst_Delete(schedule_id);
}

int Ticket_Srv_Modify(const ticket_t * data){
       return  Ticket_Perst_Update(data);
}

int Ticket_Srv_FetchByID(int ID, ticket_t *buf) {
	
       return Ticket_Perst_SelectByID(ID, buf); 
}

//根据座位ID在list中找对应的票
inline ticket_node_t * Ticket_Srv_FindBySeatID(ticket_list_t list, int seat_id){
	assert(NULL!=list);
	ticket_node_t *ptr=list->next;
	while(ptr != list){
        if(ptr->data.id == seat_id){
			return ptr;
        }
        else{
			ptr=ptr->next;
        }
	}

	return NULL;
}

//根据计划ID提取所有的演出票
int Ticket_Srv_FetchBySchID(ticket_list_t list, int schedule_id) {

    return Ticket_Perst_SelectBySchID(list,schedule_id);
}

/*
//根据演出计划ID，统计上座率及票房，返回票房数收入
int Ticket_Srv_StatRevBySchID(int schedule_id, int *soldCount, int *totalCount){
	
       return 1;
}
 */


