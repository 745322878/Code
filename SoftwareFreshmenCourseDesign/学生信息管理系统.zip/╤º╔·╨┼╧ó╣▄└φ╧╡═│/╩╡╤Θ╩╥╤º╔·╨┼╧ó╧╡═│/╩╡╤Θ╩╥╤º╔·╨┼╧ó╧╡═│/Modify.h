
//�޸�
struct student *Modify()
{
	struct student *ptemp,*phead;
	struct student *phead1,*ptemp1;
	int flag,flag1;
	int l=10,x=35,y=8,t=0,i=0;
	char name[20],id[10];
	char ch;
	float mod_score;
	FILE *fp;
	
	while(1)
	{
		fflush(stdin);
		phead=Read_file();
		ptemp=phead;
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t1.����\t\t\t|\t||\n");//8
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t2.ѧ��\t\t\t|\t||\n");//11
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|\t\t\t0.����\t\t\t|\t||\n");//14
		printf("\t||\t|\t\t\t\t\t\t|\t||\n");
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(32,5);
		printf("ѡ���޸�����");
		goto_xy(x,y);
		printf("%c",16);
		flag=getch();
		if(flag==Down)
		{
			y=y+3;
			if(y==17)
				y=8;
		}
		if(flag==Up)
		{
			y=y-3;
			if(y==5)
				y=14;
		}
		if(flag==13)
		{
			if(y==8)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|                                               |\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
				printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
				printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");//12
				printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("���������󣬻س��޸ĳɼ�");
				goto_xy(37,8);
				t=0;
				i=0;
				while((ch=getch())!='\r')
				{
					
					if(ch!='\b')
					{
						putchar(ch);
						name[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
						name[i]='\0';
					if(ch=='\b'&& i>0)
					{
						printf("\b \b");
						i--;
					} 
					if(i==6)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=5;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;

					}
					
				}
				name[i]='\0';
				getchar();
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->name,name)==0)			
					{
						break;
					}
					ptemp=ptemp->next ;
				}
				if(ptemp==NULL)
				{
					goto_xy(30,16);
					printf("No such person!\n");
					goto_xy(45,16);
					Sleep(800);
					break;
				}
				while(1)
				{
					
					phead1=Read_file();
					ptemp1=phead1;
					while(ptemp1!=NULL)
					{
						if(strcmp(ptemp1->name,name)==0)			
						{
							break;
						}
						ptemp1=ptemp1->next ;
					}
					system("cls");
					printf("\n\n");
					printf("\t ________________________________________________________________\n");//64
					printf("\t| ______________________________________________________________ |\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t _______________________________________________ \t||\n");
					printf("\t||\t|                                               |\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
					printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
					printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
					printf("\t||\t|_______________________________________________|\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||______________________________________________________________||\n");
					printf("\t|________________________________________________________________|\n");
					goto_xy(32,5);
					printf("���������󣬻س��޸ĳɼ�");
					goto_xy(37,8);
					printf("%s",name);
					goto_xy(37,9);
					printf("%s",ptemp1->id );
					goto_xy(37,10);
					printf("%2.2f",ptemp1->chinese );
					goto_xy(37,11);
					printf("%2.2f",ptemp1->math );
					goto_xy(37,12);
					printf("%2.2f",ptemp1->english );
					goto_xy(39,13);
					printf("%2.2f",ptemp1->aver );
					goto_xy(30,l);
					printf("%c",16);
					flag1=getch();
					if(flag1==Down)
					{
						l++;
						if(l==15)
							l=10;
					}
					if(flag1==Up)
					{
						l--;
						if(l==9)
							l=14;
					}
					if(flag1==13)
					{
						if(l==10)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->chinese =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==11)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->math =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==12)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->english=mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==14)
							break;
						fp=fopen("student.txt","w");
						for(phead1 ;phead1!=NULL;phead1=phead1->next)
						{
							fprintf(fp,"%s %s %f %f %f %f\n",phead1->name,phead1->id,phead1->chinese,
								phead1->math,phead1->english,phead1->aver);
						}
						fclose(fp);
						fflush(stdin);
					}
				}
			}
			if(y==11)
			{
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|                                               |\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
				printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
				printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");//12
				printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
				printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(32,5);
				printf("����ѧ�ź󣬻س��޸ĳɼ�");
				goto_xy(37,9);
				t=0;
				i=0;
				while((ch=getch())!=13)
				{
					if(ch!='\b')
					{
						putchar(ch);
						id[i]=ch;
						i++;
					}
					if(ch=='\b'&&i==0)
					{
						id[0]='\0';
					}
					if(ch=='\b'&&i>0)
					{
						printf("\b \b");
						i--;
					}
					if(i==8)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=7;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;
					}
				}
				id[i]='\0';
				getchar();
				while(ptemp!=NULL)
				{
					if(strcmp(ptemp->id,id)==0)			
					{
						break;
					}
					ptemp=ptemp->next ;
				}
				if(ptemp==NULL)
				{
					goto_xy(30,16);
					printf("No such person!\n");
					goto_xy(45,16);
		
					Sleep(1000);
					break;
				}
				while(1)
				{
					phead1=Read_file();
					ptemp1=phead1;
					while(ptemp1!=NULL)
					{
						if(strcmp(ptemp1->id,id)==0)			
						{
							break;
						}
						ptemp1=ptemp1->next ;
					}
					system("cls");
					printf("\n\n");
					printf("\t ________________________________________________________________\n");//64
					printf("\t| ______________________________________________________________ |\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t _______________________________________________ \t||\n");
					printf("\t||\t|                                               |\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//8
					printf("\t||\t|\t\tѧ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t����:\t\t\t\t|\t||\n");//10
					printf("\t||\t|\t\t��ѧ:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tӢ��:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\tƽ����:\t\t\t\t|\t||\n");
					printf("\t||\t|\t\t  ����!\t\t\t\t|\t||\n");//14
					printf("\t||\t|_______________________________________________|\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||\t\t\t\t\t\t\t\t||\n");
					printf("\t||______________________________________________________________||\n");
					printf("\t|________________________________________________________________|\n");
					goto_xy(32,5);
					printf("����ѧ�ź󣬻س��޸ĳɼ�");
					goto_xy(37,8);
					printf("%s",ptemp1->name );
					goto_xy(37,9);
					printf("%s",id );
					goto_xy(37,10);
					printf("%2.2f",ptemp1->chinese );
					goto_xy(37,11);
					printf("%2.2f",ptemp1->math );
					goto_xy(37,12);
					printf("%2.2f",ptemp1->english );
					goto_xy(39,13);
					printf("%2.2f",ptemp1->aver );
					goto_xy(30,l);
					printf("%c",16);
					flag1=getch();
					if(flag1==Down)
					{
						l++;
						if(l==15)
							l=10;
					}
					if(flag1==Up)
					{
						l--;
						if(l==9)
							l=14;
					}
					if(flag1==13)
					{
						if(l==10)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->chinese =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==11)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->math =mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==12)
						{
							goto_xy(46,l);
							scanf("%f",&mod_score);
							ptemp1->english=mod_score;
							ptemp1->aver=(ptemp1->chinese +ptemp1->math +ptemp1->english )/3;
						}
						if(l==14)
							break;
						fp=fopen("student.txt","w");
						for(phead1 ;phead1!=NULL;phead1=phead1->next)
						{
							fprintf(fp,"%s %s %f %f %f %f\n",phead1->name,phead1->id
								,phead1->chinese,phead1->math,phead1->english,phead1->aver);
						}
						fclose(fp);
						fflush(stdin);
					}
				}
			}
			if(y==14)
				break;
		}
	}
	return phead1;
}