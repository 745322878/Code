#include<curses.h>
#include<locale.h>
#include<string.h>
#include<stdlib.h>

int a[6];
int y=5,x=62;
int seat_array[6][10];

#include "Struct.h"
#include "Read_file.h"
#include "menu.h"
#include "Move.h"
#include "byTicket.h"
//#include "Save.h"
#include "Seat.h"
#include "session.h"


