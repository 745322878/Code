#include "Schedule_UI.h"
#include "../TTMS/scr/View/Play_UI_MgtEntry.h"
#include "../TTMS/scr/Common/list.h"
#include "../TTMS/scr/Service/Schedule.h"
#include "../TTMS/scr/Service/Play.h"
#include "../TTMS/scr/Service/Studio_Srv.h"
#include "../TTMS/scr/Service/EntityKey.h"
#include "../TTMS/scr/Service/Ticket.h"

#include <stdio.h>
#include <stdlib.h>

void Schedule_UI_ListAll(void) {
    
	//函数实现部分
    schedule_list_t     list;
    schedule_node_t     *p;
	int                 Snumber,i,pageSize = 10;
	Pagination_t        paging;
	char                choice;
    int                 id;
	
    List_Init(list,schedule_node_t);
    
    printf("请输入剧目id:");
    scanf("%d",&id);
    
    Snumber = Schedule_Srv_FetchByPlay(list,id);
    
    paging.totalRecords = Snumber;
    paging.pageSize = pageSize;
    Paging_Locate_FirstPage(list,paging);           //定位到第一页
    
    do {
        printf("================================ Schedule List ===================================\n");
        printf("剧目ID\t演出计划id\t\t演出厅ID\t日期\t时间\t座位数量\n");
        printf("----------------------------------------------------------------------------------\n");
        for (i = 0, p = (schedule_node_t *) (paging.curPos); //当前页面的起始位置
             p != list && i < paging.pageSize; i++) {
            printf("%d\t%d\t%d\t%d.%d.%d\t%d:%d:%d\t%d\n", p->data.id, p->data.play_id,
                   p->data.studio_id,
                   p->data.date.year,p->data.date.month,p->data.date.day,
                   p->data.time.hour,p->data.time.minute,p->data.time.second,
                   p->data.seat_count);
            p=p->next;
        }
        printf("--总记录:%2d --------------------------------------------------- 页 %2d/%2d --\n",
               paging.totalRecords, Pageing_CurPage(paging),
               Pageing_TotalPages(paging));
        printf("[P]上一页 | [N]下一页 | [R]返回\n");
        printf("=====================================================================================\n");
        printf("Your Choice:");
        while(getchar() != '\n');
        scanf("%c", &choice);
        switch (choice) {
            case 'p':
            case 'P':
                if (1 < Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, -1, schedule_node_t); //前移
                }
                break;
            case 'n':
            case 'N':
                if (Pageing_TotalPages(paging) > Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, 1, schedule_node_t);  //后移
                }
                break;
        }
    } while (choice != 'r' && choice != 'R');
    
    List_Destroy(list,schedule_node_t);
}


int Schedule_UI_Add(int play_id) {
	// 请补充完整
	int         newCount = 0;
    int         key;
    char        choice;
    schedule_t  pnew;
    studio_t    data;
    printf("=================================== 场次增加 ==================================\n");
    do{
        //pnew = (studio_t *)malloc(sizeof(studio_t));
        key = EntKey_Srv_CompNewKey("schedule"); //主键服务
        pnew.id = key;
        pnew.play_id = play_id;
        printf("请输入演出厅id:\n");
        //fflush(stdin);
        scanf("%d",&pnew.studio_id);
        printf("请输入日期 (like 2015 06 29):\n");
        scanf("%d %d %d",&pnew.date.year, &pnew.date.month, &pnew.date.day);
        printf("请输入时间 (like 12(hour) 30(minute) 00(second)):\n");
        scanf("%d %d %d",&pnew.time.hour, &pnew.time.minute, &pnew.time.second);
        if (Srv_FetchByID(pnew.studio_id, &data)) {
            pnew.seat_count = data.seatsCount;
            if (Schedule_Srv_Add(&pnew)) {
                    printf("增加成功!!\n");
                    newCount++;
                    printf("继续? (y/n):");
                    getchar();
                    scanf("%c",&choice);
            }
            else
            {
                printf("场次增加失败!\n");
                sleep(1);
                return newCount;
            }
        }
        else{
            printf("没有找到该厅!\n");
            sleep(1);
            return newCount;
        }
    }while (choice == 'y' || choice == 'Y');
    return newCount;
}

int Schedule_UI_Modify(int id){
	// 请补充完整
	int         rtn = 0;
    schedule_t  temp;
    //schedule_t  pnew;
    studio_t    data;
    if (Schedule_Srv_FetchByID( id, &temp)) {
        printf("================================= 场次更新 ================================\n");
        printf("------------------------------------ 旧计划 ----------------------------------\n");
        printf("ID: \t%d\n",temp.id);
        printf("演出计划id: \t%d\n",temp.play_id);
        printf("演出厅id: \t%d\n",temp.studio_id);
        printf("日期: \t%d %d %d\n", temp.date.year, temp.date.month, temp.date.day);
        printf("时间: \t%d %d %d\n",temp.time.hour, temp.time.minute, temp.time.second);
        printf("座位数: \t%d\n",temp.seat_count);
        printf("\n------------------------------------ New Data ----------------------------------\n");
        printf("请输入演出厅id:\n");
        scanf("%d",&temp.studio_id);
        if(Srv_FetchByID(temp.studio_id, &data))
        {
            printf("请输入日期(like 2015 06 29):\n");
            scanf("%d %d %d",&temp.date.year, &temp.date.month, &temp.date.day);
            printf("请输入时间 (like 12(hour) 30(minute) 00(second)):\n");
            scanf("%d %d %d",&temp.time.hour, &temp.time.minute, &temp.time.second);
            temp.seat_count = data.seatsCount;
            if (Schedule_Srv_Modify(&temp))
            {
                rtn = 1;
                printf("更新成功!\n");
            }
            else{
                printf("更新失败!\n");
            }
        }
        else
        {
            printf("没有找到这个厅!\n");
            return 0;
        }
    }
    else
    {
        printf("没有这个场次!\n");
        sleep(1);
        return 0;
    }
    sleep(1);
    return rtn;
}

int Schedule_UI_Delete(int id){

	// 请补充完整
	int rtn = 0;
    printf("========================= 场次删除 =========================\n");
    if (Schedule_Srv_DeleteByID(id)) {
        rtn = 1;
        printf("删除成功!\n");
    }
    else
    {
        printf("删除失败!\n");
    }
    sleep(1);
    return rtn;
}
int Schedule_UI_Query(int id){

	// 请补充完整
	int         rtn = 0;
    schedule_t  buf;
    if (Schedule_Srv_FetchByID( id, &buf)) {
        rtn = 1;
        printf("=========================== 场次信息 ===========================\n");
        printf("ID: \t%d",buf.id);
        printf("演出计划ID: \t%d",buf.play_id);
        printf("演出厅ID: \t%d",buf.studio_id);
        printf("日期: \t%d %d %d", buf.date.year, buf.date.month, buf.date.day);
        printf("时间: \t%d %d %d",buf.time.hour, buf.time.minute, buf.time.second);
        printf("座位数: \t%d",buf.seat_count);
        printf("-----------------------------------------------------------------------\n");
        printf("请按任意键退出 !!");
        while(getchar() != '\n');
    }
    else
    {
        printf("没有找到该场次!!");
        sleep(1);
    }
    return rtn;
}

/*以列表模式显示给定剧目的演出计划信息
void Schedule_UI_ListByPlay(const play_t *play, schedule_list_t list, Pagination_t paging){

	// 请补充完整
}*/

void Schedule_UI_MgtEntry(int play_id){
       // 请补充完整
    schedule_list_t     list;
    schedule_node_t     *p;
    int                 Snumber,i,pageSize = 10;
    Pagination_t        paging;
    char                choice;
    int                 id;
    //schedule_t          buf;
    
    List_Init(list,schedule_node_t);
    
    Snumber = Schedule_Srv_FetchByPlay(list, play_id);
    
    paging.totalRecords = Snumber;
    paging.pageSize = pageSize;
    Paging_Locate_FirstPage(list,paging);           //定位到第一页
    
    do {
        system("clear");
        printf("================================ 场次 ===================================\n");
        printf("ID\t演出计划ID\t演出厅ID\t日期\t时间\t座位数\n");
        printf("----------------------------------------------------------------------------------\n");
        for (i = 0, p = (schedule_node_t *) (paging.curPos); //当前页面的起始位置
             p != list && i < paging.pageSize; i++) {
            printf("%d%10d%20d%10d.%d.%d%10d:%d:%d%10d\n", p->data.id, p->data.play_id,
                   p->data.studio_id,
                   p->data.date.year,p->data.date.month,p->data.date.day,
                   p->data.time.hour,p->data.time.minute,p->data.time.second,
                   p->data.seat_count);
            p=p->next;
        }
        printf("--总记录:%2d --------------------------------------------------- 页%2d/%2d --\n",
               paging.totalRecords, Pageing_CurPage(paging),
               Pageing_TotalPages(paging));
        printf("[P]前一页 | [N]下一页 |  [A］增加  |  [D]删除  |  [U]更新  ｜  [R]返回\n");
        printf("=====================================================================================\n");
        printf("Your Choice:");
        while(getchar() != '\n');
        scanf("%c", &choice);
        switch (choice) {
            case 'a':
            case 'A':
                if (Schedule_UI_Add(play_id)) {
                    paging.totalRecords = Schedule_Srv_FetchByPlay(list, play_id);
                    Paging_Locate_LastPage(list, paging, schedule_node_t);    //定位到最后一页
                }
                break;
            case 'd':
            case 'D':
                printf("请输入场次id:");
                scanf("%d",&id);
                if (Schedule_UI_Delete(id)) {
                    paging.totalRecords = Schedule_Srv_FetchByPlay(list, play_id);
                    List_Paging(list, paging, schedule_node_t);
                }
                break;
            case 'u':
            case 'U':
                printf("请输入场次id:");
                scanf("%d",&id);
                if (Schedule_UI_Modify(id)) {
                    paging.totalRecords = Schedule_Srv_FetchByPlay(list, play_id);
                    List_Paging(list, paging, schedule_node_t);
                }
                break;
            case 'p':
            case 'P':
                if (1 < Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, -1, schedule_node_t); //前移
                }
                break;
            case 'n':
            case 'N':
                if (Pageing_TotalPages(paging) > Pageing_CurPage(paging)) {
                    Paging_Locate_OffsetPage(list, paging, 1, schedule_node_t);  //后移
                }
                break;
        }
    } while (choice != 'r' && choice != 'R');
    
    List_Destroy(list,schedule_node_t);
}
