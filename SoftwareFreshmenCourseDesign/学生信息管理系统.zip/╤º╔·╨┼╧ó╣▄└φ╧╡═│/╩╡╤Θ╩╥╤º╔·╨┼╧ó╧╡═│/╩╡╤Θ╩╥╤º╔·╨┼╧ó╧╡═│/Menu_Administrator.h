
void Administrator_Modify_Information();
void Menu_Administrator()
{
	int    flag;
	int l=9;
	struct student *phead;
	while(1)
	{
		system("cls");
		printf("\n\n");
		printf("\t ________________________________________________________________\n");//64
		printf("\t| ______________________________________________________________ |\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t _______________________________________________ \t||\n");
		printf("\t||\t|                                               |\t||\n");
		printf("\t||\t|\t\t1.ע��ѧ���˺�\t\t\t|\t||\n");//9
		printf("\t||\t|\t\t2.ע����ʦ�˺�\t\t\t|\t||\n");
		printf("\t||\t|\t\t3.�޸���Ϣ\t\t\t|\t||\n");
		printf("\t||\t|\t\t4.��ʾȫ��ѧ����Ϣ\t\t|\t||\n");
		printf("\t||\t|\t\t0.    ����\t\t\t|\t||\n");//13
		printf("\t||\t|_______________________________________________|\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||\t\t\t\t\t\t\t\t||\n");
		printf("\t||______________________________________________________________||\n");
		printf("\t|________________________________________________________________|\n");
		goto_xy(30,l);
		printf("%c",16);
		fflush(stdin);
		flag=getch();
		if(flag==Down)
		{
			l++;
			while(l==14)
				l=9;
		}
		if(flag==Up)
		{
			l--;
			while(l==8)
				l=13;
		}
		if(flag==13)
		{
			if(l==9)
			{
					system("cls");
					phead=Zhuce();
			}
			if(l==10)
			{
					system("cls");
					phead=Zhuce_Teacher();
			}
			if(l==11)
			{
					system("cls");
					Administrator_Modify_Information();
			}
			if(l==12)
			{
					system("cls");
					phead=Read_file();	
					Print(phead);
			}
			if(l==13)
			{
				break;
			}
		}
		
		
	}	
}
