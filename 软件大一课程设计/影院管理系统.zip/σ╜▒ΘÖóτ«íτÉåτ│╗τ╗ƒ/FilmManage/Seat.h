int save_array(struct readFilm *head,int u)
{
    int i,j;
    FILE *fp;
    char filmname[1000] = {0};
    strcat(filmname,"/Users/wyz/Desktop/影院管理系统/FilmBackend/");
    strcat(filmname,head->a[u]);
    fp = fopen(filmname,"w");
    if(fp == NULL)
    {
        return -1;
    }
    for(i = 0; i < 6; i++)
    {
        for(j = 0; j < 10; j++)
        {
            if(seat_array[i][j] == 1)
            {
                seat_array[i][j] = 0;
                fprintf(fp,"%d\n",seat_array[i][j]);
            }
            fprintf(fp,"%d\n",seat_array[i][j]);
        }
    }
    fclose(fp);
    return 1;
}

int read_array(struct readFilm *head,int u)
{
    int i, j;
    int flag = 0;
    FILE *fp;
    char filmname[1000] = {0};
    strcat(filmname,"/Users/wyz/Desktop/影院管理系统/FilmBackend/");
    strcat(filmname,head->a[u]);
    fp = fopen(filmname,"r");
    if(fp == NULL)
    {
        return -1;
    }
    for(i = 0; i < 6; i++)
    {
        for(j = 0; j < 10; j++)
        {
            fscanf(fp,"%d\n",&seat_array[i][j]);
            if(feof(fp))
            {
                flag = 1;
                break;
            }
        }
        if(flag == 1)
        {
            break;
        }
    }
    fclose(fp);
    return 1;
}

void menu_seat(struct readSe *shead,int n)
{
    int i,j;
    clear();
    //read_array();
    Menu_3(shead,n);
    for(i = 0; i < 6; i++)
    {
        mvprintw(11+(i*2),16,"%d排",i+1);
        for(j = 0; j < 10; j++)
        {
            // mvprintw(11+(i*2),20+(j*4),"%d",seat_array[i][j]);
            if(seat_array[i][j] == 0)
            {
                mvprintw(11+(i*2),20+(j*4),"◥██◤");
                mvchgat(11+(i*2),20+(j*4),4,A_NORMAL,7,NULL);
            }
            else if(seat_array[i][j] == 1)
            {
                mvprintw(11+(i*2),20+(j*4),"◥██◤");
                mvchgat(11+(i*2),20+(j*4),4,A_NORMAL,5,NULL);
            }
            else if(seat_array[i][j] == 2)
            {
                mvprintw(11+(i*2),20+(j*4),"◥██◤");
                mvchgat(11+(i*2),20+(j*4),4,A_NORMAL,6,NULL);
            }
        }
    }
}

void set_seat(struct readSe *shead,int n,struct readFilm *head,int u)
{
    clear();
    struct film *phead;
    int line,cols, all = 0,k,l,i,j;
    int flag;
    int set1[50],set2[50],m = 0;
    a[2] = 11;
    a[3] = 20;
    if(read_array(head,u) != -1)
    {
    loop:
        menu_seat(shead,n);
        while(1)
        {
            Move_2(a[2],a[3]);
            line = (a[2]-11)/2;
            cols = (a[3]-20)/4;
            a[4] = 21;
            a[5] = 60;
            if(a[2] == 21 && a[3] == 66)
            {
                m = 0;
                all = 0;
                for(k = 0; k < 6; k++)
                {
                    for(l = 0; l < 10; l++)
                    {
                        if(seat_array[k][l] == 1)
                        {
                            set1[m] = k+1;
                            set2[m] = l+1;
                            all++;
                            m++;
                        }
                    }
                }
                flag = Menu_massage(head,u,all,set1,set2,m,shead,n);
                move_3(21,60);
                if(a[5] == 60 && flag != 1)
                {
                    Menu_succeed();
                    for(m = 0;m < all; m++)
                    {
                        line = set1[m] - 1;
                        cols = set2[m] - 1;
                        seat_array[line][cols] = 2;
                    }
                    save_array(head,u);
                    move_3(21,60);
                    for(m = 0;m < all; m++)
                    {
                        line = set1[m] - 1;
                        cols = set2[m] - 1;
                        seat_array[line][cols] = 2;
                    }
                    save_array(head,u);
                    phead = Read_file();
                    byTicket(phead);
                }
                else if(a[5] == 16 || flag == 1)
                {
                    ;
                }
                goto loop;
            }
            else if(a[3] >= 20 && a[3] <= 56 && choise == 1 && cancle == 0 && seat_array[line][cols] != 2)
            {
                if(seat_array[line][cols] != 1)
                {
                    seat_array[line][cols] = 1;
                    clear();
                    menu_seat(shead,n);
                }
            }
            else if(a[3] >= 20 && a[3] <= 56 && cancle == 1 && choise == 0 && seat_array[line][cols] != 2)
            {
                if(seat_array[line][cols] == 1)
                {
                    seat_array[line][cols] = 0;
                    clear();
                    menu_seat(shead,n);
                }
            }
            else if(a[2] == 19 && a[3] == 66 && enter == 1)
            {
                break;
            }
        }
    }
    else
    {
        clear();
        mvprintw(15,40,"读取座位信息失败！");
        getch();
    }
}
