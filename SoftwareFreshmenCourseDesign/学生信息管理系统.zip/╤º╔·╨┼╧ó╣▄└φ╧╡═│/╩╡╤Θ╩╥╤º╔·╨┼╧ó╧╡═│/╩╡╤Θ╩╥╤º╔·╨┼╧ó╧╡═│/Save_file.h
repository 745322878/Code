void Save_file(struct student *phead)
{		
		struct student *ptemp=phead;
		FILE *fp;
		fp=fopen("student.txt","a+");
		for(ptemp ;ptemp!=NULL;ptemp=ptemp->next)
		{
			fprintf(fp,"%s %s %f %f %f %f\n",ptemp->name,ptemp->id,ptemp->chinese,ptemp->math,ptemp->english,ptemp->aver);
		}
		
		fclose(fp);
}
