void Save_TotalRank(struct student *phead)
{		
		struct student *ptemp=phead;
		FILE *fp;
	
		fp=fopen("Total_rank.txt","w");
		for(ptemp ;ptemp!=NULL;ptemp=ptemp->next)
		{
	
			fprintf(fp,"%s %s %s %f %f %f %f %d\n",
				ptemp->name,ptemp->id,ptemp->sex,ptemp->chinese,ptemp->math,ptemp->english,ptemp->aver,ptemp->data);

		}
		
		fclose(fp);
}
