void Land_Administrator( )
{
	struct student *phead,*ptemp;
	char  password[10];
	int times=0;
	int flag=0;
	int t;
	int l=8,i=0;
	char ch;
	phead=Read_Administrator_Password();
	ptemp=phead;
	system("cls");
	printf("\n\n");
	printf("\t ________________________________________________________________\n");//64
	printf("\t| ______________________________________________________________ |\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t _______________________________________________ \t||\n");
	printf("\t||\t|\t                        \t\t|\t||\n");//8
	printf("\t||\t|\t________________________\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t| Password:             |\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t|\t   ��¼\t\t|\t\t|\t||\n");
	printf("\t||\t|\t|_______________________|\t\t|\t||\n");
	printf("\t||\t|\t\t\t\t\t\t|\t||\n");
	printf("\t||\t|_______________________________________________|\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||\t\t\t\t\t\t\t\t||\n");
	printf("\t||______________________________________________________________||\n");
	printf("\t|________________________________________________________________|\n");
	goto_xy(25,7);
	printf("������6λ����");
	goto_xy(35,10);
	while((ch=getch())!='\r')
	{
		
		if(ch!='\b')
		{
			password[i]=ch;
			putchar('*');
			i++;
		}
		if(ch=='\b'&&i==0)
			password[0]='\0';
		if(ch=='\b'&& i>0)
		{
			printf("\b \b");
			i--;
		} 
		if(i==6)
		{
			while((ch=getch())!='\r')
			{
				if(ch=='\b')
				{
					printf("\b \b");
					i=5;
					t=1;
				
					break;
				}
			}
			if(t==1)
				continue;
			break;

		}
		
	}
	password[i]='\0';
	goto_xy(33,12);
	printf("%c",16);
	getch();
	if(phead==NULL)
	{
		while(times<2)
		{	
				if(strcmp(password,"666666")==0)
				{
					flag=1;
					times=0;
					break;
				}
				if(flag==1)
					break;
				
				system("cls");
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
				printf("\t||\t|\t                        \t\t|\t||\n");//8
				printf("\t||\t|\t _______________________\t\t|\t||\n");
				printf("\t||\t|\t|_______________________|\t\t|\t||\n");
				printf("\t||\t|\t| Password:             |\t\t|\t||\n");
				printf("\t||\t|\t|_______________________|\t\t|\t||\n");
				printf("\t||\t|\t|\t   ��¼\t\t|\t\t|\t||\n");
				printf("\t||\t|\t|_______________________|\t\t|\t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(24,14);
				printf("������%d�ε�¼����!\n",2-times);
				i=0;
				t=0;
				goto_xy(25,7);
				printf("������6λ����");
				goto_xy(35,10);
				while((ch=getch())!='\r')
				{
					
					if(ch!='\b')
					{
						password[i]=ch;
						putchar('*');
						i++;
					}
					if(ch=='\b'&&i==0)
						password[0]='\0';
					if(ch=='\b'&& i>0)
					{
						printf("\b \b");
						i--;
					} 
					if(i==6)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=5;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;

					}
					
				}
				password[i]='\0';
				goto_xy(33,12);
				printf("%c",16);
				getch();
				times++;
				if(strcmp(password,"666666")==0)
				{
					flag=1;
					times=0;
					break;
				}
				if(flag==1)
					break;
				
				
		}
	}
	
	else
	{
		while(times<2)
		{		
				for(ptemp;ptemp!=NULL;ptemp=ptemp->next )
				{
					if(  strcmp(ptemp->password ,password)==0)
					{
						flag=1;
						times=0;
						break;
					}
				}
				ptemp=Read_Administrator_Password();
				if(flag==1)
					break;
				system("cls");
				
				printf("\n\n");
				printf("\t ________________________________________________________________\n");//64
				printf("\t| ______________________________________________________________ |\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t _______________________________________________ \t||\n");
			
				printf("\t||\t|\t                        \t\t|\t||\n");//8
				printf("\t||\t|\t _______________________\t\t|\t||\n");
				printf("\t||\t|\t|_______________________|\t\t|\t||\n");
				printf("\t||\t|\t| Password:             |\t\t|\t||\n");
				printf("\t||\t|\t|_______________________|\t\t|\t||\n");
				printf("\t||\t|\t|\t   ��¼\t\t|\t\t|\t||\n");
				printf("\t||\t|\t|_______________________|\t\t|\t||\n");
				printf("\t||\t|\t\t\t\t\t\t|\t||\n");
				printf("\t||\t|_______________________________________________|\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||\t\t\t\t\t\t\t\t||\n");
				printf("\t||______________________________________________________________||\n");
				printf("\t|________________________________________________________________|\n");
				goto_xy(24,14);
				printf("������%d�ε�¼����!\n",2-times);
				i=0;
				t=0;
				goto_xy(25,7);
				printf("������6λ����");
				goto_xy(35,10);
				while((ch=getch())!='\r')
				{
					
					if(ch!='\b')
					{
						password[i]=ch;
						putchar('*');
						i++;
					}
					if(ch=='\b'&&i==0)
						password[0]='\0';
					if(ch=='\b'&& i>0)
					{
						printf("\b \b");
						i--;
					} 
					if(i==6)
					{
						while((ch=getch())!='\r')
						{
							if(ch=='\b')
							{
								printf("\b \b");
								i=5;
								t=1;
								break;
							}
						}
						if(t==1)
							continue;
						break;

					}
					
				}
				password[i]='\0';
				goto_xy(33,12);
				printf("%c",16);
				getch();
				times++;
				for(ptemp;ptemp!=NULL;ptemp=ptemp->next )
				{
					if(  strcmp(ptemp->password ,password)==0)
					{
						flag=1;
						times=0;
						break;
					}
				}
				ptemp=Read_Administrator_Password();
				if(flag==1)
					break;
				
				
		}
	}
	if(times==2)
	{
		goto_xy(30,10);
		printf("������¼����,ϵͳ�˳���\n");
		goto_xy(30,11);
		Exit();
		exit(1);
	}
}
