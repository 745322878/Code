#include "All.h"

int main(void)
{
    struct film *phead,*p;
    setlocale(LC_ALL,"");
    initscr();
    start_color();
    refresh();
    curs_set(0);
    noecho();
    init_pair(1,COLOR_RED,COLOR_WHITE);
    init_pair(2,COLOR_BLACK,COLOR_WHITE);
    init_pair(3,COLOR_BLUE,COLOR_CYAN);
    init_pair(4,COLOR_BLACK,COLOR_GREEN);
    init_pair(5,COLOR_MAGENTA,COLOR_GREEN);
    init_pair(6,COLOR_BLUE,COLOR_GREEN);
    init_pair(7,COLOR_WHITE,COLOR_GREEN);
    init_pair(8,COLOR_WHITE,COLOR_CYAN);
    bkgd(COLOR_PAIR(4));
    phead = Read_file();
    byTicket(phead);
    getch();
    endwin();
    
    return 0;
}


