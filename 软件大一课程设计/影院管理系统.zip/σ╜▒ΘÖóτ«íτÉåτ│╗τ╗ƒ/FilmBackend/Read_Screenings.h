struct film *Read_Screenings()
{
	struct film *phead,*ptemp,*r,*p,*shead,*q;
	int d = 0;
	FILE *fp;
	fp=fopen("/Users/wyz/Desktop/影院管理系统/文件/screenings.txt","r");
	if(fp==NULL)
		return NULL;
	phead=(struct  film *)malloc(sizeof(struct film));
	phead->next=NULL;
	phead->link=NULL;
	r=phead;
	while(!feof(fp))
	{	ptemp=(struct film *)malloc(sizeof(struct film));
		fscanf(fp,"%s %s %s %s %f %d %f %d-%d-%d\n",ptemp->name,
			ptemp->director,ptemp->actor,ptemp->type,&ptemp->score,
			&ptemp->time,&ptemp->price,&ptemp->year,&ptemp->month,
			&ptemp->day);
		
		//ptemp->link= (struct film *)malloc(sizeof(struct film));
		shead= (struct film *)malloc(sizeof(struct film));
		shead->link=NULL;
		q=shead;
		while(1)
		{
			p = (struct film *)malloc(sizeof(struct film));
			fscanf(fp,"%f %f %d\n",&p->start_time,&p->end_time,
							&p->movieroom);
			if(p->start_time == 0)
			{
				break;
			}
			d++;
			q->link= p;
			q = p;
		}
		q->link = NULL;
		shead=shead->link;
		ptemp->link=shead;
		r->next=ptemp;
		r=ptemp;
	}
	r->next=NULL;
	printw("%d",d);
	fclose(fp);
	phead=phead->next;
	return phead;
}

