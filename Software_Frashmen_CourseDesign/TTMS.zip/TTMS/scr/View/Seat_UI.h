/*
 * Seat_UI.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef _SEAT_UI_H_
#define _SEAT_UI_H_

#include "../TTMS/scr/Common/List.h"
#include "../TTMS/scr/Service/Seat_Srv.h"

//座位管理界面
void Seat_UI_MgtEntry(int roomID);

//根据座位状态获取界面显示符号
char Seat_UI_Status2Char(seat_status_t status);

//根据界面显示符号获取座位状态
seat_status_t Seat_UI_Char2Status(char statusChar);

//添加演出厅新座位界面
int Seat_UI_Add(seat_list_t list, int roomID, int rowsCount,int colsCount);

//根据id修改座位状态界面
int Seat_UI_Modify(seat_list_t list, int rowsCount, int colsCount);

//根据ID删除座位界面
int Seat_UI_Delete(seat_list_t list, int rowsCount, int colsCount);

#endif