void Front() //前端
{
	int flag,line=9,row=13;
	while(1)
	{
		clear();
		box(stdscr,ACS_VLINE,ACS_HLINE); 
		bkgd(COLOR_PAIR(6));
		
		attron(A_BOLD);
		mvprintw(3,30,"座位与场次设置");
		attroff(A_BOLD);
		mvchgat(2,23,30,A_NORMAL,2,NULL);
		mvchgat(3,23,30,A_NORMAL,2,NULL);
		mvchgat(4,23,30,A_NORMAL,2,NULL);
			
		attron(A_BOLD);			//输出修饰
		mvprintw(9,17,"录入场次");
		attroff(A_BOLD);		//关闭输出修饰
		mvchgat(8,13,15,A_NORMAL,7,NULL);
		mvchgat(9,13,15,A_NORMAL,7,NULL);
		mvchgat(10,13,15,A_NORMAL,7,NULL);

		attron(A_BOLD);			
		mvprintw(14,17,"修改场次");
		attroff(A_BOLD);		
		mvchgat(13,13,15,A_NORMAL,7,NULL);
		mvchgat(14,13,15,A_NORMAL,7,NULL);
		mvchgat(15,13,15,A_NORMAL,7,NULL);

		attron(A_BOLD);			//输出修饰
		mvprintw(9,52,"座位重置");
		attroff(A_BOLD);		//关闭输出修饰
		mvchgat(8,48,15,A_NORMAL,7,NULL);
		mvchgat(9,48,15,A_NORMAL,7,NULL);
		mvchgat(10,48,15,A_NORMAL,7,NULL);

		attron(A_BOLD);         //输出修饰
		mvprintw(14,53,"格式化");
		attroff(A_BOLD);        //关闭输出修饰
	    mvchgat(13,48,15,A_NORMAL,7,NULL);
        mvchgat(14,48,15,A_NORMAL,7,NULL);
        mvchgat(15,48,15,A_NORMAL,7,NULL);
	
		attron(A_BOLD);         //输出修饰
		mvprintw(19,19,"返回");
		attroff(A_BOLD);        //关闭输出修饰
		mvchgat(18,13,15,A_NORMAL,7,NULL);
		mvchgat(19,13,15,A_NORMAL,7,NULL);
		mvchgat(20,13,15,A_NORMAL,7,NULL);
		
		attron(A_BOLD);         //输出修饰
	    mvprintw(19,54,"返回");
        attroff(A_BOLD);        //关闭输出修饰
        mvchgat(18,48,15,A_NORMAL,7,NULL);
        mvchgat(19,48,15,A_NORMAL,7,NULL);
        mvchgat(20,48,15,A_NORMAL,7,NULL);

		mvchgat(line-1,row,15,A_BLINK,1,NULL);
		mvchgat(line,row,15,A_BLINK,1,NULL);
		mvchgat(line+1,row,15,A_BLINK,1,NULL);
		flag=getch();
		if(flag==KEY_DOWN)
		{
			line+=5;
			if(line==24)
					line=9;

		}
		else if(flag==KEY_UP)
		{
			line-=5;
			if(line==4)
					line=19;
		}
		else if(flag==KEY_RIGHT)
		{
			row+=35;
			if(row==83)
					row=13;
		}
		else if(flag==KEY_LEFT)
		{
			row-=35;
			if(row==-22)
					row=48;
		}
		else if(flag=='\r'||flag=='\n')
		{
			if(line==9&&row==13)
					Screenings();
			else if(line==9&&row==48)
					Seat_reset();
			else if(line==14&&row==13)
					ScreeningsModify();
			else if(line==14&&row==48)
					Format();
			else 
				break;
		}
	}
}
