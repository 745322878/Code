/*
 * Main_Menu.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Main_Menu.h"

void Main_Menu(void)
{
    char choice;
    do{
        system("clear");
        printf("\n==================================================================\n");
        printf("**************** 影院管理系统 ****************\n");
        printf("[S]演出厅管理.\n");
        printf("[P]剧目管理.\n");
        printf("[T]售票.\n");
        printf("[R]退票.\n");
        printf("[E]xist.\n");
        printf("\n==================================================================\n");
        printf("Please input your choice:");
        fflush(stdin);
        choice = getchar();
        switch (choice) {
            case 'S':
            case 's':
                MgtEntry();
                break;
            case 'P':
            case 'p':
                Play_UI_MgtEnt();
                break;
            case 'Q':
            case 'q':
                //Queries_Menu();
                break;
            case 'T':
            case 't':
                //Sale_UI_MgtEntry();
                break;
            case 'R':
            case 'r':
                // Sale_UI_ReturnTicket();
                break;
                //case 'N':
                //case 'n':
                //	SalesAanalysis_UI_MgtEntry();
                //	break;
            case 'A':
            case 'a':
                // Account_UI_MgtEntry();
                break;
        }
    } while ('E' != choice && 'e' != choice);
}
