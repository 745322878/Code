/*
 * Play_UI_MgtEntry.h
 *
 * Created on: 2015年6月29日
 *  Author on: Tang-tang
 */

#ifndef _PLAY_UI_MGTENTRY_H_
#define _PLAY_UI_MGTENTRY_H_

#include "../TTMS/scr/Common/list.h"
#include "../TTMS/scr/Service/Play.h"

//添加剧目界面
int Play_UI_Add(void);

//修改剧目界面
int Play_UI_Modify(int id);

//删除剧目界面
int Play_UI_Delete(int id);

//查询剧目界面
int Play_UI_Query(int id);

//主界面函数
void Play_UI_MgtEnt(void);

/*
//以列表形式显示剧目信息
void Play_UI_ShowList(play_list_t list, Pagination_t paging);
 */

#endif