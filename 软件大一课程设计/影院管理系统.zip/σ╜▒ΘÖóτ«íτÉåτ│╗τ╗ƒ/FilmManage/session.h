struct readSe *pack(struct session *yhead)
{
    struct readSe *pnew, *ptemp, *shead;
    int i;
    shead = (struct readSe *)malloc(sizeof(struct readSe));
    shead->left = NULL;
    shead->right = NULL;
    ptemp = shead;
    while(1)
    {
        pnew = (struct readSe *)malloc(sizeof(struct readSe));
        for(i = 0;i < 6 && yhead != NULL; i++)
        {
            pnew->start[i] = yhead->start;
            pnew->end[i] = yhead->end;
            pnew->room[i] = yhead->movieRoom;
            yhead = yhead->next;
        }
        ptemp->right = pnew;
        pnew->left = ptemp;
        pnew->right = NULL;
        ptemp = pnew;
        if(yhead == NULL)
        {
            pnew->end[i] = 0.0;
            break;
        }
    }
    shead = shead->right;
    shead->left = NULL;
    return shead;
}

void Session(struct session *yhead,struct readFilm *head,int n)
{
    struct readSe *shead;
    int i, get, k, l,Set;
    a[0] = 7;
    a[1] = 62;
    shead = pack(yhead);
loop:
    Menu_2(7,x,head,n);
    for(i = 0; i < 6; i++)
    {
        if(shead->end[i] == 0)
        {
            get = i-1;
            break;
        }
        mvprintw(7+(i*2),8,"%.2f~%.2f",shead->start[i],shead->end[i]);
        mvprintw(7+(i*2),25,"%d号厅",shead->room[i]);
        mvprintw(7+(i*2),64,"选择");
        mvchgat(7+(i*2),62,8,A_NORMAL,2,NULL);
        get = i;
    }
    while(1)
    {
        move_1(a[0],a[1],7+(get*2),7);
        k = a[0];
        l = a[1];
        if(a[1] == 62)
        {
            Set = (k-7)/2;
            set_seat(shead,Set,head,n);
            goto loop;
        }
        else if(a[0] == 21 && a[1] == 60 && shead->right != NULL)
        {
            clear();
            Menu_2(a[0],a[1],head,n);
            shead = shead->right;
            for(i = 0; i < 6; i++)
            {
                if(shead->end[i] == 0)
                {
                    get = i-1;
                    break;
                }
                mvprintw(7+(i*2),8,"%.2f~%.2f",shead->start[i],shead->end[i]);
                mvprintw(7+(i*2),25,"%d号厅",shead->room[i]);
                mvprintw(7+(i*2),64,"选择");
                mvchgat(7+(i*2),62,8,A_NORMAL,2,NULL);
                get = i;
            }
        }
        else if(a[0] == 21 && a[1] == 36 && shead->left != NULL)
        {
            clear();
            Menu_2(a[0],a[1],head,n);
            shead = shead->left;
            for(i = 0; i < 6; i++)
            {
                if(shead->end[i] == 0)
                {
                    get = i-1;
                    break;
                }
                mvprintw(7+(i*2),8,"%.2f~%.2f",shead->start[i],shead->end[i]);
                mvprintw(7+(i*2),25,"%d号厅",shead->room[i]);
                mvprintw(7+(i*2),64,"选择");
                mvchgat(7+(i*2),62,8,A_NORMAL,2,NULL);
                get = i;
            }
        }
        else if(a[0] == 21 && a[1] == 12)
        {
            break;
        }
    }
}